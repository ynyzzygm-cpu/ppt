from pathlib import Path
import json,sys,os,shutil,hashlib
os.environ.setdefault('MPLCONFIGDIR','/tmp/lpv808_ag_plots')
import numpy as np,pandas as pd
from scipy.special import wrightomega
from scipy.optimize import brentq,minimize_scalar
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator
R=Path(__file__).resolve().parent;O=R
rawp=R/'selected_007_raw.csv';d=pd.read_csv(rawp);v=d.voltage_V.to_numpy();i=d.current_output_A.to_numpy();power=v*i
A=json.loads((R/'analytic_results.json').read_text());runs=json.loads((R/'ga_runs.json').read_text());cfg=json.loads((R/'ga_config.json').read_text())
runs_sorted=sorted(runs,key=lambda r:r['best_SSE_A2_training']);rep=runs_sorted[len(runs)//2];pa=A['main']['parameters'];pg=rep['parameters'];f=A['features_raw'];isc=f['Isc_A'];voc=f['Voc_V'];pm=f['Pmpp_W']
strict=(v>0)&(i>0);train=np.arange(len(v))<72;nonneg=i>=0

def current(x,p):
 x=np.asarray(x);iph=p['Iph_A'];a=p['a_V'];rs=p['Rs_ohm'];g=1/p['Rsh_ohm'];li=p.get('lnI0',p.get('log_I0_A',np.log(p['I0_A'])));i0=np.exp(li);den=1+rs*g
 return (iph+i0-x*g)/den-a/rs*wrightomega(np.log(rs)+li-np.log(a*den)+(rs*(iph+i0)+x)/(a*den))

def metrics(pred,m):
 e=pred[m]-i[m];ep=v[m]*e;j=np.flatnonzero(m)[np.argmax(abs(e))]
 return {'N':int(sum(m)),'SSE_A2':float(sum(e*e)),'RMSE_mA':float(1000*np.sqrt(np.mean(e*e))),'NRMSE_percent_Isc':float(100*np.sqrt(np.mean(e*e))/isc),'MAE_mA':float(1000*np.mean(abs(e))),'max_abs_error_mA':float(1000*max(abs(e))),'bias_mA':float(1000*np.mean(e)),'max_error_voltage_V':float(v[j]),'R2':float(1-sum(e*e)/sum((i[m]-i[m].mean())**2)),'power_RMSE_W':float(np.sqrt(np.mean(ep*ep)))}

def features(p):
 vo=brentq(lambda x:float(current(x,p)),0,10,xtol=1e-13)
 m=minimize_scalar(lambda x:-x*float(current(x,p)),bounds=(0,vo),method='bounded',options={'xatol':1e-13});vv=float(m.x);ii=float(current(vv,p));pp=vv*ii
 return {'Isc_A':float(current(0,p)),'Voc_V':vo,'Vmpp_V':vv,'Impp_A':ii,'Pmpp_W':pp,'Pmpp_error_percent':float(100*(pp/pm-1)),'Vmpp_error_percent':float(100*(vv/f['Vmpp_V']-1)),'Impp_error_percent':float(100*(ii/f['Impp_A']-1))}
P={'Analytical':pa,'GA_median_run':pg};M={};F={}
for name,p in P.items():
 pred=current(v,p);M[name]={'strict70':metrics(pred,strict),'calibration72':metrics(pred,train),'all73_stress':metrics(pred,np.ones(len(v),bool))};F[name]=features(p)
all_nr=np.array([r['metrics']['strict70']['NRMSE_percent_Isc'] for r in runs]);run_rmse=np.array([r['metrics']['strict70']['RMSE_A']*1000 for r in runs]);times=np.array([r['runtime_seconds'] for r in runs])
sens=pd.read_csv(R/'window_sensitivity.csv');sens['uses_index72_stress_point']=sens.oc_hi_V>7.1
summary={'paper':{'title':'太阳电池单二极管模型中的参数提取方法','authors':'肖文波、刘伟庆、吴华明、张华明','journal':'物理学报67,198801(2018)','doi':'10.7498/aps.67.20181024','analytic_method':'Section2 example1 Five Points, Eqs2-6 with explicitly disclosed reciprocal correction to printed Eq2','GA_method':'Section5 example1, Eq31 SSE; independently specified real-coded GA implementation'},'source':{'record':'LPV-808-164-007','raw_csv_sha256':hashlib.sha256(rawp.read_bytes()).hexdigest(),'nominal_Pin_W':8,'area_cm2':1,'ambient_C':25,'actual_junction_temperature_measured':False,'calibration_points':72,'primary_error_points':70},'measured_features':f,'analytic_inputs':A['main'],'parameters':P,'metrics':M,'model_features':F,'GA_configuration':cfg,'GA_representative_seed':rep['seed'],'GA_representative_selection':'middle rank by training72 SSE, preserving one coherent run parameter set','GA_repeat_statistics':{'runs':len(runs),'NRMSE70_percent_min':float(all_nr.min()),'NRMSE70_percent_median':float(np.median(all_nr)),'NRMSE70_percent_max':float(all_nr.max()),'RMSE70_mA_min':float(run_rmse.min()),'RMSE70_mA_median':float(np.median(run_rmse)),'RMSE70_mA_max':float(run_rmse.max()),'runtime_s_min':float(times.min()),'runtime_s_median':float(np.median(times)),'runtime_s_max':float(times.max()),'objective_evaluations_per_run':runs[0]['objective_evaluations']},'analytic_sensitivity':{'cases':len(sens),'calibration_only_cases':int((~sens.uses_index72_stress_point).sum()),'all_NRMSE_min_percent':float(sens.NRMSE_percent_Isc.min()),'all_NRMSE_max_percent':float(sens.NRMSE_percent_Isc.max()),'calibration_only_min_percent':float(sens.loc[~sens.uses_index72_stress_point,'NRMSE_percent_Isc'].min()),'calibration_only_max_percent':float(sens.loc[~sens.uses_index72_stress_point,'NRMSE_percent_Isc'].max())},'NRMSE_reduction_percent':100*(1-M['GA_median_run']['strict70']['NRMSE_percent_Isc']/M['Analytical']['strict70']['NRMSE_percent_Isc']),'limitations':['Within-scan reconstruction, not independent prediction validation.','No independently measured true parameter values.','Paper review Eq2 misses reciprocal; corrected expression disclosed.','GA hyperparameters are this implementation, not specified by the review.','Primary analytic windows are fixed before reconstruction-error inspection, not selected for the smallest error.']}
(O/'comparison_results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
params=[]
for k in ['Iph_A','I0_A','a_V','Rs_ohm','Rsh_ohm']:params.append({'parameter':k,'Analytical':pa[k],'GA_median_run':pg[k]})
pd.DataFrame(params).to_csv(O/'Extracted_Parameters.csv',index=False)
pd.DataFrame([{'method':n,'domain':domain,**me,**F[n]} for n,ds in M.items() for domain,me in ds.items()]).to_csv(O/'Error_Comparison.csv',index=False)
z=d.copy()
for n,p in P.items():z[n+'_I_A']=current(v,p);z[n+'_P_W']=v*z[n+'_I_A'];z[n+'_error_mA']=1000*(z[n+'_I_A']-i)
z['strict70']=strict;z.to_csv(O/'Measured_vs_Models.csv',index=False)
sens.to_csv(O/'Analytical_Window_Sensitivity.csv',index=False)
vd=np.unique(np.r_[np.linspace(0,7.2,1601),F['Analytical']['Voc_V'],F['GA_median_run']['Voc_V'],F['Analytical']['Vmpp_V'],F['GA_median_run']['Vmpp_V']]);dense=pd.DataFrame({'voltage_V':vd})
for n,p in P.items():dense[n+'_I_A']=current(vd,p);dense[n+'_P_W']=vd*dense[n+'_I_A']
dense.to_csv(O/'Dense_Model_Curves.csv',index=False)
plt.rcParams.update({'font.family':'Nimbus Roman','font.size':12,'axes.labelsize':15,'axes.titlesize':15,'legend.fontsize':11,'xtick.labelsize':12,'ytick.labelsize':12,'axes.linewidth':1,'svg.fonttype':'none','pdf.fonttype':42,'savefig.facecolor':'white'})
RED='#D62728';BLUE='#0072B2';ORANGE='#D55E00'
condition='LPV-808-164-007 | 808 nm, 6 junctions | nominal Pin = 8 W | ambient 25 °C'

def axes(ax,xl,yl,xlim,ylim):
 ax.set(xlabel=xl,ylabel=yl,xlim=xlim,ylim=ylim);ax.tick_params(direction='in',top=True,right=True,which='both');ax.xaxis.set_minor_locator(AutoMinorLocator(2));ax.yaxis.set_minor_locator(AutoMinorLocator(2))

def save(fig,stem):
 fig.savefig(O/(stem+'.png'),dpi=360,bbox_inches='tight');fig.savefig(O/(stem+'.svg'),bbox_inches='tight');p=O/(stem+'.svg');p.write_text(p.read_text().replace('Nimbus Roman','Times New Roman'));plt.close(fig)

fig,(ax,bx)=plt.subplots(1,2,figsize=(12,4.8));fig.subplots_adjust(left=.065,right=.985,bottom=.19,top=.8,wspace=.25)
for name,col,ls in [('Analytical',ORANGE,'-'),('GA_median_run',BLUE,'--')]:
 x=vd[vd<=F[name]['Voc_V']];y=current(x,P[name]);label='Analytical (Five Points)' if name=='Analytical' else 'GA (median run)';ax.plot(x,y,color=col,ls=ls,lw=2,label=label);bx.plot(x,x*y,color=col,ls=ls,lw=2,label=label)
ax.plot(v[nonneg],i[nonneg],'o',mfc='white',mec=RED,ms=3.5,label='Experiment');bx.plot(v[strict],power[strict],'o',mfc='white',mec=RED,ms=3.5,label='Experiment')
axes(ax,'Voltage (V)','Current (A)',(0,7.25),(0,.81));axes(bx,'Voltage (V)','Power (W)',(0,7.25),(0,4.9));ax.set_title('(a) I–V comparison');bx.set_title('(b) P–V comparison');ax.legend(loc='lower left');bx.legend(loc='upper left')
fig.suptitle('Analytical extraction and genetic algorithm for sample 007',y=.99,fontsize=18);fig.text(.5,.87,condition,ha='center',fontsize=11)
fig.text(.5,.045,'Both methods use the complete single-diode forward model; GA curves show training-SSE median run (seed37).',ha='center',fontsize=10.5)
save(fig,'007_Analytical_GA_IV_PV')
fig,(ax,bx)=plt.subplots(1,2,figsize=(12,5.1));fig.subplots_adjust(left=.065,right=.985,bottom=.19,top=.74,wspace=.27)
for name,col,ls in [('Analytical',ORANGE,'-'),('GA_median_run',BLUE,'--')]:
 xx=vd[(vd>=6.1)&(vd<=F[name]['Voc_V'])];ax.plot(xx,current(xx,P[name]),color=col,ls=ls,lw=2,label='Analytical' if name=='Analytical' else 'GA (median run)');bx.plot(v[strict],1000*(current(v[strict],P[name])-i[strict]),'o'+ls,color=col,ms=3,lw=1.4,label='Analytical' if name=='Analytical' else 'GA (median run)')
ax.plot(v[strict],i[strict],'o',mfc='white',mec=RED,ms=4,label='Experiment');bx.axhline(0,lw=.8,color='#777777');axes(ax,'Voltage (V)','Current (A)',(6.1,7.12),(0,.77));axes(bx,'Voltage (V)','Current residual (mA)',(0,7.15),(-14,10));ax.set_title('(a) High-voltage region');bx.set_title('(b) Residual = model − experiment')
leg=fig.legend(*ax.get_legend_handles_labels(),loc='upper center',bbox_to_anchor=(.5,.855),ncol=3,frameon=False)
for artist in leg.get_children():artist.set_clip_on(False)
ma=M['Analytical']['strict70'];mg=M['GA_median_run']['strict70'];fig.suptitle('Reconstruction error on the same 70 generating-region points',y=.99,fontsize=18);fig.text(.5,.90,f"NRMSE / Isc: analytical {ma['NRMSE_percent_Isc']:.4f}%; GA {mg['NRMSE_percent_Isc']:.4f}%",ha='center',fontsize=12)
fig.text(.5,.045,'The single scan evaluates reconstruction quality, not independent predictions at other powers or temperatures.',ha='center',fontsize=10.5);save(fig,'007_Analytical_GA_Residuals')
fig,(ax,bx)=plt.subplots(1,2,figsize=(14,4.8));fig.subplots_adjust(left=.06,right=.81,bottom=.2,top=.8,wspace=.32)
for run in runs:
 h=pd.read_csv(R/f"ga_history_seed{run['seed']}.csv");ax.semilogy(h.generation,1000*np.sqrt(h.best_SSE_A2/72),lw=1.5,label=f"seed {run['seed']}")
ax.set(xlabel='Generation',ylabel='Best training RMSE (mA)',xlim=(0,2000));ax.grid(alpha=.2);ax.legend(ncol=2,fontsize=10);ax.set_title('(a) Five independent GA runs')
valid=sens[~sens.uses_index72_stress_point]
for (lo,deg),group in valid.groupby(['oc_lo_V','oc_degree']):
 bx.plot(group.sc_hi_V,group.NRMSE_percent_Isc,'o-',ms=4,lw=1.3,label=f'OC {lo:g}–7.1 V, order {int(deg)}')
bx.scatter([1],[ma['NRMSE_percent_Isc']],marker='*',s=130,c='black',zorder=10,label='Fixed primary window');bx.set(xlabel='SC regression upper voltage (V)',ylabel='NRMSE / Isc (%)',xlim=(.2,2.1));bx.legend(fontsize=9,loc='upper left',bbox_to_anchor=(1.02,1),borderaxespad=0);bx.grid(alpha=.15);bx.set_title('(b) Endpoint-window sensitivity')
fig.suptitle('Optimization repeatability and analytical sensitivity',y=.99,fontsize=18);fig.text(.5,.87,'Pure GA: 512 individuals, 2000 generations, five seeds; no local least-squares polishing',ha='center',fontsize=11);fig.text(.5,.045,'Sensitivity curves use index0–71 only. The fixed primary window is not chosen by minimum reconstruction error.',ha='center',fontsize=10.5);save(fig,'007_GA_Convergence_Analytical_Sensitivity')

print("Comparison figures and tables regenerated in", O)
