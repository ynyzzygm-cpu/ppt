"""Pure real-coded genetic algorithm for 007 single-diode parameters.

Review 2018 Section 5.1 and Eq.(31) specify SSE and selection/crossover/mutation,
but no hyperparameters. This implementation therefore makes and records its own
choices. No differential evolution, least-squares polishing or previous-fit seeding.
"""
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/lpv808_ga_mpl')
from pathlib import Path
import time,json,argparse,hashlib
import numpy as np,pandas as pd
from scipy.special import wrightomega
from scipy.optimize import brentq,minimize_scalar
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'selected_007_raw.csv'
D=pd.read_csv(SOURCE);V=D.voltage_V.to_numpy();I=D.current_output_A.to_numpy()
TRAIN=np.arange(len(V))<72
EVAL=(V>0)&(I>0)
ISC=float(np.interp(0,V,I));kk=np.where((I[:-1]>=0)&(I[1:]<0))[0][0]
VOC=float(V[kk]-I[kk]*(V[kk+1]-V[kk])/(I[kk+1]-I[kk]))
VM=float(V[np.argmax(V*I)]);IM=float(I[np.argmax(V*I)])
LOW=np.array([.6,np.log(.01*ISC),.08,.001,1.])
HIGH=np.array([.9,np.log(10*ISC),.5,1.2,5.5])

def decode(U):
 z=LOW+np.asarray(U)*(HIGH-LOW)
 iph=z[...,0];a=z[...,2];rs=z[...,3];rsh=10.**z[...,4]
 lnI0=z[...,1]-VOC/a
 return iph,lnI0,a,rs,rsh

def predict_population(U,v=V[TRAIN]):
 iph,lnI0,a,rs,rsh=decode(U)
 iph=iph[...,None];lnI0=lnI0[...,None];a=a[...,None];rs=rs[...,None];g=1/rsh[...,None]
 d=1+rs*g;i0=np.exp(lnI0)
 logarg=np.log(rs)-np.log(a*d)+lnI0+(rs*(iph+i0)+np.asarray(v))/(a*d)
 return (iph+i0-np.asarray(v)*g)/d-a/rs*wrightomega(logarg)

def sse(U):
 err=predict_population(U)-I[TRAIN]
 val=np.sum(err*err,axis=-1)
 return np.where(np.isfinite(val),val,1e100)

def reflect(X):
 z=np.mod(X,2);return np.where(z>1,2-z,z)

def evolve(seed,population=512,generations=2000,elite=8):
 rng=np.random.default_rng(seed)
 P=rng.uniform(size=(population,5));F=sse(P)
 hist=[];start=time.perf_counter();evals=population
 for gen in range(generations+1):
  order=np.argsort(F);P=P[order];F=F[order]
  hist.append((gen,float(F[0]),float(np.median(F)),float(np.std(P,axis=0).mean())))
  if gen==generations:break
  need=population-elite
  pairs=(need+1)//2
  indices=rng.integers(0,population,size=(pairs*2,3))
  selected=indices[np.arange(pairs*2),np.argmin(F[indices],axis=1)]
  a1=P[selected[:pairs]];a2=P[selected[pairs:]]
  uu=rng.uniform(1e-12,1-1e-12,size=(pairs,5));eta=15.
  beta=np.where(uu<.5,(2*uu)**(1/(eta+1)),(1/(2*(1-uu)))**(1/(eta+1)))
  cross=(rng.random((pairs,1))<.9)
  beta=np.where(cross,beta,1.)
  c1=.5*((1+beta)*a1+(1-beta)*a2);c2=.5*((1-beta)*a1+(1+beta)*a2)
  C=np.r_[c1,c2][:need]
  # Annealed Gaussian gene mutation, a documented GA mutation schedule.
  progress=gen/max(1,generations-1)
  sigma=.05*(1e-5/.05)**progress
  mutation=rng.random(C.shape)<.2
  C=reflect(C+mutation*rng.normal(scale=sigma,size=C.shape))
  # One percent of offspring are independent random immigrants.
  immigrant=max(1,int(round(population*.01)))
  C[-immigrant:]=rng.uniform(size=(immigrant,5))
  P=np.r_[P[:elite],C];F=np.r_[F[:elite],sse(C)];evals+=need
 elapsed=time.perf_counter()-start
 return P[0],float(F[0]),pd.DataFrame(hist,columns=['generation','best_SSE_A2','median_SSE_A2','mean_gene_standard_deviation']),elapsed,evals

def parameters(u):
 iph,li,a,rs,rsh=decode(u)
 return {'Iph_A':float(iph),'I0_A':float(np.exp(li)),'lnI0':float(li),'a_V':float(a),'Rs_ohm':float(rs),'Rsh_ohm':float(rsh),'d_log_diode_current_at_Voc_reference':float(LOW[1]+u[1]*(HIGH[1]-LOW[1]))}

def model_current(v,p):
 iph,li,a,rs,g=p['Iph_A'],p['lnI0'],p['a_V'],p['Rs_ohm'],1/p['Rsh_ohm']
 v=np.asarray(v);i0=np.exp(li);d=1+rs*g
 z=np.log(rs)-np.log(a*d)+li+(rs*(iph+i0)+v)/(a*d)
 return (iph+i0-v*g)/d-a/rs*wrightomega(z)

def features(p):
 fn=lambda v:float(model_current(v,p));vo=brentq(fn,0,15,xtol=1e-13)
 sol=minimize_scalar(lambda v:-v*fn(v),bounds=(0,vo),method='bounded',options={'xatol':1e-13})
 vm=float(sol.x);im=fn(vm);pm=vm*im;isc=fn(0)
 return {'Isc_A':isc,'Voc_V':vo,'Vm_V':vm,'Im_A':im,'Pm_W':pm,'FF':pm/(vo*isc),'efficiency_nominal_percent':100*pm/8,'Pm_error_percent_vs_sampled':100*(pm/(VM*IM)-1)}

def metrics(pred,mask):
 e=pred[mask]-I[mask];imax=int(np.where(mask)[0][np.argmax(abs(e))])
 return {'N':int(sum(mask)),'SSE_A2':float(np.sum(e*e)),'RMSE_A':float(np.sqrt(np.mean(e*e))),'MAE_A':float(np.mean(abs(e))),'NRMSE_percent_Isc':float(np.sqrt(np.mean(e*e))/ISC*100),'max_abs_error_A':float(np.max(abs(e))),'bias_A':float(np.mean(e)),'max_error_voltage_V':float(V[imax]),'R2':float(1-np.sum(e*e)/np.sum((I[mask]-np.mean(I[mask]))**2))}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--population',type=int,default=512);ap.add_argument('--generations',type=int,default=2000);ap.add_argument('--seeds',default='11,23,37,53,71');ap.add_argument('--suffix',default='');args=ap.parse_args()
 seeds=[int(x) for x in args.seeds.split(',')]
 cfg={'algorithm':'pure real-coded genetic algorithm','objective':'Eq31 current prediction SSE over fixed first72 measured points','population':args.population,'generations':args.generations,'seeds':seeds,'selection':'tournament size3','crossover':'SBX, probability0.9, distribution index15','mutation':'Gaussian, independent gene probability0.2; normalized sigma geometrically annealed .05 to1e-5','elitism':8,'random_immigrants':'round(1% population) per generation','initialization':'independent uniform normalized chromosomes; no previous fit or analytic parameter seed','local_polishing':False,'encoding':['Iph_A','d=lnI0+Voc_reference/a','a_V','Rs_ohm','log10Rsh'],'reference_voltage_V':VOC,'bounds':{'lower':LOW.tolist(),'upper':HIGH.tolist()},'training_points':72,'evaluation_points':70,'nominal_T_ambient_C':25,'a_interpretation':'complete6J terminal exponent voltage, not assumed microscopic one-junction ideality factor','source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest()}
 output=ROOT/args.suffix if args.suffix else ROOT;output.mkdir(exist_ok=True)
 (output/'ga_config.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2))
 runs=[]
 for seed in seeds:
  u,best,hist,secs,nf=evolve(seed,args.population,args.generations)
  par=parameters(u);pred=model_current(V,par)
  result={'seed':seed,'parameters':par,'encoded_normalized_chromosome':u.tolist(),'best_SSE_A2_training':best,'runtime_seconds':secs,'objective_evaluations':nf,'features':features(par),'metrics':{'strict70':metrics(pred,EVAL),'training72':metrics(pred,TRAIN),'all73_stress':metrics(pred,np.ones(len(V),bool))}}
  hist.to_csv(output/f'ga_history_seed{seed}.csv',index=False)
  (output/f'ga_result_seed{seed}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));runs.append(result)
  (output/'ga_runs.json').write_text(json.dumps(runs,ensure_ascii=False,indent=2))
  print(json.dumps({'seed':seed,'seconds':secs,'SSE':best,'NRMSE70':result['metrics']['strict70']['NRMSE_percent_Isc'],'parameters':par}),flush=True)
 best=min(runs,key=lambda r:r['best_SSE_A2_training']);(output/'ga_best.json').write_text(json.dumps(best,ensure_ascii=False,indent=2))
 pd.DataFrame([{'seed':r['seed'],'SSE72_A2':r['best_SSE_A2_training'],'RMSE70_mA':1000*r['metrics']['strict70']['RMSE_A'],'NRMSE70_percent':r['metrics']['strict70']['NRMSE_percent_Isc'],'max_error70_mA':1000*r['metrics']['strict70']['max_abs_error_A'],'runtime_seconds':r['runtime_seconds'],'objective_evaluations':r['objective_evaluations'],**r['parameters'],**r['features']} for r in runs]).to_csv(output/'ga_run_summary.csv',index=False)
 print('Completed',len(runs),'runs; best seed',best['seed'])
if __name__=='__main__':main()
