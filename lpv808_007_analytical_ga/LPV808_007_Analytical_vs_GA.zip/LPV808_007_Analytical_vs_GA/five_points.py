from pathlib import Path
import json,time,math
import numpy as np,pandas as pd
from scipy.special import wrightomega
from scipy.optimize import brentq,minimize_scalar
ROOT=Path(__file__).resolve().parent
RAW=ROOT/'selected_007_raw.csv'
d=pd.read_csv(RAW);V=d.voltage_V.to_numpy();I=d.current_output_A.to_numpy();strict=(V>0)&(I>0)
isc=float(np.interp(0,V,I));k=np.flatnonzero((I[:-1]>=0)&(I[1:]<0))[0];voc=float(V[k]-I[k]*(V[k+1]-V[k])/(I[k+1]-I[k]));km=int(np.argmax(V*I));vm=float(V[km]);im=float(I[km]);pm=vm*im
VT=1.380649e-23*298.15/1.602176634e-19

def derivative_at(x0,lo,hi,deg):
    m=(V>=lo-1e-3)&(V<=hi+1e-3)
    x=V[m]-x0;y=I[m]
    if sum(m)<deg+1:raise ValueError('Too few points')
    c=np.polynomial.polynomial.polyfit(x,y,deg)
    return float(c[1]),{'indices':np.flatnonzero(m).tolist(),'Vmin':float(V[m][0]),'Vmax':float(V[m][-1]),'degree':deg,'coefficients_ascending_centered':c.tolist(),'origin_V':x0,'R2':float(1-np.sum((np.polynomial.polynomial.polyval(x,c)-y)**2)/np.sum((y-y.mean())**2))}

def parameters(sc,oc,literal=False):
    Rsho=-1/sc;Rso=-1/oc
    A=isc-vm/Rsho-im;B=isc-voc/Rsho
    if A<=0 or B<=0:raise ValueError('Log domain')
    den=np.log(A/B)+im/B;num=vm+Rso*im-voc
    a=num*den*VT*VT if literal else num/den
    rs=Rso-a/B
    if min(Rsho,Rso,a,rs)<=0:raise ValueError('Nonpositive parameter')
    li0=np.log(B)-voc/a;i0=np.exp(li0)
    iph=isc*(1+rs/Rsho)+np.exp(li0+isc*rs/a)-i0
    return {'Iph_A':float(iph),'I0_A':float(i0),'log_I0_A':float(li0),'a_V':float(a),'Rs_ohm':float(rs),'Rsh_ohm':float(Rsho),'n_terminal_at_25C':float(a/VT),'n_sub_if_6_identical_at25C':float(a/(6*VT)),'Rso_ohm':float(Rso),'Rsho_ohm':float(Rsho),'formula_denominator':float(den),'formula_numerator_V':float(num),'literal_printed_formula':literal}

def current(v,p):
    v=np.asarray(v,dtype=float);ip=p['Iph_A'];i0=p['I0_A'];a=p['a_V'];rs=p['Rs_ohm'];g=1/p['Rsh_ohm'];den=1+rs*g
    arg=np.log(rs)+p['log_I0_A']-np.log(a*den)+(rs*(ip+i0)+v)/(a*den)
    return (ip+i0-v*g)/den-a/rs*wrightomega(arg)

def metric(p,m=strict):
    e=current(V[m],p)-I[m];idx=np.flatnonzero(m)[np.argmax(abs(e))]
    return {'n_points':int(sum(m)),'RMSE_A':float(np.sqrt(np.mean(e**2))),'NRMSE_percent_Isc':float(100*np.sqrt(np.mean(e**2))/isc),'MAE_A':float(np.mean(abs(e))),'max_abs_error_A':float(max(abs(e))),'max_error_voltage_V':float(V[idx]),'R2':float(1-np.sum(e**2)/np.sum((I[m]-I[m].mean())**2))}

def features(p):
    vo=brentq(lambda v:float(current(v,p)),0,10)
    s=minimize_scalar(lambda v:-v*float(current(v,p)),bounds=(0,vo),method='bounded',options={'xatol':1e-13})
    vv=float(s.x);ii=float(current(vv,p));pp=vv*ii
    return {'Isc_A':float(current(0,p)),'Voc_V':vo,'Vmpp_V':vv,'Impp_A':ii,'Pmpp_W':pp,'Pmpp_error_percent':100*(pp/pm-1),'Vmpp_error_percent':100*(vv/vm-1),'Impp_error_percent':100*(ii/im-1),'FF':pp/(float(current(0,p))*vo)}

def run():
    cases=[]
    
    for hi_sc in [.3,.5,.8,1.,1.5,2.]:
     for lo_oc,hi_oc,deg_oc in [(6.8,7.1,1),(6.9,7.1,1),(6.8,7.1,2),(6.9,7.1,2),(6.9,7.2,2),(6.8,7.2,2),(6.7,7.1,3),(6.8,7.2,3)]:
      sc,sinfo=derivative_at(0,-.001,hi_sc,1);oc,oinfo=derivative_at(voc,lo_oc,hi_oc,deg_oc)
      item={'sc_hi_V':hi_sc,'oc_lo_V':lo_oc,'oc_hi_V':hi_oc,'oc_degree':deg_oc,'dIdV_SC_A_V':sc,'dIdV_OC_A_V':oc,'short_circuit_fit':sinfo,'open_circuit_fit':oinfo}
      try:
       st=time.perf_counter();p=parameters(sc,oc);item.update({'valid':True,'parameters':p,'metrics':metric(p),'features':features(p),'elapsed_extract_s':time.perf_counter()-st})
      except Exception as e:item.update({'valid':False,'error':str(e)})
      cases.append(item)
    main=next(x for x in cases if x['sc_hi_V']==1 and x['oc_lo_V']==6.9 and x['oc_hi_V']==7.1 and x['oc_degree']==2)
    lit={'parameters':parameters(main['dIdV_SC_A_V'],main['dIdV_OC_A_V'],literal=True)};lit['metrics']=metric(lit['parameters']);lit['features']=features(lit['parameters'])
    # Raw endpoint secants demonstrate why raw nearest-point derivatives are noisy.
    secsc=(I[1]-I[0])/(V[1]-V[0]);secoc=(I[71]-I[70])/(V[71]-V[70])
    out={'reference':'Xiao et al., Acta Physica Sinica 67,198801(2018), DOI10.7498/aps.67.20181024, Section2 item1 Eqs2-6','source':str(RAW),'features_raw':{'Isc_A':isc,'Voc_V':voc,'Vmpp_V':vm,'Impp_A':im,'Pmpp_W':pm},'method':'Five Points with dimensionally consistent standard quotient for a; printed Eq2 lacks reciprocal. No global curve fitting.','main':main,'literal_print_diagnostic':lit,'window_cases':cases,'endpoint_secants':{'SC_A_V':float(secsc),'raw_Rsho_ohm':float(-1/secsc),'OC_A_V':float(secoc),'raw_Rso_ohm':float(-1/secoc)},'temperature_scope':'a is terminal exponential voltage; n values conditional on actual junction25C and identical6subcells. Only ambient25C was recorded.','limitations':['Rsho is a slope approximation, not directly measured internal shunt resistance.','Derivative estimation is sensitive to noisy/coarse .1V sampling.','Main windows chosen before looking at reconstruction error; sensitivity table is not used to select minimum residual.']}
    (ROOT/'analytic_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
    pd.DataFrame([{k:x[k] for k in ['sc_hi_V','oc_lo_V','oc_hi_V','oc_degree','dIdV_SC_A_V','dIdV_OC_A_V','valid']} | ({**x['parameters'],**x['metrics'],**x['features']} if x['valid'] else {'error':x['error']}) for x in cases]).to_csv(ROOT/'window_sensitivity.csv',index=False)
    pd.DataFrame({'voltage_V':V,'measured_I_A':I,'analytic_I_A':current(V,main['parameters']),'residual_mA':1000*(current(V,main['parameters'])-I),'strict_generation':strict}).to_csv(ROOT/'analytic_predictions.csv',index=False)
    print(json.dumps({'main':main,'literal':lit,'endpoint_secants':out['endpoint_secants'],'valid_sensitivity_cases':sum(c['valid'] for c in cases)},indent=2))

if __name__=="__main__":
    run()
