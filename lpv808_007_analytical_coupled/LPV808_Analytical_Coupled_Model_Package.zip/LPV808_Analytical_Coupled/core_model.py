"""Conditional power, junction-temperature and thermal extension of an
analytically extracted five-parameter 808 nm six-junction GaAs terminal model.

The reference parameters are read from the analytical-extraction result, never
from a joint nonlinear fit.  All extensions outside the original 8 W scan are
scenario assumptions.  The cell is spatially uniform internally; Pin is its
total intercepted incident optical power.
"""
from pathlib import Path
import json
import math
import hashlib
import numpy as np
from scipy.special import wrightomega
from scipy.optimize import brentq, minimize_scalar

ROOT = Path(__file__).resolve().parent
REFERENCE_PATH = ROOT / 'input' / 'analytic_results.json'
REFERENCE = json.loads(REFERENCE_PATH.read_text(encoding='utf-8'))
PARAMETER_KEYS = ['Iph_A', 'I0_A', 'a_V', 'Rs_ohm', 'Rsh_ohm']
BASE = {k: float(REFERENCE['main']['parameters'][k]) for k in PARAMETER_KEYS}
BASE_PARAMS = BASE
REFERENCE_SHA256 = hashlib.sha256(REFERENCE_PATH.read_bytes()).hexdigest()


def _scalar_or_array(a):
    a = np.asarray(a)
    return float(a) if a.ndim == 0 else a


def current_from_parameters(V, p):
    """Output-positive I(V), scalar or vector, via stable Lambert-W form."""
    v = np.asarray(V, dtype=float)
    iph, i0, a, rs, sh = [p[k] for k in PARAMETER_KEYS]
    d = 1 + rs / sh
    logarg = np.log(rs * i0 / (a * d)) + (rs * (iph + i0) + v) / (a * d)
    out = (iph + i0 - v / sh) / d - a / rs * wrightomega(logarg)
    return _scalar_or_array(out)


def current_internal_u(U, p):
    u = np.asarray(U, dtype=float)
    out = p['Iph_A'] - p['I0_A'] * np.expm1(u / p['a_V']) - u / p['Rsh_ohm']
    return _scalar_or_array(out)


def voltage_internal(I_A, p, generation_only=True):
    """Internal parallel-branch U(I), vectorized stable explicit inverse.

    generation_only rejects external reverse-bias/current-injection requests.
    It does not clip unsupported operating states into a spurious IV segment.
    """
    ii = np.asarray(I_A, dtype=float)
    if generation_only:
        isc = current_from_parameters(0., p)
        if np.any(ii < -1e-10) or np.any(ii > isc + 1e-10):
            raise ValueError('Current outside V>=0,I>=0 generation domain; reverse bias not modeled.')
        ii = np.clip(ii, 0., isc)
    c = p['Iph_A'] + p['I0_A'] - ii
    logarg = np.log(p['I0_A'] * p['Rsh_ohm'] / p['a_V']) + c * p['Rsh_ohm'] / p['a_V']
    u = c * p['Rsh_ohm'] - p['a_V'] * wrightomega(logarg)
    return _scalar_or_array(u)


def voltage_from_parameters(I_A, p, generation_only=True):
    ii = np.asarray(I_A, dtype=float)
    u = voltage_internal(ii, p, generation_only=generation_only)
    return _scalar_or_array(np.asarray(u) - ii * p['Rs_ohm'])


def slope(V, p):
    v = np.asarray(V, dtype=float)
    ii = np.asarray(current_from_parameters(v, p))
    u = v + ii * p['Rs_ohm']
    g = p['I0_A'] / p['a_V'] * np.exp(u / p['a_V']) + 1 / p['Rsh_ohm']
    return _scalar_or_array(-g / (1 + p['Rs_ohm'] * g))


def features_from_parameters(p, Pin_W=None):
    voc = float(voltage_from_parameters(0., p))
    fn = lambda v: current_from_parameters(v, p)
    opt = minimize_scalar(lambda v: -v * fn(v), bounds=(0., voc), method='bounded',
                          options={'xatol': 1e-11})
    vm, isc = float(opt.x), float(fn(0.))
    im = float(fn(vm)); pm = vm * im
    out = {'Isc_A': isc, 'Voc_V': voc, 'Vmpp_V': vm, 'Impp_A': im,
           'Pmpp_W': pm, 'FF': pm / (isc * voc), 'Rmpp_ohm': vm / im,
           'dI_dV_mpp_A_per_V': float(slope(vm, p))}
    if Pin_W is not None:
        out['efficiency_percent'] = 100 * pm / Pin_W
    return out


BASE_FEATURES = features_from_parameters(BASE, 8.)
DEFAULT_CONFIG = {
    'T_ref_C': 40., 'P_ref_W': 8., 'T_sink_ref_C': 25.,
    'beta_Voc_V_per_K': -.00815, 'alpha_Iph_per_K': 0., 'gamma_Rs_per_K': 0.,
    'eta_h': .9, 'Rth_K_per_W': 15. / (.9 * 8. - BASE_FEATURES['Pmpp_W']),
    'Cth_J_per_K': .3, 'temperature_domain_C': [0., 180.],
    'interpretation': 'Conditional Tref, migrated betaVoc, optical-retention fraction, Rth and Cth; not target-cell measurements.',
}


def config(overrides=None):
    c = dict(DEFAULT_CONFIG)
    if overrides:
        c.update(overrides)
    return c


def parameters(Pin_W, Tj_C, cfg=None):
    """Scalar parameters or array-valued dictionary for broadcast cell states."""
    c = config(cfg)
    pin, t = np.broadcast_arrays(np.asarray(Pin_W, dtype=float), np.asarray(Tj_C, dtype=float))
    if np.any(~np.isfinite(pin)) or np.any(pin <= 0):
        raise ValueError('Positive finite intercepted cell power is required.')
    if np.any(~np.isfinite(t)) or np.any(t < c['temperature_domain_C'][0]) or np.any(t > c['temperature_domain_C'][1]):
        raise ValueError('Junction temperature outside declared scenario domain.')
    dt = t - c['T_ref_C']
    a = BASE['a_V'] * (t + 273.15) / (c['T_ref_C'] + 273.15)
    iph_ref = BASE['Iph_A'] * (1 + c['alpha_Iph_per_K'] * dt)
    rs = BASE['Rs_ohm'] * (1 + c['gamma_Rs_per_K'] * dt)
    sh = BASE['Rsh_ohm']
    voc_ref = BASE_FEATURES['Voc_V'] + c['beta_Voc_V_per_K'] * dt
    numerator = iph_ref - voc_ref / sh
    if any(np.any(x <= 0) for x in [a, iph_ref, rs, voc_ref, numerator]):
        raise ValueError('Scenario violates positivity constraints.')
    i0 = np.where(np.abs(dt) < 1e-12, BASE['I0_A'], numerator / np.expm1(voc_ref / a))
    return {'Iph_A': _scalar_or_array(iph_ref * pin / c['P_ref_W']), 'I0_A': _scalar_or_array(i0),
            'a_V': _scalar_or_array(a), 'Rs_ohm': _scalar_or_array(rs),
            'Rsh_ohm': _scalar_or_array(np.full(pin.shape, sh))}


def current(V, params_or_Pin, Tj_C=None, cfg=None):
    p = params_or_Pin if isinstance(params_or_Pin, dict) else parameters(params_or_Pin, Tj_C, cfg)
    return current_from_parameters(V, p)


def features(params_or_Pin, Tj_C=None, cfg=None):
    if isinstance(params_or_Pin, dict):
        return features_from_parameters(params_or_Pin)
    return features_from_parameters(parameters(params_or_Pin, Tj_C, cfg), params_or_Pin)


def voltage_at_current(I_A, Pin_W, Tj_C, cfg=None):
    return voltage_from_parameters(I_A, parameters(Pin_W, Tj_C, cfg))


def loadpoint(R_ohm, Pin_W, Tj_C, cfg=None):
    r = float(R_ohm)
    if not math.isfinite(r) or r < 0:
        raise ValueError('Finite nonnegative load resistance is required.')
    p = parameters(Pin_W, Tj_C, cfg)
    if r == 0:
        return {'V_V': 0., 'I_A': current_from_parameters(0., p), 'Pout_W': 0.}
    voc = voltage_from_parameters(0., p)
    v = brentq(lambda vv: vv - r * current_from_parameters(vv, p), 0., voc, xtol=1e-12)
    ii = current_from_parameters(v, p)
    return {'V_V': float(v), 'I_A': float(ii), 'Pout_W': float(v * ii)}


def electrical_state(Pin_W, Tj_C, mode='mpp', cfg=None, Rload_ohm=None, V_V=None):
    c = config(cfg)
    if mode == 'mpp':
        f = features(Pin_W, Tj_C, c)
        # These endpoints belong to the frozen temperature, not to the whole
        # self-heating IV curve whose endpoints have different temperatures.
        return {'V_V': f['Vmpp_V'], 'I_A': f['Impp_A'], 'Pout_W': f['Pmpp_W'],
                'Rmpp_ohm': f['Rmpp_ohm'], 'isothermal_Isc_at_Tj_A': f['Isc_A'],
                'isothermal_Voc_at_Tj_V': f['Voc_V'], 'isothermal_FF_at_Tj': f['FF']}
    if mode == 'resistor':
        return loadpoint(BASE_FEATURES['Rmpp_ohm'] if Rload_ohm is None else Rload_ohm, Pin_W, Tj_C, c)
    if mode == 'short':
        return {'V_V': 0., 'I_A': current(0., Pin_W, Tj_C, c), 'Pout_W': 0.}
    if mode == 'open':
        return {'V_V': features(Pin_W, Tj_C, c)['Voc_V'], 'I_A': 0., 'Pout_W': 0.}
    if mode == 'voltage':
        v = float(V_V); ii = current(v, Pin_W, Tj_C, c)
        return {'V_V': v, 'I_A': ii, 'Pout_W': v * ii}
    raise ValueError('Unknown electrical mode.')


def thermal_state(Pin_W, T_sink_C, mode='mpp', cfg=None, Rload_ohm=None, V_V=None):
    c = config(cfg); r = float(c['Rth_K_per_W']); ts = float(T_sink_C)
    lo, hi = c['temperature_domain_C']
    if r < 0 or not lo <= ts <= hi or not 0 < c['eta_h'] <= 1:
        raise ValueError('Invalid thermal scenario.')
    state = lambda t: electrical_state(Pin_W, t, mode, c, Rload_ohm, V_V)
    residual = lambda t: t - ts - r * (c['eta_h'] * Pin_W - state(t)['Pout_W'])
    if r == 0:
        t = ts
    else:
        low = max(ts, lo)
        if residual(low) > 1e-9:
            raise ValueError('No passive thermal root above sink temperature.')
        upper = hi
        if residual(upper) < 0:
            # A fixed-voltage branch can turn unstable above a stable root.
            # Find its first upward crossing rather than miss it at the outer
            # temperature bound, and subsequently check stability explicitly.
            nodes = np.linspace(low, hi, 121)
            brackets = [(a, b) for a, b in zip(nodes[:-1], nodes[1:])
                        if residual(a) <= 0 <= residual(b)]
            if not brackets:
                raise ValueError('No stable thermal-root bracket in declared range; no clipping.')
            low, upper = brackets[0]
        t = brentq(residual, low, upper, xtol=1e-10)
    s = state(t)
    if s['V_V'] < -1e-9 or s['I_A'] < -1e-9:
        raise ValueError('Thermal operating state leaves V>=0,I>=0 generation domain.')
    if abs(s['I_A']) < 1e-10:
        s['I_A'], s['Pout_W'] = 0., 0.
    q = c['eta_h'] * Pin_W - s['Pout_W']
    if q < -1e-8:
        raise ValueError('Electrical output exceeds retained optical energy.')
    eps = 1e-3; ta, tb = max(lo, t - eps), min(hi, t + eps)
    dpdt = (state(tb)['Pout_W'] - state(ta)['Pout_W']) / (tb - ta)
    margin = 1 + r * dpdt
    if margin <= 0:
        raise ValueError('Thermally unstable operating root.')
    return {'Pin_W': float(Pin_W), 'T_sink_C': ts, 'Tj_C': float(t), 'mode': mode,
            'Rth_K_per_W': r, 'eta_h': c['eta_h'], **s, 'Qheat_W': float(q),
            'thermal_balance_residual_K': float(t - ts - r * q),
            'electrical_efficiency_percent': 100 * s['Pout_W'] / Pin_W,
            'thermal_stability_margin': float(margin)}


def thermal_mpp(Pin_W, T_sink_C, Rth_K_W=None, cfg=None):
    c = config(cfg)
    if Rth_K_W is not None:
        c['Rth_K_per_W'] = Rth_K_W
    return thermal_state(Pin_W, T_sink_C, 'mpp', c)


def thermal_voltage_point(V_V, Pin_W, T_sink_C, Rth_K_W=None, cfg=None):
    c = config(cfg)
    if Rth_K_W is not None:
        c['Rth_K_per_W'] = Rth_K_W
    return thermal_state(Pin_W, T_sink_C, 'voltage', c, V_V=V_V)


def anchor_family(T_ref_C, eta_h=.9):
    rise = float(T_ref_C) - DEFAULT_CONFIG['T_sink_ref_C']
    if rise < 0:
        raise ValueError('Passive family requires Tref >= reference sink temperature.')
    return config({'T_ref_C': float(T_ref_C), 'eta_h': eta_h,
                   'Rth_K_per_W': rise / (eta_h * 8. - BASE_FEATURES['Pmpp_W'])})


if __name__ == '__main__':
    print(json.dumps({'reference_parameters': BASE, 'reference_features': BASE_FEATURES,
                      'config': DEFAULT_CONFIG, 'anchor': thermal_state(8., 25.)}, indent=2))
