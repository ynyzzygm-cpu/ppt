from pathlib import Path
from zipfile import ZipFile
from io import BytesIO
from lxml import etree as E
from docx import Document
import json,hashlib
ROOT=Path(__file__).resolve().parent;p=ROOT/'report/LPV808_Analytical_Coupled_Study_Report.docx'
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main','c':'http://schemas.openxmlformats.org/drawingml/2006/chart','r':'http://schemas.openxmlformats.org/package/2006/relationships','m':'http://schemas.openxmlformats.org/officeDocument/2006/math','s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
a={'word_font_nodes':0,'chart_font_nodes':0,'embedded_workbook_font_nodes':0,'errors':[],'native_charts':0,'embedded_workbooks':0,'external_image_links':0,'chart_cache_max_points':0}
with ZipFile(p) as z:
 assert z.testzip() is None
 for n in z.namelist():
  if n.startswith('word/embeddings/') and n.endswith('.xlsx'):
   a['embedded_workbooks']+=1
   with ZipFile(BytesIO(z.read(n))) as wb:
    assert wb.testzip() is None
    for qn in wb.namelist():
     if qn.endswith('.xml'):
      root=E.fromstring(wb.read(qn))
      for f in root.xpath('.//s:font/s:name | .//s:rPr/s:rFont',namespaces=ns):
       a['embedded_workbook_font_nodes']+=1
       if f.get('val') not in ['Times New Roman','宋体']:a['errors'].append([n,qn,'spreadsheet_font',dict(f.attrib)])
  if n.endswith('.rels'):
   for q in E.fromstring(z.read(n)):
    if q.get('TargetMode')=='External' and q.get('Type','').endswith('/image'):a['external_image_links']+=1
  if not n.endswith('.xml'):continue
  root=E.fromstring(z.read(n))
  if n.startswith('word/charts/chart'):
   a['native_charts']+=1
   for q in root.xpath('.//a:latin | .//a:ea | .//a:cs',namespaces=ns):
    want='宋体' if E.QName(q).localname=='ea' else 'Times New Roman';a['chart_font_nodes']+=1
    if q.get('typeface')!=want:a['errors'].append([n,'chart_font',dict(q.attrib)])
   for c in root.xpath('.//c:ptCount',namespaces=ns):a['chart_cache_max_points']=max(a['chart_cache_max_points'],int(c.get('val')))
  elif n.startswith('word/'):
   for q in root.xpath('.//w:rFonts',namespaces=ns):
    a['word_font_nodes']+=1
    for k,v in [('ascii','Times New Roman'),('hAnsi','Times New Roman'),('eastAsia','宋体'),('cs','Times New Roman')]:
     if q.get('{'+ns['w']+'}'+k)!=v:a['errors'].append([n,k,dict(q.attrib)])
  for q in root.xpath('.//m:mathFont',namespaces=ns):
   if q.get('{'+ns['m']+'}val')!='Times New Roman':a['errors'].append([n,'mathFont',dict(q.attrib)])
 a['native_equations']=len(E.fromstring(z.read('word/document.xml')).xpath('.//m:oMath',namespaces=ns))

a['passed']=not a['errors'] and a['native_charts']==a['embedded_workbooks']==20 and a['external_image_links']==0 and a['chart_cache_max_points']<=500
a['docx_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'report/font_and_structure_audit.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
print(json.dumps(a,ensure_ascii=False))
assert a['passed']
