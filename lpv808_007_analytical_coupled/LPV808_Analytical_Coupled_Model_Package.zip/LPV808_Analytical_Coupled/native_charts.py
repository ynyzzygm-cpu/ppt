"""Editable Office charts in DOCX, with explicit Times New Roman / 宋体 fonts.

python-pptx is only used to generate standards-compliant chart/workbook parts.
No slide is delivered. The same DrawingML chart parts are embedded into Word.
"""
from pathlib import Path
from io import BytesIO
from zipfile import ZipFile, ZIP_DEFLATED
from lxml import etree as ET
from PIL import Image
from pptx import Presentation
from pptx.chart.data import XyChartData, CategoryChartData
from pptx.enum.chart import (XL_CHART_TYPE, XL_LEGEND_POSITION, XL_MARKER_STYLE,
                            XL_TICK_MARK, XL_TICK_LABEL_POSITION)
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from pptx.util import Inches as PInches, Pt as PPt
from pptx.dml.color import RGBColor as PRGB
from docx.shared import Cm

NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
 'a':'http://schemas.openxmlformats.org/drawingml/2006/main',
 'c':'http://schemas.openxmlformats.org/drawingml/2006/chart',
 'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
 'wp':'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing',
 'rel':'http://schemas.openxmlformats.org/package/2006/relationships',
 'ct':'http://schemas.openxmlformats.org/package/2006/content-types'}
LATIN='Times New Roman';CJK='宋体'
# Blue, vermilion, green and purple retain useful contrast in print and in
# common colour-vision deficiencies. A second line-style cue is added below.
PALETTE=['0072B2','D55E00','009E73','CC79A7','E69F00','56B4E9','444444','888888']
LINE_STYLES=[MSO_LINE_DASH_STYLE.SOLID, MSO_LINE_DASH_STYLE.DASH,
             MSO_LINE_DASH_STYLE.DASH_DOT, MSO_LINE_DASH_STYLE.LONG_DASH,
             MSO_LINE_DASH_STYLE.ROUND_DOT, MSO_LINE_DASH_STYLE.LONG_DASH_DOT]
MARKER_STYLES=[XL_MARKER_STYLE.CIRCLE,XL_MARKER_STYLE.SQUARE,
               XL_MARKER_STYLE.TRIANGLE,XL_MARKER_STYLE.DIAMOND]
def tag(ns,name):return '{'+NS[ns]+'}'+name
def child(el,ns,name):
 found=el.find(tag(ns,name))
 if found is None:found=ET.SubElement(el,tag(ns,name))
 return found
def set_drawing_fonts(root):
 for pp in ET.XPath('.//a:pPr | .//a:bodyPr | .//a:defRPr | .//a:rPr | .//a:endParaRPr',namespaces=NS)(root):
  if ET.QName(pp).localname in ['defRPr','rPr','endParaRPr']:
   for kind,face in [('latin',LATIN),('ea',CJK),('cs',LATIN)]:
    child(pp,'a',kind).set('typeface',face)
   pp.set('lang','en-US');pp.set('altLang','zh-CN')
 # Apply an explicit default to every chart text container, including axes,
 # legend and automatic tick labels; otherwise Office can inherit theme fonts.
 targets=[root]+ET.XPath('.//c:catAx | .//c:valAx | .//c:serAx | .//c:legend | .//c:dLbls',namespaces=NS)(root)
 for el in targets:
  tx=el.find(tag('c','txPr'))
  if tx is None:
   tx=ET.Element(tag('c','txPr'))
   before={'chartSpace':['externalData','printSettings','userShapes','extLst'],
           'catAx':['crossAx','crosses','crossesAt','auto','lblAlgn','lblOffset','tickLblSkip','tickMarkSkip','noMultiLvlLbl','extLst'],
           'valAx':['crossAx','crosses','crossesAt','crossBetween','majorUnit','minorUnit','dispUnits','extLst'],
           'legend':['extLst'],'dLbls':['dLblPos','showLegendKey','showVal','showCatName','showSerName','showPercent','showBubbleSize','separator','showLeaderLines','leaderLines','extLst']}.get(ET.QName(el).localname,[])
   later=next((x for x in el if ET.QName(x).localname in before),None)
   if later is None:el.append(tx)
   else:el.insert(el.index(later),tx)
   ET.SubElement(tx,tag('a','bodyPr'));ET.SubElement(tx,tag('a','lstStyle'))
   pa=ET.SubElement(tx,tag('a','p'));ppr=ET.SubElement(pa,tag('a','pPr'))
   dr=ET.SubElement(ppr,tag('a','defRPr'));dr.set('sz','1000')
   ET.SubElement(pa,tag('a','endParaRPr'))
 for prop in ET.XPath('.//a:defRPr | .//a:rPr | .//a:endParaRPr',namespaces=NS)(root):
  for kind,face in [('latin',LATIN),('ea',CJK),('cs',LATIN)]:child(prop,'a',kind).set('typeface',face)
  prop.set('lang','en-US');prop.set('altLang','zh-CN')

def set_word_fonts(root):
 # Remove theme-based overrides wherever a Word font element already exists.
 for fonts in root.xpath('.//w:rFonts',namespaces=NS):
  for attr in list(fonts.attrib):
   if ET.QName(attr).localname.endswith('Theme'):del fonts.attrib[attr]
  for k,v in [('ascii',LATIN),('hAnsi',LATIN),('eastAsia',CJK),('cs',LATIN)]:fonts.set(tag('w',k),v)
 # Explicit fonts for every actual run: titles, tables, headers and fields.
 for run in root.xpath('.//w:r',namespaces=NS):
  rp=run.find(tag('w','rPr'))
  if rp is None:rp=ET.Element(tag('w','rPr'));run.insert(0,rp)
  ff=rp.find(tag('w','rFonts'))
  if ff is None:ff=ET.Element(tag('w','rFonts'));rp.insert(0,ff)
  for attr in list(ff.attrib):
   if ET.QName(attr).localname.endswith('Theme'):del ff.attrib[attr]
  for k,v in [('ascii',LATIN),('hAnsi',LATIN),('eastAsia',CJK),('cs',LATIN)]:ff.set(tag('w',k),v)

def set_theme(root):
 for f in root.xpath('.//a:majorFont | .//a:minorFont',namespaces=NS):
  for k,v in [('latin',LATIN),('ea',CJK),('cs',LATIN)]:child(f,'a',k).set('typeface',v)
  for e in list(f.findall(tag('a','font'))):
   if e.get('script') in ['Hans','Hant']:e.set('typeface',CJK)
   else:f.remove(e)

def workbook_fonts(blob):
 """Font the editable workbook too, including mixed Chinese series labels."""
 sn='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
 with ZipFile(BytesIO(blob)) as z:parts={n:z.read(n) for n in z.namelist()}
 if 'xl/styles.xml' in parts:
  r=ET.fromstring(parts['xl/styles.xml'])
  for ff in r.findall('.//{'+sn+'}font'):
   nm=ff.find('{'+sn+'}name')
   if nm is None:nm=ET.SubElement(ff,'{'+sn+'}name')
   nm.set('val',LATIN)
   for old in list(ff.findall('{'+sn+'}scheme')):ff.remove(old)
  parts['xl/styles.xml']=ET.tostring(r,xml_declaration=True,encoding='UTF-8',standalone=True)
 # SpreadsheetML fonts have one family name rather than DrawingML's separate
 # Latin/East-Asian families. Split string cells into rich-text runs so that
 # editing the embedded data preserves the same language-specific fonts.
 import unicodedata
 for name,data in list(parts.items()):
  if name=='xl/sharedStrings.xml' or (name.startswith('xl/worksheets/') and name.endswith('.xml')):
   r=ET.fromstring(data)
   for item in r.findall('.//{'+sn+'}si')+r.findall('.//{'+sn+'}is'):
    txt=''.join(item.itertext())
    if not txt:continue
    for old in list(item):item.remove(old)
    groups=[]
    for ch in txt:
     face=CJK if unicodedata.east_asian_width(ch) in ('W','F') else LATIN
     if groups and groups[-1][0]==face:groups[-1]=(face,groups[-1][1]+ch)
     else:groups.append((face,ch))
    for face,segment in groups:
     run=ET.SubElement(item,'{'+sn+'}r');rp=ET.SubElement(run,'{'+sn+'}rPr')
     ET.SubElement(rp,'{'+sn+'}rFont').set('val',face)
     tt=ET.SubElement(run,'{'+sn+'}t');tt.text=segment
     if segment!=segment.strip():tt.set('{http://www.w3.org/XML/1998/namespace}space','preserve')
   parts[name]=ET.tostring(r,xml_declaration=True,encoding='UTF-8',standalone=True)
 for name in list(parts):
  if name.startswith('xl/theme/') and name.endswith('.xml'):
   r=ET.fromstring(parts[name]);set_theme(r);parts[name]=ET.tostring(r,xml_declaration=True,encoding='UTF-8',standalone=True)
 out=BytesIO()
 with ZipFile(out,'w',ZIP_DEFLATED) as z:
  for n,data in parts.items():z.writestr(n,data)
 return out.getvalue()

class ChartBook:
 def __init__(self,work):
  self.work=Path(work);self.work.mkdir(exist_ok=True,parents=True)
  self.prs=Presentation();self.charts=[]
  self.blank=self.work/'chart_slot.png'
  Image.new('RGB',(8,8),'white').save(self.blank)
 def add(self,doc,series,x_title,y_title,height=7,width=16.8,kind='scatter',categories=None,legend=True,x_min=None,x_max=None,y_min=None,y_max=None,log_x=False,
         x_format=None,y_format=None,x_major=None,y_major=None,
         line_width=1.6,tick_size=10,title_size=11,legend_size=9,
         legend_position='bottom',style_cycle=True,alt_text=None):
  """Add one independent, editable scientific figure.

  Existing calls and series fields remain valid. New optional fields are:
  ``line_style`` (solid/dash/dash_dot/dot/long_dash), ``marker_style``
  (circle/square/triangle/diamond), and ``marker_fill`` (solid/open).
  Axis labels should state the measured quantity and unit, e.g. 电压 (V).
  Figure captions and panel labels belong in Word, outside the chart.
  """
  import math
  if width<=0 or height<=0:raise ValueError('Chart width and height must be positive.')
  if not series:raise ValueError('A chart needs at least one data series.')
  if kind not in ('scatter','column'):raise ValueError('kind must be scatter or column.')
  if x_min is not None and x_max is not None and x_min>=x_max:raise ValueError('x_min must be smaller than x_max.')
  if y_min is not None and y_max is not None and y_min>=y_max:raise ValueError('y_min must be smaller than y_max.')
  if log_x and kind!='scatter':raise ValueError('A logarithmic x axis requires a scatter chart.')
  if log_x and x_min is not None and x_min<=0:raise ValueError('A logarithmic x axis requires positive limits.')
  slide=self.prs.slides.add_slide(self.prs.slide_layouts[6])
  if kind=='scatter':
   data=XyChartData()
   for ss in series:
    if len(ss['x'])!=len(ss['y']):raise ValueError('x and y arrays must have the same length: '+str(ss['name']))
    s=data.add_series(ss['name'])
    for xx,yy in zip(ss['x'],ss['y']):
     if xx is None or yy is None:continue
     xx,yy=float(xx),float(yy)
     if not math.isfinite(xx) or not math.isfinite(yy):raise ValueError('Chart data must be finite: '+str(ss['name']))
     if log_x and xx<=0:raise ValueError('Logarithmic x data must be positive: '+str(ss['name']))
     s.add_data_point(xx,yy)
   ctype=XL_CHART_TYPE.XY_SCATTER_LINES_NO_MARKERS
  else:
   if categories is None:raise ValueError('Column charts require categories.')
   data=CategoryChartData();data.categories=list(categories)
   for ss in series:
    if len(ss['y'])!=len(categories):raise ValueError('Category and value arrays must have the same length: '+str(ss['name']))
    values=[float(v) if v is not None else None for v in ss['y']]
    if any(v is not None and not math.isfinite(v) for v in values):raise ValueError('Chart data must be finite.')
    data.add_series(ss['name'],values)
   ctype=XL_CHART_TYPE.COLUMN_CLUSTERED
  # Build at the final physical size instead of distorting a fixed 9 x 4 in
  # chart into every Word slot. Text size and geometry then match the report.
  chart=slide.shapes.add_chart(ctype,PInches(.2),PInches(.2),PInches(width/2.54),PInches(height/2.54),data).chart
  if kind=='scatter' and any(ss.get('markers') or ss.get('points_only') for ss in series):
   chart._chartSpace.find('.//'+tag('c','scatterStyle')).set('val','lineMarker')
  chart.has_title=False;chart.has_legend=legend and len(series)>1
  # Keep a plain white figure with no enclosing rectangular decoration.
  for element in (chart._chartSpace,chart._chartSpace.find('.//'+tag('c','plotArea'))):
   sp=child(element,'c','spPr')
   if ET.QName(element).localname=='chartSpace':
    # CT_ChartSpace requires spPr before txPr/externalData, rather than an
    # arbitrary append after the workbook relationship.
    later=next((v for v in element if ET.QName(v).localname in
                ('txPr','externalData','printSettings','userShapes','extLst')),None)
    if later is not None:
     element.remove(sp);element.insert(element.index(later),sp)
   fill=child(sp,'a','solidFill');child(fill,'a','srgbClr').set('val','FFFFFF')
   ln=child(sp,'a','ln');child(ln,'a','noFill')
  if chart.has_legend:
   positions={'bottom':XL_LEGEND_POSITION.BOTTOM,'right':XL_LEGEND_POSITION.RIGHT,
              'top':XL_LEGEND_POSITION.TOP,'left':XL_LEGEND_POSITION.LEFT}
   if legend_position not in positions:raise ValueError('Unknown legend_position.')
   chart.legend.position=positions[legend_position];chart.legend.include_in_layout=False
   chart.legend.font.name=LATIN;chart.legend.font.size=PPt(legend_size)
   chart.legend.font.color.rgb=PRGB.from_string('222222')
  for axis,title,mi,ma,fmt,major in [
      (chart.category_axis,x_title,x_min,x_max,x_format or '0.##',x_major),
      (chart.value_axis,y_title,y_min,y_max,y_format or '0.###',y_major)]:
   axis.tick_labels.font.name=LATIN;axis.tick_labels.font.size=PPt(tick_size)
   axis.tick_labels.font.color.rgb=PRGB.from_string('222222')
   axis.tick_label_position=XL_TICK_LABEL_POSITION.LOW
   axis.major_tick_mark=XL_TICK_MARK.OUTSIDE;axis.minor_tick_mark=XL_TICK_MARK.NONE
   axis.format.line.color.rgb=PRGB.from_string('555555');axis.format.line.width=PPt(.65)
   axis.has_title=bool(title)
   if title:
    tf=axis.axis_title.text_frame;tf.text=title
    for pp in tf.paragraphs:
     pp.font.name=LATIN;pp.font.size=PPt(title_size)
     pp.font.color.rgb=PRGB.from_string('111111')
   if mi is not None:axis.minimum_scale=mi
   if ma is not None:axis.maximum_scale=ma
   if major is not None:
    if major<=0:raise ValueError('Major tick intervals must be positive.')
    axis.major_unit=major
   axis.tick_labels.number_format=fmt
   axis.tick_labels.number_format_is_linked=False
  if log_x:
   scaling=chart.category_axis._element.find(tag('c','scaling'))
   lb=scaling.find(tag('c','logBase'))
   if lb is None:lb=ET.Element(tag('c','logBase'));scaling.insert(0,lb)
   lb.set('val','10')
  chart.category_axis.has_major_gridlines=False
  chart.value_axis.has_major_gridlines=True
  grid=chart.value_axis.major_gridlines.format.line
  grid.color.rgb=PRGB.from_string('DDE2E7');grid.width=PPt(.45)
  if kind=='column':chart.plots[0].gap_width=70
  dash_map={'solid':MSO_LINE_DASH_STYLE.SOLID,'dash':MSO_LINE_DASH_STYLE.DASH,
            'dash_dot':MSO_LINE_DASH_STYLE.DASH_DOT,'dot':MSO_LINE_DASH_STYLE.ROUND_DOT,
            'long_dash':MSO_LINE_DASH_STYLE.LONG_DASH}
  marker_map={'circle':XL_MARKER_STYLE.CIRCLE,'square':XL_MARKER_STYLE.SQUARE,
              'triangle':XL_MARKER_STYLE.TRIANGLE,'diamond':XL_MARKER_STYLE.DIAMOND}
  for j,(s,ss) in enumerate(zip(chart.series,series)):
   col=ss.get('color',PALETTE[j%len(PALETTE)])
   if kind=='scatter':
    s.smooth=False
    s.format.line.color.rgb=PRGB.from_string(col);s.format.line.width=PPt(ss.get('width',line_width))
    if ss.get('markers') or ss.get('points_only'):
     ms=ss.get('marker_style')
     s.marker.style=marker_map.get(ms,MARKER_STYLES[j%len(MARKER_STYLES)])
     s.marker.size=ss.get('marker_size',4)
     s.marker.format.fill.solid()
     s.marker.format.fill.fore_color.rgb=PRGB.from_string('FFFFFF' if ss.get('marker_fill')=='open' else col)
     s.marker.format.line.color.rgb=PRGB.from_string(col);s.marker.format.line.width=PPt(.6)
    else:s.marker.style=XL_MARKER_STYLE.NONE
    ls=ss.get('line_style')
    if ls is not None:
     if ls not in dash_map:raise ValueError('Unknown line_style: '+str(ls))
     s.format.line.dash_style=dash_map[ls]
    elif 'dash' in ss:s.format.line.dash_style=MSO_LINE_DASH_STYLE.DASH if ss['dash'] else MSO_LINE_DASH_STYLE.SOLID
    elif style_cycle and len(series)>1:s.format.line.dash_style=LINE_STYLES[j%len(LINE_STYLES)]
    else:s.format.line.dash_style=MSO_LINE_DASH_STYLE.SOLID
    if ss.get('points_only'):s.format.line.fill.background()
   else:
    s.format.fill.solid();s.format.fill.fore_color.rgb=PRGB.from_string(col)
    s.format.line.fill.background()
  set_drawing_fonts(chart._chartSpace)
  slot=len(self.charts)+1;self.charts.append(chart)
  shape=doc.add_picture(str(self.blank),width=Cm(width),height=Cm(height))
  shape._inline.docPr.set('name',f'LPV_NATIVE_CHART_{slot}')
  shape._inline.docPr.set('descr',alt_text or f'{x_title}; {y_title}; editable chart; Latin and numerals: Times New Roman; Chinese: 宋体')
  return chart
 def save_docx(self,doc,path):
  path=Path(path);temp=self.work/'base.docx';deck=self.work/'chart_parts.pptx'
  doc.save(temp);self.prs.save(deck)
  with ZipFile(temp) as z:parts={n:z.read(n) for n in z.namelist()}
  with ZipFile(deck) as z:pparts={n:z.read(n) for n in z.namelist()}
  main=ET.fromstring(parts['word/document.xml']);rels=ET.fromstring(parts['word/_rels/document.xml.rels']);ct=ET.fromstring(parts['[Content_Types].xml'])
  for j in range(1,len(self.charts)+1):
   rid=f'rIdLPVNativeChart{j}'
   rel=ET.SubElement(rels,tag('rel','Relationship'));rel.set('Id',rid);rel.set('Type',NS['r']+'/chart');rel.set('Target',f'charts/chart{j}.xml')
   for dp in main.xpath(f'.//wp:docPr[@name="LPV_NATIVE_CHART_{j}"]',namespaces=NS):
    inline=dp.getparent();gd=inline.find('.//'+tag('a','graphicData'))
    gd.clear();gd.set('uri',NS['c']);cc=ET.SubElement(gd,tag('c','chart'));cc.set(tag('r','id'),rid)
   chartname=f'ppt/charts/chart{j}.xml'
   rt=ET.fromstring(pparts[chartname]);set_drawing_fonts(rt)
   # Charts can contain several text containers; every run/default is checked.
   parts[f'word/charts/chart{j}.xml']=ET.tostring(rt,xml_declaration=True,encoding='UTF-8',standalone=True)
   source_rel=f'ppt/charts/_rels/chart{j}.xml.rels'
   if source_rel in pparts:
    rr=ET.fromstring(pparts[source_rel])
    for r in rr:
     target=r.get('Target')
     if target and target.startswith('../embeddings/'):
      basename=target.rsplit('/',1)[-1];r.set('Target',f'../embeddings/lpv_chart_{j}.xlsx')
      parts[f'word/embeddings/lpv_chart_{j}.xlsx']=workbook_fonts(pparts['ppt/embeddings/'+basename])
    parts[f'word/charts/_rels/chart{j}.xml.rels']=ET.tostring(rr,xml_declaration=True,encoding='UTF-8',standalone=True)
   over=ET.SubElement(ct,tag('ct','Override'));over.set('PartName',f'/word/charts/chart{j}.xml');over.set('ContentType','application/vnd.openxmlformats-officedocument.drawingml.chart+xml')
  if not any(x.get('Extension')=='xlsx' for x in ct):
   de=ET.SubElement(ct,tag('ct','Default'));de.set('Extension','xlsx');de.set('ContentType','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
  parts['word/document.xml']=ET.tostring(main,xml_declaration=True,encoding='UTF-8',standalone=True)
  parts['word/_rels/document.xml.rels']=ET.tostring(rels,xml_declaration=True,encoding='UTF-8',standalone=True)
  parts['[Content_Types].xml']=ET.tostring(ct,xml_declaration=True,encoding='UTF-8',standalone=True)
  for name,data in list(parts.items()):
   if not name.endswith('.xml'):continue
   if name.startswith('word/'):
    rt=ET.fromstring(data)
    if name.startswith('word/theme/'):set_theme(rt)
    elif not name.startswith('word/charts/'):set_word_fonts(rt)
    if name=='word/fontTable.xml':
     for old in list(rt):rt.remove(old)
     for fontname,charset in [(LATIN,'00'),(CJK,'86')]:
      ft=ET.SubElement(rt,tag('w','font'));ft.set(tag('w','name'),fontname)
      ch=ET.SubElement(ft,tag('w','charset'));ch.set(tag('w','val'),charset)
      fam=ET.SubElement(ft,tag('w','family'));fam.set(tag('w','val'),'roman')
    if name=='word/settings.xml':
     mn='http://schemas.openxmlformats.org/officeDocument/2006/math'
     for mf in rt.findall('.//{'+mn+'}mathFont'):mf.set('{'+mn+'}val',LATIN)
    parts[name]=ET.tostring(rt,xml_declaration=True,encoding='UTF-8',standalone=True)
  with ZipFile(path,'w',ZIP_DEFLATED) as z:
   for name,data in parts.items():z.writestr(name,data)
  return path

if __name__=='__main__':
 from docx import Document
 work=Path(__file__).resolve().parent/'report';work.mkdir(exist_ok=True)
 doc=Document();doc.add_paragraph('字体检查 Test 1064 nm 九结电池')
 cb=ChartBook(work);cb.add(doc,[{'name':'实测 Measured','x':[0,1,2,3],'y':[2,1.9,1.7,0]},{'name':'拟合 Fitted','x':[0,1,2,3],'y':[2,1.8,1.6,0]}],'电压 Voltage (V)','电流 Current (A)',height=8)
 print(cb.save_docx(doc,work/'native_chart_test.docx'))
