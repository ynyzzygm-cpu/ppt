"""Joint optical/boundary cases. Quadrature is for optical power only.
Each electrical/thermal cell receives a single spatially uniform Pin.
"""
from pathlib import Path
import sys,json,itertools,hashlib
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).parent))
import core_model as core
import beam_integrals as beam
OUT=Path(__file__).resolve().parent
ETA_FIBER=.98;ETA_OPTICS=.96;ETA_PATH=.96;ETA_CHAIN=ETA_FIBER*ETA_OPTICS*ETA_PATH
CONSTRAINTS={'uniform_within_each_cell':True,'spatial_electrical_microelements':False,'array_nonuniformity':'one integrated Pin and one uniform mean irradiance per cell','quadrature_is_not_cell_discretization':True}

def make(case_id,profile,w,angle,offset,ps,ts,rth,nrows=2,ncols=2,family='representative'):
 b=beam.receiver_budget(profile=profile,w_mm=w,gap_mm=.3,offset_mm=offset,angle_deg=angle,source_power_W=ps,chain_efficiency=ETA_CHAIN,cell_side_mm=10,nrows=nrows,ncols=ncols,order=128)
 row={'case_id':case_id,'family':family,'nrows':nrows,'ncols':ncols,'profile':profile,'w_mm':w,'angle_deg':angle,'theta_deg':angle,'offset_x_mm':offset[0],'offset_y_mm':offset[1],'source_power_W':ps,'Psrc_W':ps,'Tsink_C':ts,'Rth_K_per_W':rth,'G_lat_W_per_K':.03,'Rwire_ohm':.02,'eta_fiber':ETA_FIBER,'eta_optics':ETA_OPTICS,'eta_path':ETA_PATH,'eta_chain':ETA_CHAIN,'fiber_loss_W':ps*(1-ETA_FIBER),'optics_loss_W':ps*ETA_FIBER*(1-ETA_OPTICS),'path_loss_W':ps*ETA_FIBER*ETA_OPTICS*(1-ETA_PATH),'beam_power_W':b['beam_power_W'],'active_power_W':b['active_power_W'],'gap_power_W':b['gap_power_W'],'outside_power_W':b['outside_power_W'],'capture_fraction':b['active_fraction_of_beam'],'gap_mm':.3}
 pins=np.array([b[f'Pin_{j+1}_W'] for j in range(nrows*ncols)])
 row.update({f'Pin_{j+1}_W':float(x) for j,x in enumerate(pins)})
 row.update({'Pin_min_W':float(pins.min()),'Pin_max_W':float(pins.max()),'Pin_mean_W':float(pins.mean()),'Pin_CV':float(pins.std()/pins.mean()),'mean_irradiance_W_cm2':float(pins.mean()),'optical_balance_residual_W':float(ps-row['fiber_loss_W']-row['optics_loss_W']-row['path_loss_W']-row['active_power_W']-row['gap_power_W']-row['outside_power_W'])})
 assert abs(row['optical_balance_residual_W'])<1e-9 and pins.min()>0
 return row

def long(rows):
 result=[]
 for r in rows:
  for j,c in enumerate(beam.cell_rectangles(10,.3,r['nrows'],r['ncols'])):
   z={k:v for k,v in r.items() if not k.startswith('Pin_')};z.update({'cell':j+1,'row':c['row'],'column':c['column'],'cx_mm':c['cx_mm'],'cy_mm':c['cy_mm'],'Pin_W':r[f'Pin_{j+1}_W'],'irradiance_W_cm2':r[f'Pin_{j+1}_W']});result.append(z)
 return result

def run():
 rref=core.DEFAULT_CONFIG['Rth_K_per_W'];rows=[]
 for j,(w,an,ofs,ps,ts,rt) in enumerate(itertools.product([12.,18.],[0.,40.],[(0.,0.),(4.,4.)],[32.,48.],[25.,45.],[3.,8.])):
  rows.append(make(f'F{j:03d}','gaussian',w,an,ofs,ps,ts,rt,family='factorial_6factors'))
 B={'B0':(12.,0.,(0.,0.),40.,25.,rref),'B1':(12.,40.,(4.,4.),48.,45.,8.),'B2':(18.,40.,(4.,4.),48.,25.,3.)}
 for profile in beam.PROFILES:
  for b,args in B.items():rows.append(make('R_'+profile+'_'+b,profile,*args,family='representative'))
 for j,args in enumerate([
  ('gaussian',18.,0.,(0.,0.),72.,25.,rref),('gaussian',18.,40.,(4.,4.),96.,45.,8.),('super_gaussian_m6',20.,40.,(4.,4.),96.,25.,3.),('top_hat',22.,40.,(4.,4.),96.,25.,3.)]):
  rows.append(make(f'N{j}',*args,nrows=3,ncols=3,family='nine_cell'))
 pd.DataFrame(rows).to_csv(OUT/'optical_case_summary.csv',index=False)
 pd.DataFrame(long(rows)).to_csv(OUT/'optical_power_cases.csv',index=False)
 singles=[]
 for j,(w,an,ofs,ps,ts,rt) in enumerate(itertools.product([5.,8.],[0.,40.],[(0.,0.),(2.,2.)],[12.,20.],[25.,45.],[3.,8.])):
  r=make(f'S{j:03d}','gaussian',w,an,ofs,ps,ts,rt,nrows=1,ncols=1,family='single_factorial_6factors');r['Pin_W']=r['Pin_1_W'];singles.append(r)
 pd.DataFrame(singles).to_csv(OUT/'single_optical_cases.csv',index=False)
 dyn=[make('D_before','gaussian',12.,40.,(0.,0.),32.,25.,rref,family='dynamic'),make('D_after','gaussian',12.,40.,(4.,4.),48.,25.,rref,family='dynamic')]
 pd.DataFrame(long(dyn)).to_csv(OUT/'array_dynamic_inputs.csv',index=False)
 # Precision convergence, normalization and exact source power closure.
 checks=[]
 for profile in beam.PROFILES:
  r=next(x for x in rows if x['case_id']=='R_'+profile+'_B1');p128=np.array([r[f'Pin_{j}_W'] for j in range(1,5)])
  b=beam.receiver_budget(profile=profile,w_mm=12,gap_mm=.3,offset_mm=(4,4),angle_deg=40,source_power_W=48,chain_efficiency=ETA_CHAIN,order=256)
  err=max(abs(p128-np.array([b[f'Pin_{j}_W'] for j in range(1,5)])));checks.append({'check':profile+' 128 vs 256 quadrature W','value':float(err),'passed':bool(err<1e-8)})
 checks.append({'check':'all source power budget closure W','value':float(max(abs(x['optical_balance_residual_W']) for x in rows+singles+dyn)),'passed':True})
 cfg={'reference_source':'analytical Five Points sample007','constraints':CONSTRAINTS,'source_transmission':{'eta_fiber':ETA_FIBER,'eta_optics':ETA_OPTICS,'eta_path':ETA_PATH,'eta_chain_product':ETA_CHAIN,'status':'assumed engineering scenario, not measured'},'projected_beam':'qplane=cos(theta)*q_perp((x-x0)*cos(theta),y-y0); infinite plane integral conserved; no second cos or normal-incidence surface loss applied','receiver_geometry':{'cell_side_mm':10,'gap_mm':.3,'array_shapes':[[2,2],[3,3]],'cell_numbering':'row-major, upper row positive y, left col negative x'},'main_factorial':{'count':64,'profile':'Gaussian','w_mm':[12,18],'angle_deg':[0,40],'offset_mm':[[0,0],[4,4]],'source_power_W':[32,48],'Tsink_C':[25,45],'Rth_K_per_W':[3,8]},'single_factorial':{'count':64,'profile':'Gaussian','w_mm':[5,8],'angle_deg':[0,40],'offset_mm':[[0,0],[2,2]],'source_power_W':[12,20],'Tsink_C':[25,45],'Rth_K_per_W':[3,8]},'representative_B_cases':B,'array_Glat_W_K':.03,'array_Rwire_ohm':.02,'per_cell_Cth_J_K':.3,'validation':checks,'array_optical_cases':len(rows),'single_optical_cases':len(singles),'array_received_power_range_W':[min(x['Pin_min_W'] for x in rows),max(x['Pin_max_W'] for x in rows)],'single_received_power_range_W':[min(x['Pin_W'] for x in singles),max(x['Pin_W'] for x in singles)]}
 (ROOT/'study_config.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2));(OUT/'optical_validation.json').write_text(json.dumps(checks,indent=2))
 assert all(x['passed'] for x in checks)
 print(json.dumps({'array_cases':len(rows),'single_cases':len(singles),'dynamic_cases':len(dyn),'array_Pin_range_W':cfg['array_received_power_range_W'],'single_Pin_range_W':cfg['single_received_power_range_W'],'checks':checks},ensure_ascii=False))
if __name__=='__main__':run()
