"""Power-conserving optical integrals for the analytical 808 nm cell study.

Each optical rectangle supplies ONE total power to a uniform single-cell model.
All coordinates are millimetres and density is W/mm2. The beam-plane total
power is normalized before interception. eta_chain is upstream transmission;
normal-incidence surface response is already contained in the measured Iph.
"""
from pathlib import Path
from functools import lru_cache
import math,json
import numpy as np
import pandas as pd
from scipy.special import erf,gamma
from scipy.integrate import quad
from numpy.polynomial.legendre import leggauss

OUT=Path(__file__).resolve().parent
PROFILES=('gaussian','super_gaussian_m6','top_hat')
DEFAULT_SOURCE_W=40.0
DEFAULT_CHAIN_EFFICIENCY=0.9
DEFAULT_BEAM_W=DEFAULT_SOURCE_W*DEFAULT_CHAIN_EFFICIENCY

def _profile_name(profile):
    aliases={'Gaussian':'gaussian','SG':'super_gaussian_m6','supergaussian':'super_gaussian_m6',
             'super_gaussian':'super_gaussian_m6','Top-Hat':'top_hat','top-hat':'top_hat'}
    profile=aliases.get(profile,profile)
    if profile not in PROFILES:raise ValueError('Unknown beam profile')
    return profile

def _validate(beam_power_W,w_mm,offset_mm,angle_deg):
    if not np.isfinite(beam_power_W) or beam_power_W<0:raise ValueError('Beam power must be finite and nonnegative')
    if not np.isfinite(w_mm) or w_mm<=0:raise ValueError('Radius must be finite and positive')
    if len(offset_mm)!=2 or not np.isfinite(offset_mm).all():raise ValueError('Finite x/y offset required')
    if not np.isfinite(angle_deg) or not 0<=angle_deg<90:raise ValueError('Angle must be in [0,90) degrees')

def normalization_density(beam_power_W,w_mm,profile='gaussian',m=6):
    """Central density normal to beam, in W/mm2.

    For exp[-2(r/w)^m], C=P*m*2^(2/m)/(2*pi*w^2*Gamma(2/m)).
    m=2 is Gaussian; the study super-Gaussian uses m=6.
    """
    profile=_profile_name(profile)
    if profile=='top_hat':return beam_power_W/(math.pi*w_mm*w_mm)
    m=2 if profile=='gaussian' else m
    if m<=0:raise ValueError('Positive super-Gaussian exponent required')
    return beam_power_W*m*2**(2/m)/(2*math.pi*w_mm*w_mm*gamma(2/m))

def beam_density(x_mm,y_mm,beam_power_W=DEFAULT_BEAM_W,w_mm=12.,profile='gaussian',offset_mm=(0.,0.),angle_deg=0.):
    """Projected receiver-plane density; incidence inclines about the y axis.

    x_perp=(x-x0)*cos(theta), y_perp=y-y0. q_plane=cos(theta)*q_perp.
    Consequently the integral over an infinite receiver plane remains Pbeam.
    No additional global cos(theta) multiplier may be applied afterwards.
    """
    _validate(beam_power_W,w_mm,offset_mm,angle_deg);profile=_profile_name(profile)
    co=math.cos(math.radians(angle_deg))
    u=(np.asarray(x_mm)-offset_mm[0])*co;v=np.asarray(y_mm)-offset_mm[1]
    rr=np.sqrt(u*u+v*v)
    c=normalization_density(beam_power_W,w_mm,profile)
    if profile=='top_hat':return co*c*(rr<=w_mm)
    exponent=2 if profile=='gaussian' else 6
    return co*c*np.exp(-2*(rr/w_mm)**exponent)

@lru_cache(maxsize=8)
def _nodes(n):return leggauss(int(n))

def _rect_circle_area(rect,radius):
    """Area of intersection of an axis-aligned rectangle and centered disk."""
    x0,x1,y0,y1=rect
    lo=max(x0,-radius);hi=min(x1,radius)
    if lo>=hi or y0>=radius or y1<=-radius:return 0.
    def height(x):
        h=math.sqrt(max(0.,radius*radius-x*x))
        return max(0.,min(y1,h)-max(y0,-h))
    # Split at every point where a horizontal rectangle edge crosses the disk.
    pts=[lo,hi]
    for y in [y0,y1]:
        if abs(y)<radius:
            a=math.sqrt(radius*radius-y*y)
            pts.extend(x for x in [-a,a] if lo<x<hi)
    pts=sorted(set(pts))
    area=0.
    for a,b in zip(pts[:-1],pts[1:]):
        area+=quad(height,a,b,epsabs=1e-10,epsrel=3e-12,limit=150)[0]
    return min((x1-x0)*(y1-y0),max(0.,area))

def rectangle_power(rect_mm,beam_power_W=DEFAULT_BEAM_W,w_mm=12.,profile='gaussian',offset_mm=(0.,0.),angle_deg=0.,order=128):
    """Intercepted W in (xmin,xmax,ymin,ymax), no extra fill-factor scaling."""
    _validate(beam_power_W,w_mm,offset_mm,angle_deg);profile=_profile_name(profile)
    x0,x1,y0,y1=map(float,rect_mm)
    if not x1>x0 or not y1>y0:raise ValueError('Rectangle bounds must increase')
    co=math.cos(math.radians(angle_deg))
    # Transform to the beam-normal plane; Jacobian cancels projected cos.
    u0,u1=(x0-offset_mm[0])*co,(x1-offset_mm[0])*co
    v0,v1=y0-offset_mm[1],y1-offset_mm[1]
    if profile=='gaussian':
        fx=.5*(erf(math.sqrt(2)*u1/w_mm)-erf(math.sqrt(2)*u0/w_mm))
        fy=.5*(erf(math.sqrt(2)*v1/w_mm)-erf(math.sqrt(2)*v0/w_mm))
        return float(beam_power_W*fx*fy)
    if profile=='top_hat':
        return float(beam_power_W*_rect_circle_area((u0,u1,v0,v1),w_mm)/(math.pi*w_mm*w_mm))
    nodes,weights=_nodes(order)
    ux=(u1-u0)/2*nodes+(u0+u1)/2;vy=(v1-v0)/2*nodes+(v0+v1)/2
    rr2=ux[:,None]**2+vy[None,:]**2
    density=normalization_density(beam_power_W,w_mm,profile)*np.exp(-2*(rr2/(w_mm*w_mm))**3)
    val=(u1-u0)*(v1-v0)/4*float(weights@density@weights)
    return val

def cell_rectangles(cell_side_mm=10.,gap_mm=.3,nrows=2,ncols=2):
    """Row-major IDs; row 1 has positive y, column 1 negative x."""
    if cell_side_mm<=0 or gap_mm<0 or nrows<1 or ncols<1:raise ValueError('Invalid receiver geometry')
    out=[];pitch=cell_side_mm+gap_mm;half=cell_side_mm/2
    for row in range(nrows):
        cy=((nrows-1)/2-row)*pitch
        for col in range(ncols):
            cx=(col-(ncols-1)/2)*pitch
            out.append({'cell':row*ncols+col+1,'row':row+1,'column':col+1,'cx_mm':cx,'cy_mm':cy,
                        'bounds_mm':[cx-half,cx+half,cy-half,cy+half]})
    return out

def gaussian_cell_powers(offset_x_mm,offset_y_mm,beam_power_W=DEFAULT_BEAM_W,w_mm=12.,
                         gap_mm=.3,cell_side_mm=10.,nrows=2,ncols=2,angle_deg=0.):
    """Vectorized Gaussian reception, shape broadcast(offset_x,offset_y)+(Ncells,).

    Last axis uses row-major cell IDs from ``cell_rectangles``. The x/y offsets
    may be scalars or broadcastable NumPy arrays; all other arguments are scalar.
    This exact erf integral supports temporal pointing-jitter simulation without
    replacing a finite receiver by a local intensity sample at its centre.
    """
    bx,by=np.broadcast_arrays(np.asarray(offset_x_mm,dtype=float),np.asarray(offset_y_mm,dtype=float))
    if not np.isfinite(bx).all() or not np.isfinite(by).all():raise ValueError('Finite x/y offsets required')
    _validate(beam_power_W,w_mm,(0.,0.),angle_deg)
    bounds=np.asarray([c['bounds_mm'] for c in cell_rectangles(cell_side_mm,gap_mm,nrows,ncols)])
    co=math.cos(math.radians(angle_deg));factor=math.sqrt(2)/w_mm
    fx=.5*(erf(factor*(bounds[:,1]-bx[...,None])*co)-erf(factor*(bounds[:,0]-bx[...,None])*co))
    fy=.5*(erf(factor*(bounds[:,3]-by[...,None]))-erf(factor*(bounds[:,2]-by[...,None])))
    return beam_power_W*fx*fy

def receiver_budget(profile='gaussian',w_mm=12.,gap_mm=.3,offset_mm=(0.,0.),angle_deg=0.,
                    source_power_W=DEFAULT_SOURCE_W,chain_efficiency=DEFAULT_CHAIN_EFFICIENCY,
                    cell_side_mm=10.,nrows=2,ncols=2,order=128):
    """Partition source power into upstream loss, active, gap and outside W."""
    if not 0<chain_efficiency<=1:raise ValueError('Upstream chain efficiency must be in (0,1]')
    beam=source_power_W*chain_efficiency
    cells=cell_rectangles(cell_side_mm,gap_mm,nrows,ncols)
    pins=[rectangle_power(c['bounds_mm'],beam,w_mm,profile,offset_mm,angle_deg,order) for c in cells]
    outer=[min(c['bounds_mm'][0] for c in cells),max(c['bounds_mm'][1] for c in cells),
           min(c['bounds_mm'][2] for c in cells),max(c['bounds_mm'][3] for c in cells)]
    aperture=rectangle_power(outer,beam,w_mm,profile,offset_mm,angle_deg,order)
    active=sum(pins);gap=aperture-active;outside=beam-aperture
    if min(gap,outside)<-1e-7:raise ValueError('Optical budget violates positivity')
    if abs(gap)<1e-10:gap=0.
    if abs(outside)<1e-10:outside=0.
    row={'profile':_profile_name(profile),'source_power_W':float(source_power_W),'chain_efficiency':float(chain_efficiency),
         'beam_power_W':float(beam),'w_mm':float(w_mm),'gap_mm':float(gap_mm),'offset_x_mm':float(offset_mm[0]),
         'offset_y_mm':float(offset_mm[1]),'angle_deg':float(angle_deg),'cell_side_mm':float(cell_side_mm),
         'nrows':nrows,'ncols':ncols,'aperture_side_x_mm':outer[1]-outer[0],'aperture_side_y_mm':outer[3]-outer[2],
         'transmission_loss_W':float(source_power_W-beam),'active_power_W':float(active),'aperture_power_W':float(aperture),
         'gap_power_W':float(gap),'outside_power_W':float(outside),
         'active_fraction_of_beam':float(active/beam) if beam else None,
         'energy_residual_W':float(source_power_W-(source_power_W-beam+active+gap+outside)),
         'single_Pins_in_previously_studied_2_to16W':bool(min(pins)>=2 and max(pins)<=16)}
    row.update({f'Pin_{k+1}_W':float(v) for k,v in enumerate(pins)})
    return row

def fresnel_uncoated(angle_deg,index=3.6):
    """Diagnostic bare loss for real-index nonabsorbing interface, not AR cell."""
    theta=math.radians(angle_deg);ct=math.sqrt(1-(math.sin(theta)/index)**2);ci=math.cos(theta)
    rs=((ci-index*ct)/(ci+index*ct))**2
    rp=((index*ci-ct)/(index*ci+ct))**2
    r=.5*(rs+rp);r0=((index-1)/(index+1))**2
    return {'R_s':rs,'R_p':rp,'R_average':r,'R_normal':r0,'relative_transmission_to_normal':(1-r)/(1-r0)}


if __name__ == "__main__":
    print("Optical integration library. Run build_optical_cases.py for this study.")
