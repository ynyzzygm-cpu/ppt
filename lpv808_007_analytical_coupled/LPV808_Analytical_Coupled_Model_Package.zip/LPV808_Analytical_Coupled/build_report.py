"""Analytical opto-electro-thermal coupled single-cell and array report."""
from pathlib import Path
import json,sys,math,shutil
import numpy as np,pandas as pd
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from native_charts import ChartBook,LATIN,CJK,tag,child

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'report';OUT.mkdir(exist_ok=True)
import core_model as core
S=pd.read_csv(ROOT/'single/coupled_source_summary.csv');SI=pd.read_csv(ROOT/'single/coupled_source_iv.csv')
ISO=pd.read_csv(ROOT/'single/isothermal_grid.csv');SH=pd.read_csv(ROOT/'single/self_heating_summary.csv')
RF=pd.read_csv(ROOT/'single/temperature_reference_family.csv');SD=pd.read_csv(ROOT/'single/dynamic_step.csv');DS=pd.read_csv(ROOT/'single/dynamic_summary.csv')
A=pd.read_csv(ROOT/'array/results_summary.csv');AC=pd.read_csv(ROOT/'array/results_cells.csv');AI=pd.read_csv(ROOT/'array/representative_ivpv.csv')
AD=pd.read_csv(ROOT/'array/dynamic_timeseries.csv');AJ=json.loads((ROOT/'array/dynamic_summary.json').read_text())
J=json.loads((ROOT/'analysis/joint_analysis.json').read_text());OPT=pd.read_csv(ROOT/'optics/optical_case_summary.csv')
ES=pd.read_csv(ROOT/'analysis/single_joint_effects.csv');EA=pd.read_csv(ROOT/'analysis/array_joint_effects.csv');CFG=json.loads((ROOT/'study_config.json').read_text())
RAW=pd.read_csv(ROOT/'input/selected_007_raw.csv');SR=json.loads((ROOT/'single/single_results.json').read_text());AR=json.loads((ROOT/'array/results.json').read_text())
TL={'1S4P':'1S4P','2S2P_rows':'2S2P行分组','2S2P_columns':'2S2P列分组','2S2P_diagonals':'2S2P对角分组','4S1P':'4S1P','3S3P_rows':'3S3P行分组','3S3P_mixed':'3S3P交错分组','3S3P_balanced':'3S3P交错分组'}
TOP4=['1S4P','2S2P_rows','2S2P_columns','2S2P_diagonals','4S1P']
PL={'gaussian':'高斯','super_gaussian_m6':'六次超高斯','top_hat':'平顶'}
FL={'w_mm':'光斑半径','angle_deg':'入射角','offset':'偏移','source_power_W':'源功率','Tsink_C':'热沉温度','Rth_K_per_W':'热阻','topology':'分组'}
FLC={'w_mm':'w','angle_deg':'θ','offset':'d','source_power_W':'Ps','Tsink_C':'Ts','Rth_K_per_W':'Rth','topology':'组'}
doc=Document();sec=doc.sections[0]
sec.page_width=Cm(21);sec.page_height=Cm(29.7);sec.left_margin=Cm(2);sec.right_margin=Cm(2);sec.top_margin=Cm(1.7);sec.bottom_margin=Cm(1.6);sec.header_distance=Cm(.65);sec.footer_distance=Cm(.65);sec.different_first_page_header_footer=True
for st in doc.styles:
 if hasattr(st,'font'):
  st.font.name=LATIN;st.font.color.rgb=RGBColor(0,0,0)
  try:st._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),CJK)
  except AttributeError:pass
  for old in st._element.xpath('.//w:pBdr'):old.getparent().remove(old)
norm=doc.styles['Normal'];norm.font.size=Pt(11);norm.paragraph_format.line_spacing=1.17;norm.paragraph_format.space_after=Pt(6)
for name,size in [('Title',26),('Subtitle',13),('Heading 1',16),('Heading 2',12),('Heading 3',11)]:
 st=doc.styles[name];st.font.size=Pt(size);st.font.bold=name!='Subtitle';st.paragraph_format.keep_with_next=True;st.paragraph_format.space_before=Pt(6);st.paragraph_format.space_after=Pt(7)
doc.styles['Caption'].font.size=Pt(9.5);doc.styles['Caption'].font.color.rgb=RGBColor(0,0,0);doc.styles['Caption'].paragraph_format.space_after=Pt(6)
head=sec.header.paragraphs[0];head.text='解析模型 光束接收 光热电与阵列联合仿真'
for r in head.runs:r.font.size=Pt(8)
foot=sec.footer.paragraphs[0];foot.alignment=WD_ALIGN_PARAGRAPH.RIGHT;foot.add_run('第 ')
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');rr=OxmlElement('w:r');tt=OxmlElement('w:t');tt.text='1';rr.append(tt);fld.append(rr);foot._p.append(fld);foot.add_run(' 页')
for r in foot.runs:r.font.size=Pt(8)
doc.core_properties.title='808nm六结GaAs解析模型光热电与阵列联合仿真';doc.core_properties.subject='解析法基线 单体与阵列联合工况 端口输出与温升响应';doc.core_properties.author='';doc.core_properties.keywords='GaAs;808nm;6J;007;analytical;opto-electro-thermal;arrays'
cb=ChartBook(OUT/'chart_work');page_names=[]

def p(s='',bold=False,style=None):
 pp=doc.add_paragraph(style=style);r=pp.add_run(str(s));r.bold=bold;return pp

def note(s):
 pp=p(s)
 for r in pp.runs:r.font.size=Pt(9)
 return pp

def h(s,level=2):return doc.add_heading(s,level)

def page(s):
 doc.add_page_break();h(s,1);page_names.append(s)

def cap(s):return p(s,style='Caption')

def table(headers,rows,widths=None,size=10):
 widths=widths or [17/len(headers)]*len(headers)
 tb=doc.add_table(rows=1,cols=len(headers));tb.alignment=WD_TABLE_ALIGNMENT.CENTER;tb.autofit=False
 for j,txt in enumerate(headers):tb.rows[0].cells[j].text=str(txt)
 for vals in rows:
  for c,txt in zip(tb.add_row().cells,vals):c.text=str(txt)
 for j,w in enumerate(widths):tb.columns[j].width=Cm(w)
 borders=OxmlElement('w:tblBorders')
 for side in ['top','left','bottom','right','insideH','insideV']:
  z=OxmlElement('w:'+side);z.set(qn('w:val'),'single');z.set(qn('w:sz'),'4');z.set(qn('w:color'),'D9D9D9');borders.append(z)
 tb._tbl.tblPr.append(borders)
 for k,row in enumerate(tb.rows):
  rp=row._tr.get_or_add_trPr();rp.append(OxmlElement('w:cantSplit'))
  if k==0:rp.append(OxmlElement('w:tblHeader'))
  for j,c in enumerate(row.cells):
   c.width=Cm(widths[j]);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   tc=c._tc.get_or_add_tcPr();shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'E6EDF3' if k==0 else ('F6F8FA' if k%2 else 'FFFFFF'));tc.append(shade)
   pad=OxmlElement('w:tcMar')
   for side in ['top','bottom','left','right']:
    e=OxmlElement('w:'+side);e.set(qn('w:w'),'85');e.set(qn('w:type'),'dxa');pad.append(e)
   tc.append(pad)
   for pp in c.paragraphs:
    pp.paragraph_format.space_before=Pt(2);pp.paragraph_format.space_after=Pt(2);pp.paragraph_format.line_spacing=1.08
    pp.alignment=WD_ALIGN_PARAGRAPH.LEFT if j==0 else WD_ALIGN_PARAGRAPH.CENTER
    for r in pp.runs:r.font.size=Pt(size);r.bold=(k==0)
 p().paragraph_format.space_after=Pt(0)
 return tb

def mr(s):
 r=OxmlElement('m:r');rp=OxmlElement('m:rPr');sty=OxmlElement('m:sty');sty.set(qn('m:val'),'p');rp.append(sty);nor=OxmlElement('m:nor');nor.set(qn('m:val'),'1');rp.append(nor);r.append(rp)
 wr=OxmlElement('w:rPr');ff=OxmlElement('w:rFonts')
 for k,v in [('ascii',LATIN),('hAnsi',LATIN),('eastAsia',CJK),('cs',LATIN)]:ff.set(qn('w:'+k),v)
 wr.append(ff);sz=OxmlElement('w:sz');sz.set(qn('w:val'),'22');wr.append(sz);r.append(wr);t=OxmlElement('m:t');t.set(qn('xml:space'),'preserve');t.text=str(s);r.append(t);return r

def seq(*a):
 out=[]
 for v in a:
  if isinstance(v,list):out.extend(seq(*v))
  elif isinstance(v,str):out.append(mr(v))
  else:out.append(v)
 return out

def sub(a,b):
 z=OxmlElement('m:sSub');e=OxmlElement('m:e');e.extend(seq(a));k=OxmlElement('m:sub');k.extend(seq(b));z.extend([e,k]);return z

def sup(a,b):
 z=OxmlElement('m:sSup');e=OxmlElement('m:e');e.extend(seq(a));k=OxmlElement('m:sup');k.extend(seq(b));z.extend([e,k]);return z

def frac(a,b):
 z=OxmlElement('m:f');n=OxmlElement('m:num');n.extend(seq(a));d=OxmlElement('m:den');d.extend(seq(b));z.extend([n,d]);return z

def rad(a):
 z=OxmlElement('m:rad');pr=OxmlElement('m:radPr');no=OxmlElement('m:degHide');no.set(qn('m:val'),'1');pr.append(no);z.append(pr);z.append(OxmlElement('m:deg'));e=OxmlElement('m:e');e.extend(seq(a));z.append(e);return z

def eq(*a):
 pp=doc.add_paragraph();pp.alignment=WD_ALIGN_PARAGRAPH.CENTER;pp.paragraph_format.space_before=Pt(2);pp.paragraph_format.space_after=Pt(5)
 z=OxmlElement('m:oMath');z.extend(seq(*a));pp._p.append(z);return pp

def fmt(x,n=6):return f'{float(x):.{n}f}'

def sci(x):
 if isinstance(x,str):return '∞' if x=='infinity' else x
 if x==0:return '0'
 if abs(x)<1e-6:return f'{x:.6e}'
 return f'{x:.6f}'

def ser(name,x,y,**kw):return {'name':name,'x':np.asarray(x).tolist(),'y':np.asarray(y).tolist(),**kw}

def chart(s,xt,yt,height=7,**kw):
 return cb.add(doc,s,xt,yt,height=height,width=17,legend_size=9,tick_size=10,title_size=11,**kw)
def sampled(d,x,maxn=400):
 if len(d)<=maxn:return d
 idx=np.unique(np.r_[np.linspace(0,len(d)-1,maxn-4).round().astype(int),np.flatnonzero(d[x].duplicated(keep=False))])
 return d.iloc[idx]
def line(name,d,x,y,**kw):
 d=sampled(d,x);return ser(name,d[x],d[y],**kw)
def ar(cid,top='2S2P_rows'):return A[(A.case_id==cid)&(A.topology==top)].iloc[0]
def cells(cid,top='2S2P_rows'):
 return AC[(AC.case_id==cid)&(AC.topology==top)&(AC['mode']=='self_heated')].sort_values('cell')
def sg(cid):return S[S.case_id==cid].iloc[0]
def f(x,n=4):return f'{float(x):.{n}f}'
def sci2(x):return f'{float(x):.6e}'
def beamlabel(cid):
 for k,v in PL.items():
  if k in cid:return v+' '+cid.rsplit('_',1)[-1]
 return cid
def maps(data,nrows,ncols,power_max=16,Tmin=25,Tmax=110):
 outer=doc.add_table(rows=1,cols=2);outer.autofit=False;outer.alignment=WD_TABLE_ALIGNMENT.CENTER
 for j,(key,title,limits,palette) in enumerate([('Pin_W','每片平均接收功率 W',(0,power_max),((245,249,255),(0,75,140))),('Tj_C','每片结温 °C',(Tmin,Tmax),((255,250,236),(190,40,30)))]):
  cell=outer.cell(0,j);cell.width=Cm(8.4);cell.text=title;cell.paragraphs[0].alignment=WD_ALIGN_PARAGRAPH.CENTER
  for rr in cell.paragraphs[0].runs:rr.bold=True;rr.font.size=Pt(10)
  tt=cell.add_table(rows=nrows,cols=ncols);tt.autofit=False
  for k,row in data.reset_index(drop=True).iterrows():
   c=tt.cell(k//ncols,k%ncols);c.width=Cm(8.2/ncols);val=float(row[key]);q=float(np.clip((val-limits[0])/(limits[1]-limits[0]),0,1));rgb=np.rint(np.array(palette[0])*(1-q)+np.array(palette[1])*q).astype(int);fill=''.join(f'{x:02X}' for x in rgb)
   c.text=f'C{int(row["cell"])}\n{val:.3f}';c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   sh=OxmlElement('w:shd');sh.set(qn('w:fill'),fill);c._tc.get_or_add_tcPr().append(sh)
   for pp in c.paragraphs:
    pp.alignment=WD_ALIGN_PARAGRAPH.CENTER;pp.paragraph_format.space_before=Pt(3);pp.paragraph_format.space_after=Pt(3);pp.paragraph_format.line_spacing=1.08
    for rr in pp.runs:rr.font.size=Pt(12 if ncols==2 else 10.5);rr.font.color.rgb=RGBColor(255,255,255) if np.mean(rgb)<135 else RGBColor(0,0,0)
  bd=OxmlElement('w:tblBorders')
  for side in ['top','left','bottom','right','insideH','insideV']:
   z=OxmlElement('w:'+side);z.set(qn('w:val'),'single');z.set(qn('w:sz'),'5');z.set(qn('w:color'),'D9D9D9');bd.append(z)
  tt._tbl.tblPr.append(bd)
 bd=OxmlElement('w:tblBorders')
 for side in ['top','left','bottom','right','insideH','insideV']:
  z=OxmlElement('w:'+side);z.set(qn('w:val'),'single');z.set(qn('w:sz'),'4');z.set(qn('w:color'),'D9D9D9');bd.append(z)
 outer._tbl.tblPr.append(bd)
 note(f'颜色范围  功率0至{power_max:g} W  温度{Tmin:g}至{Tmax:g}°C  每一色块代表整片均匀单体')
 return outer

# Cover
p('解析模型联合工况研究报告',bold=True)
p('808 nm六结GaAs激光光伏电池\n光束接收 光热电与阵列联合仿真',style='Title')
p('以007号电池解析提取参数为基线',style='Subtitle')
p('本研究把激光源、传输损耗、接收光束、单体平均受光、热边界、串并联网络和外部负载放入同一条计算链，研究多种条件共同作用时最终端口的电压、电流、功率与温升。研究基线为此前Five Points解析法。')
p('主要结果',bold=True)
p(f'64组单体联合工况的端口最大功率为{f(S.Pout_W.min(),3)}至{f(S.Pout_W.max(),3)} W，结温为{f(S.Tj_C.min(),2)}至{f(S.Tj_C.max(),2)}°C。阵列完成181组网络联合求解，其中128组用于七因子完整组合比较。')
p('中心接收和偏移接收下，连接方式的功率排序发生变化。高斯B1联合工况中，1S4P约13.653 W，而4S1P约6.021 W；中心B0中4S1P略高。该差异由每片接收功率、实际电工作点和自热共同产生。')
p('功率与偏移同时阶跃时，激光源由32 W提高到48 W，固定负载阵列端口输出仍可能下降：行分组约11.320→10.143 W，列分组约11.320→6.577 W。仅看光源功率不足以判断接收端输出。')
table(['研究约束','执行方式'],[['单体内部辐照','每片一个总接收功率和平均辐照强度；电热模型为空间均匀单体'],['阵列辐照差异','仅以不同单体之间的接收功率差异表示'],['基线与波长','LPV-808-164-007  808 nm  每片6结  1 cm²'],['结果性质','基准8 W曲线经实测校核；温度和多功率结果为条件性预测'],['报告日期','2026年11月27日']],[5,12],10.3)
note('正文、表格、公式及原生可编辑图表显式设置英文与数字Times New Roman、中文宋体。字体文件未嵌入。所有热图均以整片单体为一个色块。')

page('1 解析法基线与实测回代')
p('固定此前解析法的五个端口参数，保留原始007实测扫描。短路端局部回归与开路端局部求导得到的参数用于完整单二极管方程。2018年综述式（2）采用此前已披露的量纲一致商式修正，本研究不重新调整解析窗口。')
table(['参数','解析法数值'],[[{'Iph_A':'Iph (A)','I0_A':'I0 (A)','a_V':'a (V)','Rs_ohm':'Rs (Ω)','Rsh_ohm':'Rsh (Ω)'}[k],sci2(core.BASE[k]) if k=='I0_A' else f(core.BASE[k],9)] for k in core.PARAMETER_KEYS],[6,11],10.5)
v=RAW.voltage_V.to_numpy();ii=RAW.current_output_A.to_numpy();mask=(v>0)&(ii>0);x=np.linspace(0,core.BASE_FEATURES['Voc_V'],401)
chart([ser('解析参考曲线',x,core.current_from_parameters(x,core.BASE),color='0072B2'),ser('007实测',v[mask],ii[mask],color='222222',markers=True,marker_style='circle',marker_size=3,width=.5)],'端口电压 (V)','输出电流 (A)',height=7.5,x_min=0,x_max=7.2,y_min=0,y_max=.8)
cap('图1  解析参考模型与70个严格发电区实测点  仅此参考条件具有直接测试对照')
p('参考模型连续最大功率4.441240965 W，电压6.268163404 V，电流0.708539436 A；相对离散实测4.438791362 W偏差+0.05519%。同70点电流RMSE为4.19584 mA，NRMSE为0.57099%，MAE为3.14441 mA。')
p('25°C为测试环境记录，实际结温未测。因此以下Tref=40°C是条件参考温度；它保持原五参数数值不变，不把原曲线当成已知25°C结温曲线。')

page('2 联合求解链与功率边界')
eq(sub('P','source'),' → ',sub('P','beam'),' → {',sub('P','in,i'),'} → {',sub('T','i'),',',sub('V','i'),',',sub('I','i'),'} → ',sub('P','port'))
p('光学先确定各片接收总功率Pi；电路和热方程随后同时求解。负载改变各片ViIi，热源随之改变；温度又通过二极管参数反作用于端口曲线。一次组合计算包含全部这些反馈。')
eq('I = ',sub('I','ph'),' − ',sub('I','0'),' {exp[',frac(['V+I',sub('R','s')],'a'),']−1} − ',frac(['V+I',sub('R','s')],sub('R','sh')))
eq(sub('Q','i'),' = ',sub('η','h'),sub('P','in,i'),' − ',sub('V','i'),sub('I','i'))
eq(sub('C','i'),frac(['d',sub('T','i')],'dt'),' = ',sub('Q','i'),' − ',frac([sub('T','i'),'−',sub('T','sink')],sub('R','th,i')),' − ',sub('Σ','j'),sub('g','ij'),'(',sub('T','i'),'−',sub('T','j'),')')
eq(sub('V','port'),' = U − ',sub('I','port'),sub('R','wire'),'     ',sub('P','port'),' = ',sub('V','port'),sub('I','port'))
p('上游传输损耗、接收面外溢和间隙未接收功率在光学端分账。ηh=0.9表示单体控制体保留的光能比例，用于热平衡；它不同于上游传输效率，不能再次乘到已经由入射光功率标定的Iph上。')
p('主阵列模型把公共互联电阻的I²R热量散到外部环境，不返回单体。间隙或外溢光若实际加热机壳和热沉，其影响尚未加入固定热沉边界；这类装置需增加机壳或热沉热节点。')
p('温度扫描图属于给定结温的等温结果；自热稳态曲线在每个电压点重新求热平衡；瞬态则以当前温度求电网络，再推进热状态。三者使用相同基线，边界条件不同。')

page('3 温度迁移与热锚定假设')
eq('a(T) = ',sub('a','0'),frac('T+273.15','40+273.15'))
eq(sub('I','ph'),' = ',sub('I','ph,0'),frac(sub('P','in'),'8'),' [1+',sub('α','I'),' (T−40)]')
eq(sub('V','oc,8W'),'(T) = ',sub('V','oc,0'),' + ',sub('β','Voc'),' (T−40)')
eq(sub('I','0'),'(T) = ',frac([sub('I','ph,8W'),'(T)−',sub('V','oc,8W'),'(T)/',sub('R','sh')],['exp[',sub('V','oc,8W'),'(T)/a(T)]−1']))
table(['量','主情景设置','依据与性质'],[['Tref','40°C','未知实际结温的条件参考，非测试结温'],['βVoc','−0.00815 V/K','Gou等六结808 nm器件文献迁移，非007实测'],['αI 与 Rs温系','0 与 0','缺少目标器件多温数据时的固定情景'],['Rsh','758.867831 Ω恒定','解析基线保持；温度关系未标定'],['ηh','0.9','净保留光能比例假设'],['Cth','0.3 J/K每片','动态主情景；另比较0.1与0.5'],['Rth参考','5.437227322 K/W','由下式重算；联合工况另用3或8']],[3.4,4.5,9.1],9.8)
eq(sub('R','th,ref'),' = ',frac('40−25',['0.9×8−4.441240965']),' = 5.437227322 K/W')
p('这一锚只保证8 W、25°C热沉、理想MPPT条件下回到Tj=40°C及解析参考最大功率。整条自热I–V的温度随工作点变化，因此不会处处等于参考等温曲线。0至180°C是数值情景域，不是已认证器件安全工作范围。')

page('4 光斑与入射接收的守恒模型')
p('各片接收功率由光束在有源面积上的积分获得，随后作为一个标量送入均匀单体模型。光学积分节点不作为电学或热学微单元。主几何为10 mm×10 mm单体，间隙0.3 mm；阵列为2×2与3×3。')
eq(sub('q','⊥'),'(r) = C exp[−2',sup('(r/w)','m'),']     C = ',frac([sub('P','beam'),' m ',sup('2','2/m')],['2π',sup('w','2'),' Γ(2/m)']))
eq(sub('q','plane'),'(x,y) = cosθ ',sub('q','⊥'),'((x−',sub('x','0'),')cosθ,y−',sub('y','0'),')')
eq(sub('P','in,i'),' = ',sub('∫∫','Ai'),sub('q','plane'),'(x,y) dA     ',sub('G','mean,i'),' = ',frac(sub('P','in,i'),sub('A','i')))
p('高斯取m=2，超高斯取m=6；平顶使用半径w内的常量Pbeam/(πw²)。这里w是exp[−2(r/w)^m]中的明确定义半径。倾斜光斑投影只含一次cosθ，整个无限接收平面总功率保持Pbeam。')
import importlib.util
spec=importlib.util.spec_from_file_location('beam_report',ROOT/'optics/beam_integrals.py');beam=importlib.util.module_from_spec(spec);spec.loader.exec_module(beam)
xx=np.linspace(-25,25,401);ss=[]
for k,name in PL.items():ss.append(ser(name,xx,100*beam.beam_density(xx,0,40*CFG['source_transmission']['eta_chain_product'],12,k)))
cc=chart(ss,'光束接收面横坐标 (mm)','光束辐照强度 (W/cm²)',height=7,x_min=-25,x_max=25,y_min=0,y_max=18)
cc.category_axis.crosses_at=-25
cap('图2  相同源功率40 W与w=12 mm的外部光束截面  用于接收积分，不代表片内电热分布')
p('主模型只计算几何入射角效应。表面抗反射膜的相对角响应缺少实测，不额外施加裸GaAs菲涅耳反射系数；也不再乘全局填充因子，以免与有源面积积分重复扣减。')

page('5 联合工况设计与输出定义')
table(['因素','单体64组的两水平','阵列64组光学热边界的两水平'],[['光斑','高斯 w=5/8 mm','高斯 w=12/18 mm'],['入射角','0/40°','0/40°'],['中心偏移','(0,0)/(2,2) mm','(0,0)/(4,4) mm'],['源功率','12/20 W','32/48 W'],['热沉温度','25/45°C','25/45°C'],['单体热阻','3/8 K/W','3/8 K/W'],['电连接','单体理想MPPT及固定负载对照','行与列2S2P各一套，合计128个网络']],[3.4,6.1,7.5],10)
p('代表工况另比较高斯、六次超高斯和平顶光束，每种光束下均计算5种四片连接，共45个网络；九片阵列追加4组联合工况与2种3S3P分组，共8个网络。总计181个阵列网络。')
table(['代表边界','w / mm','角度 / °','偏移 / mm','Ps / W','Ts / °C','Rth / K/W'],[['B0',12,0,'0,0',40,25,f(core.DEFAULT_CONFIG['Rth_K_per_W'],3)],['B1',12,40,'4,4',48,45,8],['B2',18,40,'4,4',48,25,3]],[2.6,2.2,2.2,2.7,2.2,2.4,2.7],9.5)
p('B2同时扩宽光束并改善散热；它用于综合方案比较，不能把B1到B2的变化单独归因于光斑半径。全因子组合则用于分解平均主效应与二阶交互。')
p('上游效率按ηfiber=0.98、ηoptics=0.96、ηpath=0.96逐级计算，乘积0.903168，均为工程情景。报告同时给出ηcell=Pport/ΣPin与ηsource=Pport/Psource，避免把光学截获改善误当成单体本征转换效率提升。')
p('阵列输出均为所有单体处于正电压、非负发电电流的共同支撑域内的端口最大功率。主模型未引入未经测量的反偏击穿或旁路二极管参数。')

page('6 温度与接收功率的等温基础结果')
ss=[]
for t,g in ISO.groupby('Tj_C'):ss.append(line(f'Tj={t:g}°C',g.sort_values('Pin_W'),'Pin_W','Pmpp_W',markers=True,marker_size=4))
chart(ss,'单体接收光功率 (W)','等温最大输出功率 (W)',height=8,x_min=0,x_max=17,y_min=0,y_max=10)
cap('图3  25个温度与接收功率组合的等温MPP  结温作为给定条件')
table(['Tj / °C','Pin=4 W Pmax','Pin=8 W Pmax','Pin=12 W Pmax','Pin=16 W Pmax'],[[int(t)]+[f(ISO[(ISO.Tj_C==t)&(ISO.Pin_W==pw)].iloc[0].Pmpp_W,4) for pw in [4,8,12,16]] for t in [20,40,60,80,100]],[3,3.5,3.5,3.5,3.5],10)
p('这些曲线给出后续热反馈的电学关系，而不是把每条曲线单独当作最终系统输出。Iph在主情景下与接收功率线性变化，I0与a随温度迁移；串联电阻使高功率下的功率增量逐渐偏离简单比例。')
p('温度响应采用从另一只六结GaAs器件迁移的Voc系数。当前007没有多温实测曲线，等温结果还需要独立实验验证；参考0.571%的NRMSE仅适用于原8 W扫描。')

page('7 功率与散热共同作用的自热端口结果')
sm=SH[SH['mode']=='mpp'];ss=[];tt=[]
for (ts,rt),g in sm.groupby(['T_sink_C','Rth_K_per_W']):
 g=g.sort_values('Pin_W');name=f'Ts{ts:g}°C Rth{rt:g}K/W';ss.append(line(name,g,'Pin_W','Pout_W',markers=True));tt.append(line(name,g,'Pin_W','Tj_C',markers=True))
chart(ss,'单体接收功率 (W)','自热稳态输出功率 (W)',height=7.6,x_min=3,x_max=17,y_min=0,y_max=10)
cap('图4  Pin Tsink Rth联合求解的端口功率  每个点都重新求热平衡')
chart(tt,'单体接收功率 (W)','MPP结温 (°C)',height=7.6,x_min=3,x_max=17,y_min=20,y_max=110)
cap('图5  与图4相同工作点的结温  热沉与热阻共同改变高功率收益')
p('相同接收功率下，更高热沉温度或更大热阻提高结温，反馈降低输出。最终电功率与温度应成对评价，不能从等温功率曲线单独推断自热工作点。')

page('8 单体光源到端口的联合工况结果')
sel=['S000','S007','S018','S025','S038','S045','S056','S063']
table(['工况','Ps w θ 偏移','Ts Rth','Pin / W','Pout / W','Tj / °C','ηsrc / %'],[[cid,f"{sg(cid).source_power_W:g} {sg(cid).w_mm:g} {sg(cid).angle_deg:g} ({sg(cid).offset_x_mm:g},{sg(cid).offset_y_mm:g})",f"{sg(cid).Tsink_C:g} {sg(cid).Rth_K_per_W:g}",f(sg(cid).Pin_W,3),f(sg(cid).Pout_W,3),f(sg(cid).Tj_C,2),f(sg(cid).eta_source_percent,2)] for cid in sel],[2,4.4,2.2,2.1,2.1,2.1,2.1],9.4)
cap('表1  8个代表联合工况  Ps为W  w及偏移为mm  θ为度  Ts为°C  Rth为K/W')
note('单体联合工况的接收功率最高16.457 W，略超等温展示网格16 W上限；全部新功率及温度结果仍属于条件预测。')
p('S007和S063使用相同20 W源功率、45°C热沉与8 K/W热阻，但光斑、角度和偏移同时变化：端口输出约8.150 W和4.397 W，结温约98.29°C和69.64°C。更低温度在这里部分来自接收功率变少，不能单独解释为散热改善。')
e=ES[ES.order==2].sort_values('averaged_DID_4beta',key=abs,ascending=False).head(5)
table(['二阶组合','平均差中之差 / W'],[[' × '.join(FL[z] for z in row.factors.split(' x ')),f(row.averaged_DID_4beta,5)] for _,row in e.iterrows()],[11.5,5.5],10)
p('二阶量按完整64组的±1编码计算4βAB，等于平均差中之差；主效应为2βA。它们是确定性仿真对比量，不附加统计显著性或实验置信区间。结果显示光斑尺寸会改变增加源功率获得的电输出增量。')

page('9 联合单体工况的完整端口曲线')
ids=['S000','S007','S056','S063'];s1=[];s2=[]
for cid in ids:
 g=SI[SI.case_id==cid];s1.append(line(cid,g,'V_V','I_A'));s2.append(line(cid,g,'V_V','Pout_W'))
chart(s1,'端口电压 (V)','输出电流 (A)',height=7.8,x_min=0,x_max=7.5,y_min=0,y_max=1.7)
cap('图6  多因素同时变化的单体自热稳态I–V  工况详见表1')
chart(s2,'端口电压 (V)','输出功率 (W)',height=7.8,x_min=0,x_max=7.5,y_min=0,y_max=10)
cap('图7  对应P–V  曲线上每个电压点分别求温度与电流')
p('同一条曲线在开路、短路和MPP处的发热不同，因此结温并非常量。这里的自热I–V与冻结在MPP温度的等温I–V具有不同含义。比较最大功率时使用前者的实际端口曲线。')

page('10 端到端损耗与实际负载的耦合')
load=pd.read_csv(ROOT/'single/fixed_load_sweep.csv');ss=[]
for rt in [3,8]:
 for mode,name in [('mpp','理想MPPT'),('resistor','固定8.8466 Ω')]:
  g=load[(load.T_sink_C==25)&(load.Rth_K_per_W==rt)&(load['mode']==mode)].sort_values('Pin_W')
  ss.append(line(f'{name} Rth{rt}',g,'Pin_W','Pout_W'))
chart(ss,'单体接收光功率 (W)','自热输出功率 (W)',height=8,x_min=1,x_max=17,y_min=0,y_max=10)
cap('图8  Pin 负载与热阻共同决定输出  Ts=25°C  固定电阻与理想MPPT对照')
table(['工况','理想MPPT输出 W','固定8.8466 Ω输出 W','MPPT结温 °C','固定负载结温 °C'],[[cid,f(sg(cid).Pout_W,4),f(sg(cid).fixed_load_Pout_W,4),f(sg(cid).Tj_C,3),f(sg(cid).fixed_load_Tj_C,3)] for cid in ['S000','S007','S056','S063']],[2.6,3.6,3.6,3.6,3.6],9.7)
note('本页负载对照表沿用表1各工况自身的Ts与Rth；上图单独固定Ts=25°C，两者边界明确区分。')
p('原参考最佳负载约8.8466 Ω，接收功率和温度改变后不再保证最佳。固定电阻的电输出较低时，留在单体的热源可能变大，进一步改变温度和输出；这就是负载与热边界的联合反馈。')
p('ηsource包含光学截获和传输损耗，ηcell仅以已接收光功率归一化。对于S063，较低的源端效率主要与光束截获有关；不能把全部损失归到电池内部电阻。')

page('11 未知参考结温对联合预测的影响')
ss=[]
for tr,g in RF[(RF['mode']=='mpp')&(RF.T_sink_C==25)].groupby('T_ref_C'):
 g=g.sort_values('Pin_W');ss.append(line(f'Tref={tr:g}°C',g,'Pin_W','Pout_W',markers=True))
chart(ss,'单体接收功率 (W)','自热最大输出功率 (W)',height=8.5,x_min=1,x_max=17,y_min=0,y_max=10)
cap('图9  三个条件参考温度族  各族均以同一8 W原曲线和25°C热沉重新锚定')
table(['Tref / °C','重锚Rth / K/W','8 W参考Pout / W'],[[tr,f((tr-25)/(.9*8-core.BASE_FEATURES['Pmpp_W']),5),f(core.BASE_FEATURES['Pmpp_W'],6)] for tr in [25,40,55]],[4,6,7],10.5)
p('三族在参考点重合是构造条件，并非热模型得到新的独立验证。偏离参考功率后，未知Tref及其对应热阻会使预测产生差异。因此多功率、多结温测试是把条件模型变成实物预测模型的必要约束。')
p('主联合工况的3与8 K/W属于独立设计热边界，不等同于每个参考族的锚定热阻。使用温度族时需保持该族自身一致的参考温度、温度迁移和热锚定，不能只替换温度标签。')

page('12 阵列电网络与共同发电支撑域')
p('每个外部单体包含六个垂直串联结。四片阵列比较1S4P、行分组2S2P、列分组2S2P、对角2S2P与4S1P。每串支路电流相同，并联支路共用内部母线电压U。')
eq(sub('Σ','i∈串k'),sub('V','i'),'(',sub('I','k'),',',sub('T','i'),',',sub('P','in,i'),') = U     ',sub('I','port'),' = ',sub('Σ','k'),sub('I','k'))
eq('[diag(1/',sub('R','th'),')+L(g)] (T−',sub('T','sink'),') = ',sub('η','h'),' P − V ⊙ I')
eq(sub('P','port'),' = (U−',sub('I','port'),sub('R','wire'),')',sub('I','port'))
table(['四片分组','一基编号'],[['1S4P','[1] [2] [3] [4]'],['2S2P行分组','[1,2] [3,4]'],['2S2P列分组','[1,3] [2,4]'],['2S2P对角分组','[1,4] [2,3]'],['4S1P','[1,2,3,4]']],[6,11],10.5)
p('热导矩阵L连接几何相邻单体，主横向热导g=0.03 W/K。每片热阻由工况给出，互联公共串联电阻0.02 Ω。阵列优化时求的是实际端口功率，而非各片单独MPP功率的求和。')
p('模型只接受所有单体Vi≥0、所有支路Ik≥0且Vport≥0的解。强失配串联可能使可用曲线从正电压才开始，并联共同支撑域的高端也未必达到真实阵列开路。图中仅绘制这个已定义范围，不补画未知反偏或旁路区段。')
p('本次181组最优点均在共同支撑域内部。以17点初始母线网格搜索、局部细化，并对代表情况用65点复核。这是域内数值搜索，不是对未知反偏全域GMPP的证明。')

page('13 阵列接收与温度的整片热图')
for b in ['B0','B1','B2']:
 cid='R_gaussian_'+b;rr=ar(cid)
 h(f'高斯{b} 行分组2S2P')
 maps(cells(cid),2,2)
 note(f'Ps={rr.source_power_W:g} W  w={rr.w_mm:g} mm  θ={rr.angle_deg:g}°  偏移({rr.offset_x_mm:g},{rr.offset_y_mm:g}) mm  Ts={rr.Tsink_C:g}°C  Rth={rr.Rth_K_per_W:.3f} K/W  Pport={rr.Pport_W:.4f} W')
p('C1 C2为上排，C3 C4为下排。每个单体面积1 cm²，因此各片Pin的W数值也等于该片平均辐照强度的W/cm²数值。热图只显示单体之间的差异，每片内部不作空间分辨。')
p('B1中最强受光片不一定以独立MPP运行，串联支路电流和温度相互约束。B2的温降同时受较低热沉、更小热阻以及光学截获变化影响。')

page('14 连接方式在联合工况下的功率排序')
ss=[]
for b in ['B0','B1','B2']:
 vals=[ar('R_gaussian_'+b,k).Pport_W for k in TOP4];ss.append({'name':'高斯'+b,'y':vals})
cb.add(doc,ss,'阵列连接','支撑域最大端口功率 (W)',height=8,width=17,kind='column',categories=['1S4P','2S2P行','2S2P列','2S2P对角','4S1P'],legend=True,y_min=0,y_max=20,tick_size=10,legend_size=9)
cap('图10  相同解析单体在三种联合边界下的拓扑结果  B0 B1 B2定义见第5节')
table(['拓扑','B0 Pout W','B1 Pout W','B2 Pout W','B1 Tmax °C'],[[TL[k]]+[f(ar('R_gaussian_'+b,k).Pport_W,4) for b in ['B0','B1','B2']]+[f(ar('R_gaussian_B1',k).Tj_max_C,3)] for k in TOP4],[4.3,3.1,3.1,3.1,3.4],9.8)
p('B0各片受光相同，串联较多时公共互联电阻中的电流较小，4S1P略有优势。B1存在明显片间受光差异，1S4P容许各片提供不同电流，串联限制减弱，端口输出显著高于4S1P。')
p('这不是单独改变串并联数量的结论：光束分布、斜投影、偏移及自热决定各片可提供的电流和电压，连接方式再决定它们如何共同形成端口输出。')

page('15 联合阵列端口曲线与热反馈')
ss=[]
for k in TOP4:
 g=AI[(AI.case_id=='R_gaussian_B1')&(AI.topology==k)&(AI['mode']=='self_heated')]
 ss.append(line(TL[k],g,'Vport_V','Pport_W'))
chart(ss,'实际端口电压 (V)','端口功率 (W)',height=7.8,x_min=0,x_max=30,y_min=0,y_max=16)
cap('图11  高斯B1五种拓扑的支撑域P–V  各线仅在所有单体可发电的范围内出现')
ss=[]
for mode,name in [('self_heated','联合热稳态'),('isothermal40C','固定40°C等温')]:
 g=AI[(AI.case_id=='R_gaussian_B1')&(AI.topology=='2S2P_rows')&(AI['mode']==mode)]
 ss.append(line(name,g,'Vport_V','Pport_W'))
chart(ss,'实际端口电压 (V)','行分组端口功率 (W)',height=7.8,x_min=5,x_max=15,y_min=0,y_max=14)
cap('图12  相同光学与拓扑下的等温及联合热稳态结果  后者含45°C热沉与8 K/W热阻')
p('高斯B1行分组支撑端口电压约6.502至13.176 V。支撑区间端点不是模型已求得的真正短路和开路端点，因此不从这个截取范围伪造Isc、Voc或填充因子。')

page('16 光斑类型与系统边界的联合影响')
ss=[]
for profile,name in PL.items():
 ss.append({'name':name,'y':[ar('R_'+profile+'_'+b).Pport_W for b in ['B0','B1','B2']]})
cb.add(doc,ss,'联合工况','行分组端口功率 (W)',height=8,width=17,kind='column',categories=['B0中心','B1偏移高温','B2扩斑强散热'],y_min=0,y_max=20,tick_size=10,legend_size=9)
cap('图13  三种光斑与三组联合边界下的行分组输出  不仅比较光斑形状')
table(['光束及边界','接收功率 W','Pport W','ηsource %','Tmax °C'],[[PL[profile]+' '+b,f(ar('R_'+profile+'_'+b).Pin_total_W,3),f(ar('R_'+profile+'_'+b).Pport_W,3),f(ar('R_'+profile+'_'+b).end_to_end_efficiency_percent,2),f(ar('R_'+profile+'_'+b).Tj_max_C,2)] for profile in PL for b in ['B0','B1','B2']],[5.4,2.9,2.9,2.9,2.9],9.6)
p('六次超高斯在B0与B1行分组中均高于本组高斯结果，但在B2仍须权衡接收率和温度。平顶B2各片接收较接近，串并联差异随之减弱；宽光束仍有较多外溢，不能只以均匀性判断源端效率。')

page('17 完整组合中的二阶交互')
wod=pd.read_csv(ROOT/'analysis/array_width_offset_response.csv');ss=[]
for off,g in wod.groupby('offset_level_mm'):
 ss.append(line(f'偏移({off:g},{off:g}) mm',g.sort_values('w_mm'),'w_mm','Pport_W',markers=True,marker_size=5))
chart(ss,'光斑半径w (mm)','平均端口功率 (W)',height=7.8,x_min=11,x_max=19,y_min=0,y_max=20)
cap('图14  128组联合网络中光斑与偏移的二阶响应  其余因素及两分组均取平均')
eq(sub('β','AB'),' = mean(y ',sub('x','A'),sub('x','B'),')     ',sub('Δ','AB'),' = 4',sub('β','AB'))
e=EA[EA.order==2].sort_values('averaged_DID_4beta',key=abs,ascending=False).head(7)
table(['二阶组合','平均差中之差 W'],[[' × '.join(FL[z] for z in row.factors.split(' x ')),f(row.averaged_DID_4beta,5)] for _,row in e.iterrows()],[11.5,5.5],10)
p('光斑与偏移的平均差中之差约+4.2070 W：扩大光斑虽然降低平均截获输出，但会减轻偏移引起的损失。这种折中无法由“光斑越小越好”或“辐照越均匀越好”的单因素结论替代。')
p('表内为4β差中之差，配套数据同时保留DOE常用2β交互效应，两个量相差2倍。它们是给定因素范围内的确定性模型对比，不代表实验显著性，也不外推为所有功率和光束范围的通用规律。')

page('18 分组同时改变电工作点与温度')
cid='R_gaussian_B1';ss=[]
for k in ['1S4P','2S2P_rows','2S2P_columns','4S1P']:
 g=cells(cid,k);ss.append(ser(TL[k],g.cell,g.Tj_C,markers=True,marker_size=4))
chart(ss,'单体编号','支撑域最优工作点结温 (°C)',height=8,x_min=1,x_max=4,y_min=40,y_max=110,x_major=1)
cap('图15  接收功率分布完全相同，分组仍通过实际ViIi改变温度')
table(['分组','单体','Pin W','V V','I A','电功率 W','Tj °C'],[[TL[k].replace('2S2P',''),int(r.cell),f(r.Pin_W,3),f(r.Vcell_V,3),f(r.Icell_A,4),f(r.Pcell_W,3),f(r.Tj_C,2)] for k in ['2S2P_rows','2S2P_columns'] for _,r in cells(cid,k).iterrows()],[3.2,1.2,2.4,2.4,2.4,2.7,2.7],9.5)
r1=ar(cid);r2=ar(cid,'2S2P_columns')
p(f'行分组同温度独立单体MPP电上界为{r1.same_T_independent_MPP_upper_bound_W:.4f} W，实际端口为{r1.Pport_W:.4f} W；列分组分别为{r2.same_T_independent_MPP_upper_bound_W:.4f} W与{r2.Pport_W:.4f} W。上界在各自阵列工作温度下计算，用于诊断电失配与线损。')
p('把各片独立自热MPP相加会改变各片温度和电边界，不能当作这个实际阵列的输出，也不作为严格同温度上界。')

page('19 九片阵列中的光热电联合结果')
p('九片单体仍各自均匀，采用3×3几何。行分组为[1,2,3]、[4,5,6]、[7,8,9]；交错分组为[1,5,9]、[2,6,7]、[3,4,8]。交错只是指定连接，不表示已经求得最优平衡。')
nine=A[A.family=='nine_cell']
table(['工况','光束与输入边界','行分组 W','交错分组 W'],[[cid,('高斯' if cid in ['N0','N1'] else '六次超高斯' if cid=='N2' else '平顶')+' '+f"{ar(cid,'3S3P_rows').source_power_W:g}W / θ{ar(cid,'3S3P_rows').angle_deg:g}° / w{ar(cid,'3S3P_rows').w_mm:g}mm",f(ar(cid,'3S3P_rows').Pport_W,4),f(nine[(nine.case_id==cid)&(nine.topology.str.contains('mixed|balanced'))].iloc[0].Pport_W,4)] for cid in ['N0','N1','N2','N3']],[2,7.4,3.8,3.8],10)
maps(cells('N2','3S3P_rows'),3,3,Tmax=65)
cap('图16  九片N2行分组的整片接收功率与结温  偏移(4,4) mm  40°  96 W源  Ts25°C Rth3 K/W')
p('N2行分组约26.5863 W，交错分组约21.4868 W；N3平顶的两分组几乎相同。连接优劣依赖片间功率分布与热状态，不由分组名称决定。')
p('九片与四片使用不同面积和源功率，不能把绝对输出功率差解释为纯规模收益。比较效率时应同时报告Psource、ΣPin、有效面积和每片最高温度。')

page('20 单体功率阶跃的电热响应')
d=SD[np.isclose(SD.Cth_J_per_K,.3)];s1=[];s2=[]
for mode,name in [('mpp','理想MPPT'),('resistor','固定8.8466 Ω')]:
 g=d[d['mode']==mode];s1.append(line(name,g,'t_s','Pout_W'));s2.append(line(name,g,'t_s','Tj_C'))
chart(s1,'时间 (s)','单体端口功率 (W)',height=6.5,x_min=0,x_max=10,y_min=0,y_max=7.2)
cap('图17  单体接收功率4→12 W阶跃  Cth=0.3 J/K  Ts25°C  参考热阻')
chart(s2,'时间 (s)','单体结温 (°C)',height=6.5,x_min=0,x_max=10,y_min=25,y_max=60)
cap('图18  与图17相同条件  温度连续，端口电功率允许瞬时跳变')
table(['负载','Cth J/K','热t63 / s','最终功率 W','最终结温 °C'],[['MPPT' if r['mode']=='mpp' else '固定电阻',r.Cth_J_per_K,f(r.t63_thermal_s,4),f(r.final_steady_Pout_W,4),f(r.final_steady_Tj_C,3)] for _,r in DS.iterrows()],[4.2,3.2,3.2,3.2,3.2],9.5)
p('本节作为热机制对照。下一节把源功率与指向偏移同时改变，并在每个热状态上重新求实际阵列负载点；热响应时间不被解释为电信号带宽。')

page('21 源功率与偏移同时阶跃的阵列输出')
s1=[];s2=[]
for k in ['2S2P_rows','2S2P_columns']:
 g=AD[(AD.topology==k)&(AD.cell==1)]
 s1.append(line(TL[k],g,'time_s','Pport_W'))
 for cell in range(1,5):
  gg=AD[(AD.topology==k)&(AD.cell==cell)];s2.append(line(('行' if k=='2S2P_rows' else '列')+f'C{cell}',gg,'time_s','Tj_C'))
chart(s1,'阶跃后时间 (s)','固定负载端口功率 (W)',height=7.6,x_min=0,x_max=12,y_min=5,y_max=12)
cap('图19  t=0源32→48 W且偏移(0,0)→(4,4) mm  实际电阻约14.167 Ω全程固定')
chart(s2,'阶跃后时间 (s)','各片结温 (°C)',height=7.6,x_min=0,x_max=12,y_min=25,y_max=70)
cap('图20  相同动态输入的各片温升  w12 mm  40°  Ts25°C  每片Cth0.3 J/K')
p('初始受光各片相同，两个分组均输出约11.31965 W。偏移后接收总功率由20.29810 W升到26.19758 W，但分配更不均匀：行分组最终10.14261 W，列分组6.57708 W。增加接收总光功率仍不足以抵消电失配与负载约束。')
p('两组温度2%收敛时间约5.60与5.75 s，全程保持已定义支撑域。固定负载热Jacobian最大实部约−0.61249与−0.61270 s⁻¹；这一局部热稳定结论不扩展为未建模MPPT控制器的稳定性。')

page('22 光源到电端口的统一能量分账')
r=ar('R_gaussian_B1');terms=[('上游传输',r.fiber_loss_W+r.optics_loss_W+r.path_loss_W),('阵列外溢',r.outside_power_W),('间隙未接收',r.gap_power_W),('单体光外逸',r.optical_unretained_W),('散至热沉',r.heat_to_sink_total_W),('外部互联热',r.wire_loss_W),('端口电输出',r.Pport_W)]
cb.add(doc,[{'name':'功率分账','y':[x[1] for x in terms],'color':'0072B2'}],'能量去向','功率 (W)',height=7,width=17,kind='column',categories=[x[0] for x in terms],legend=False,y_min=0,y_max=20,tick_size=9,title_size=11)
cap('图21  高斯B1行分组的源端48 W能量分账  每项只计一次')
table(['能量去向','功率 W','占源功率 %','控制边界'],[[name,f(val,6),f(100*val/r.source_power_W,3),desc] for (name,val),desc in zip(terms,['按三级效率依次扣减','有源阵列外包络之外','外包络内的非有源间隙','(1−ηh)ΣPin','Σ(Ti−Ts)/Rth','Iport²Rwire散到环境','Vport Iport'])],[4.4,3.2,3.3,6.1],9.8)
p(f'分账之和为{sum(x[1] for x in terms):.9f} W，端口输出约{r.Pport_W:.6f} W。横向导热在单体之间转移能量，总和为零；稳态总账中不再把横向流量作为额外损耗。')
p('实际装置若由间隙光照、底板或互联加热改变热沉温度，固定Ts边界会低估系统温升，需要把散热器和机壳加入控制体。ηh也应通过吸收、反射、透射与外逸发光测量进一步约束。')

page('23 数值验证与结果可信度')
table(['验证层','独立检查数','主要独立方法与结果'],[['参考模型',72,'原始二极管方程与Brent求根；解析参数逐值保持'],['光学接收',510,'自适应或几何积分；77阵列64单体2动态输入'],['单体扩展',54,'联合工作点双层Brent及热能积分复核'],['阵列稳态',101,'全部181网络原方程重构；10选点独立电热求根'],['阵列动态',22,'原始电网络加DOP853独立积分；热稳定矩阵'],['合计',759,'全部通过；数值复核不等于新工况实验验证']],[4,3,10],10.3)
p('光学逐片独立积分最大差约2.26×10⁻¹² W。181个最优网络的最大电平衡残差约3.46×10⁻¹¹ W、热残差约1.09×10⁻¹⁰ W、源端能量残差约9.39×10⁻¹³ W。')
p('代表曲线共7290状态，端点附近残差比最优点略大，最大热残差约1.59×10⁻⁸ W、电平衡约6.71×10⁻⁹ W。17与65点初网格复核的域内最优功率差小于3.24×10⁻¹¹ W。')
p('阵列动态独立积分与原RK45解的最大温差约7.24×10⁻⁹ K；逐片Simpson热能积分残差不超过9.08×10⁻⁸ J。单体动态另用两种采样步长与Richardson校正核对储能变化。')
p('上述小残差说明方程实现、守恒及数值求解一致，不能据此宣称真实器件具备相同精度。温度系数、光学效率、Rth、Cth与热接触尚未在007实物上辨识。')
p('严格区分三层证据：原8 W扫描的电流重建误差；新工况方程求解的数值一致性；未来多工况测量带来的预测精度。当前仅前两层已经具备。')

page('24 约束温度下的联合方案选择')
p('以下把Tmax不超过60、80或100°C作为示例设计约束，在128个完整组合内选取最大端口输出。该阈值用于展示联合选择方法，不是007器件已认证的安全额定温度；最优仅指当前离散候选集。')
choices=pd.read_csv(ROOT/'analysis/conditional_design_choices.csv')
table(['T限 °C','分组','工况','Pout W','Tmax °C','Ps w θ Ts Rth'],[[int(r.illustrative_Tmax_C),'行' if r.topology=='2S2P_rows' else '列',r.case_id,f(r.Pport_W,3),f(r.Tj_max_C,2),f'{r.source_power_W:g} {r.w_mm:g} {r.angle_deg:g} {r.Tsink_C:g} {r.Rth_K_per_W:g}'] for _,r in choices.iterrows()],[2.2,1.4,2.2,2.6,2.6,6],9.8)
cap('表2  源功率单位W  w为mm  θ为度  Ts为°C  Rth为K/W  偏移及完整因素见配套CSV')
note('本候选集的F004最高温度约33.73°C，低于三个阈值，因此本表温度约束均未活跃；重复最优工况不代表不同温度上限总会得到相同设计。')
p('应首先以源端功率预算、可用接收面积和热约束筛选组合，再比较真实负载点与候选拓扑。均匀接收时较高串联数可能减少公共线损；存在强片间差异时，减少串联电流约束可明显提高电输出并降低局部发热。')
p('扩宽光束能降低对偏移的敏感度，但会增加外溢；改善散热提升温度裕量，但不能追回已经外溢的光能。仅改变其中一项难以评价最终端口，必须把方案重新送入整条光热电链。')
p('实际设计还需加入允许电压电流、连接可靠性、MPPT效率、散热器体积和指向变化范围。若要研究反偏热点或旁路切换，应先补充相关I–V和器件参数；主结果继续遵守单体内部均匀假设。')

page('25 研究结论与实验优化路线')
p('解析法基线已支持一套可复算的单体与阵列光热电联合模型。64组单体和181个阵列网络表明，源功率、光束接收、热边界、负载和分组共同决定输出。对端口功率有利的连接方式会随联合工况变化，固定负载下提高源功率也可能降低电输出。')
p('单体只使用整片平均接收功率；阵列的不均匀性只来自片与片之间。每片温度由实际电工作点及导热网络求出，热图不扩展为单体内部温度、辐照或效率分布。')
h('实物验证与模型更新')
p('先在若干接收光功率和热台温度下测量I–V，并同步标定实际结温，分离温度系数与自热。采用未参与参数更新的功率及温度组合，比较RMSE、NRMSE、MAE、最大电流误差与最大功率偏差。温度预测比较稳态温差与热动态时间指标。')
p('阵列验证应同步记录源功率、光束类型与半径、入射角、偏移、每片接收总功率、各片温度以及端口I–V。至少包含中心低温和偏移高温等多因素同时变化的工况，用来验证分组排序和局部温升。测量反射及光学损耗、热阻热容和互联电阻后再更新对应子模型。')
h('参考资料与复算')
note('[1] 肖文波等. 太阳电池单二极管模型中的参数提取方法. 物理学报67,198801(2018). DOI 10.7498/aps.67.20181024. 基线采用Five Points法及明确披露的式（2）商式修正。')
note('[2] Gou Y et al. Optics Express 30,31509–31517(2022). DOI 10.1364/OE.470740. 六结808 nm器件在21 W条件下的总Voc温系−8.15 mV/K；本研究迁移到007仅作情景。')
note('[3] Fafard S, Masson D. Photonics 13,246(2026). DOI 10.3390/photonics13030246. 另一器件809 nm温度系数约−6.8 mV/K，提示系数依赖结构与工况。')
note('[4] Geisz J F et al. IEEE Journal of Photovoltaics 13,808–813(2023). DOI 10.1109/JPHOTOV.2023.3304360. 用于结温测量与温度系数分工况标定方法参考。')
note('[5] Mou Z et al. Photonics 11,193(2024). DOI 10.3390/photonics11030193. 阵列光束接收与拓扑研究参考；本报告电学基线采用007解析参数。')
note('配套模型包包含input、optics、single、array、analysis与validation目录。依次运行optics/build_optical_cases.py、single/run_single.py、array/run_array_study.py、array/dynamic_array.py与analysis/analyze_joint.py，可复算本文结果。研究约束保存在study_config.json。')

fn=OUT/'LPV808_Analytical_Coupled_Study_Report.docx'
cb.save_docx(doc,fn)
(OUT/'report_structure.json').write_text(json.dumps({'intended_pages':26,'native_charts':len(cb.charts),'native_cell_heatmap_pairs':4,'chapter_titles':page_names},ensure_ascii=False,indent=2))
print(json.dumps({'docx':str(fn),'bytes':fn.stat().st_size,'intended_pages':26,'native_charts':len(cb.charts)},ensure_ascii=False))
