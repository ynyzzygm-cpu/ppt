"""Actual-port electrothermal network on positive generation support only.

Cells are uniform internally.  Nonuniformity exists only among intercepted cell
powers.  Strings are series-connected cells and strings are placed in parallel.
An external common series wire resistance connects the bus to the load port.
Newton iterates may evaluate the algebraic diode inverse outside generation,
but every accepted state strictly checks all cell voltages/currents and all
thermal/electrical balances. No reverse-bias or bypass law is supplied.
"""
from pathlib import Path
import sys,time
import numpy as np
from scipy.optimize import root,brentq,minimize_scalar,least_squares

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
import core_model as core


def spatial_edges(nrows,ncols):
    edges=[]
    for r in range(nrows):
        for c in range(ncols):
            j=r*ncols+c
            if c+1<ncols:edges.append((j,j+1))
            if r+1<nrows:edges.append((j,j+ncols))
    return edges


def topologies(nrows=2,ncols=2):
    if (nrows,ncols)==(2,2):
        return {'1S4P':[[0],[1],[2],[3]],
                '2S2P_rows':[[0,1],[2,3]],
                '2S2P_columns':[[0,2],[1,3]],
                '2S2P_diagonals':[[0,3],[1,2]],
                '4S1P':[[0,1,2,3]]}
    if (nrows,ncols)==(3,3):
        return {'3S3P_rows':[[0,1,2],[3,4,5],[6,7,8]],
                '3S3P_mixed':[[0,4,8],[1,5,6],[2,3,7]]}
    raise ValueError('Topology presets exist for 2x2 and 3x3.')


class UnsupportedState(ValueError):pass


class ArrayModel:
    def __init__(self,powers,groups,Tsink_C=25.,Rth=5.437227322491945,
                 G_lat=.03,interconnectR=.02,nrows=2,ncols=2,cfg=None,
                 wire_to_cell_fraction=0.,wire_weights=None):
        self.powers=np.asarray(powers,dtype=float)
        self.n=len(self.powers);self.groups=[np.asarray(g,dtype=int) for g in groups]
        self.ns=len(self.groups);self.Tsink=float(Tsink_C)
        self.rth=np.broadcast_to(np.asarray(Rth,dtype=float),(self.n,)).copy()
        self.glat=float(G_lat);self.rwire=float(interconnectR);self.cfg=core.config(cfg)
        self.eta=float(self.cfg['eta_h']);self.nrows=int(nrows);self.ncols=int(ncols)
        self.fwire=float(wire_to_cell_fraction)
        self.weights=np.full(self.n,1/self.n) if wire_weights is None else np.asarray(wire_weights,dtype=float)
        if self.n!=self.nrows*self.ncols:raise ValueError('Grid and cell count disagree.')
        if sorted(np.concatenate(self.groups).tolist())!=list(range(self.n)):raise ValueError('Every cell must occur exactly once.')
        if min(self.powers)<=0 or min(self.rth)<0 or self.glat<0 or self.rwire<0:raise ValueError('Invalid positive-power/passive network data.')
        if not 0<=self.fwire<=1 or min(self.weights)<0 or not np.isclose(sum(self.weights),1):raise ValueError('Invalid wire heat fraction/weights.')
        self.mapping=np.empty(self.n,dtype=int)
        for k,g in enumerate(self.groups):self.mapping[g]=k
        self.L=np.zeros((self.n,self.n))
        self.edges=spatial_edges(self.nrows,self.ncols)
        for a,b in self.edges:
            self.L[a,a]+=self.glat;self.L[b,b]+=self.glat
            self.L[a,b]-=self.glat;self.L[b,a]-=self.glat
        self.invr=np.divide(1.,self.rth,out=np.zeros_like(self.rth),where=self.rth>0)
        self.A=np.diag(self.invr)+self.L
        self.clamped=self.rth==0
        self.solveA=self.A.copy()
        for j in np.flatnonzero(self.clamped):self.solveA[j]=0.;self.solveA[j,j]=1.
        self.cache={};self.solve_count=0;self.solve_seconds=0.;self.failures=0
        self._boundary=None

    def _evaluate(self,z,unknown_U=False,U=None):
        ib=z[:self.ns];tt=z[self.ns:self.ns+self.n]
        u=float(z[-1]) if unknown_U else float(U)
        p=core.parameters(self.powers,tt,self.cfg)
        ii=ib[self.mapping]
        vv=np.asarray(core.voltage_from_parameters(ii,p,generation_only=False))
        pp=vv*ii;it=float(sum(ib));pw=self.rwire*it*it
        qbase=self.eta*self.powers-pp
        q=qbase+self.fwire*pw*self.weights
        thermal=self.A@(tt-self.Tsink)-q
        thermal[self.clamped]=tt[self.clamped]-self.Tsink
        kvl=np.array([sum(vv[g])-u for g in self.groups])
        return ib,tt,u,p,ii,vv,pp,it,pw,qbase,q,thermal,kvl

    def _derivatives(self,z,unknown_U=False,U=None):
        data=self._evaluate(z,unknown_U,U)
        ib,tt,u,p,ii,vv,pp,it,pw,qbase,q,thermal,kvl=data
        internal=vv+ii*p['Rs_ohm']
        b=p['I0_A']/p['a_V']*np.exp(internal/p['a_V'])+1/p['Rsh_ohm']
        dvdi=-1/b-p['Rs_ohm']
        eps=1e-3
        ta=np.maximum(tt-eps,self.cfg['temperature_domain_C'][0])
        tb=np.minimum(tt+eps,self.cfg['temperature_domain_C'][1])
        pplus=core.parameters(self.powers,tb,self.cfg)
        pminus=core.parameters(self.powers,ta,self.cfg)
        dvdt=(np.asarray(core.voltage_from_parameters(ii,pplus,False))-
              np.asarray(core.voltage_from_parameters(ii,pminus,False)))/(tb-ta)
        return data,dvdi,dvdt

    def _initial(self,U=None):
        q=np.maximum((self.eta-.54)*self.powers,0.)
        q[self.clamped]=0.
        tt=self.Tsink+np.linalg.solve(self.solveA,q)
        p=core.parameters(self.powers,tt,self.cfg)
        isc=np.asarray(core.current_from_parameters(0.,p));voc=np.asarray(core.voltage_from_parameters(np.zeros(self.n),p))
        if U is None:U=float(np.mean([sum(voc[g]) for g in self.groups])*.88)
        ib=[]
        for g in self.groups:
            imax=float(min(isc[g]));vmax=float(sum(voc[g]))
            if U>=vmax:ik=0.
            else:
                # Only initialization is clipped to the nonnegative branch.
                def vf(x):
                    sub={k:np.asarray(v)[g] for k,v in p.items()}
                    return float(sum(core.voltage_from_parameters(np.full(len(g),x),sub,False))-U)
                if vf(imax)>=0:ik=imax
                else:ik=brentq(vf,0,imax,xtol=1e-10)
            ib.append(ik)
        return np.r_[ib,tt],float(U)

    def _solve(self,U=None,constraint=None,initial=None):
        unknown=constraint is not None
        if initial is None:
            z0,ug=self._initial(U)
            if unknown:z0=np.r_[z0,ug]
        else:
            z0=np.asarray(initial,dtype=float).copy()
            if unknown and len(z0)==self.ns+self.n:z0=np.r_[z0,float(U)]
        last={}
        def calc(z):
            if last.get('z') is None or not np.array_equal(z,last['z']):
                last['z']=z.copy();last['value']=self._derivatives(z,unknown,U)
            return last['value']
        def residual(z):
            dat,di,dt=calc(z);ib,tt,u,p,ii,vv,pp,it,pw,qbase,q,th,kvl=dat
            out=np.r_[kvl,th]
            if unknown:
                kind,j=constraint
                boundary=(vv[j] if kind=='cell_zero' else
                          ib[j] if kind=='branch_zero' else
                          u-self.rwire*it if kind=='port_zero' else
                          u-(self.rwire+float(j))*it if kind=='load' else None)
                if boundary is None:raise ValueError('Unknown constraint.')
                out=np.r_[out,boundary]
            return out
        def jac(z):
            dat,di,dt=calc(z);ib,tt,u,p,ii,vv,pp,it,pw,qbase,q,th,kvl=dat
            nc=self.ns+self.n+int(unknown);J=np.zeros((nc,nc))
            for k,g in enumerate(self.groups):
                J[k,k]=sum(di[g]);J[k,self.ns+g]=dt[g]
                if unknown:J[k,-1]=-1
            J[self.ns:self.ns+self.n,self.ns:self.ns+self.n]=self.A+np.diag(ii*dt)
            for j in range(self.n):
                J[self.ns+j,self.mapping[j]]=vv[j]+ii[j]*di[j]
                J[self.ns+j,:self.ns]-=self.fwire*self.weights[j]*2*self.rwire*it
            for j in np.flatnonzero(self.clamped):
                J[self.ns+j]=0.;J[self.ns+j,self.ns+j]=1.
            if unknown:
                kind,j=constraint
                if kind=='cell_zero':J[-1,self.mapping[j]]=di[j];J[-1,self.ns+j]=dt[j]
                elif kind=='branch_zero':J[-1,j]=1.
                else:
                    J[-1,:self.ns]=-self.rwire-(float(j) if kind=='load' else 0.)
                    J[-1,-1]=1.
            return J
        start=time.perf_counter();self.solve_count+=1
        try:
            try:
                sol=root(residual,z0,jac=jac,method='hybr',options={'xtol':2e-9,'maxfev':250})
                good=np.all(np.isfinite(sol.x)) and max(abs(residual(sol.x)))<=2e-7
            except (ValueError,FloatingPointError,OverflowError):good=False
            if not good:
                # Keep nonlinear trial temperatures inside the declared model
                # domain. Currents may leave generation during Newton/search;
                # only a final supported solution is accepted by public calls.
                lb=np.full(len(z0),-np.inf);ub=np.full(len(z0),np.inf)
                lb[self.ns:self.ns+self.n]=self.cfg['temperature_domain_C'][0]
                ub[self.ns:self.ns+self.n]=self.cfg['temperature_domain_C'][1]
                z0=np.minimum(np.maximum(z0,lb+1e-8),ub-1e-8)
                sol=least_squares(residual,z0,jac=jac,bounds=(lb,ub),
                                  xtol=1e-11,ftol=1e-11,gtol=1e-11,
                                  max_nfev=350,x_scale='jac')
            residual_final=residual(sol.x)
            if not np.all(np.isfinite(sol.x)) or not np.all(np.isfinite(residual_final)) or max(abs(residual_final))>2e-7:
                raise UnsupportedState('Network root residual too large or nonfinite.')
            dat=self._evaluate(sol.x,unknown,U)
            state=self._state(dat,sol.x)
        except (ValueError,FloatingPointError,OverflowError) as exc:
            self.failures+=1
            raise UnsupportedState(str(exc)) from exc
        finally:self.solve_seconds+=time.perf_counter()-start
        return state

    def _state(self,dat,z):
        ib,tt,u,p,ii,vv,pp,it,pw,qbase,q,th,kvl=dat
        vo=u-self.rwire*it
        lateral=self.L@(tt-self.Tsink)
        sink=self.invr*(tt-self.Tsink)
        sink[self.clamped]=(q-lateral)[self.clamped]
        support=bool(min(vv)>=-2e-7 and min(ib)>=-2e-9 and vo>=-2e-7 and min(qbase)>=-2e-7)
        cellrows=[]
        for j in range(self.n):
            cellrows.append({'cell':j+1,'row':j//self.ncols+1,'col':j%self.ncols+1,
              'string':int(self.mapping[j])+1,'Pin_W':float(self.powers[j]),'Tj_C':float(tt[j]),
              'Vcell_V':float(vv[j]),'Icell_A':float(ii[j]),'Pcell_W':float(pp[j]),
              'Qcell_base_W':float(qbase[j]),'Qcell_total_W':float(q[j]),
              'heat_to_sink_W':float(sink[j]),'lateral_heat_out_W':float(lateral[j]),
              'thermal_balance_residual_W':float(q[j]-sink[j]-lateral[j])})
        pout=vo*it
        return {'Vbus_V':float(u),'Vport_V':float(vo),'Iport_A':float(it),'Pport_W':float(pout),
                'Pin_total_W':float(sum(self.powers)),'efficiency_intercepted_percent':float(100*pout/sum(self.powers)),
                'wire_loss_W':float(pw),'wire_heat_to_cells_W':float(self.fwire*pw),
                'wire_heat_to_environment_W':float((1-self.fwire)*pw),
                'sum_cell_power_W':float(sum(pp)),'sum_cell_heat_W':float(sum(q)),
                'heat_to_sink_total_W':float(sum(sink)),'retained_optical_W':float(self.eta*sum(self.powers)),
                'optical_unretained_W':float((1-self.eta)*sum(self.powers)),
                'electrical_balance_residual_W':float(sum(pp)-pout-pw),
                'full_energy_balance_residual_W':float(sum(self.powers)-(1-self.eta)*sum(self.powers)-pout-(1-self.fwire)*pw-sum(sink)),
                'lateral_heat_sum_residual_W':float(sum(lateral)),
                'KVL_max_residual_V':float(max(abs(kvl))),
                'thermal_max_residual_W':float(max(abs(th))),
                'minimum_cell_voltage_V':float(min(vv)),'minimum_branch_current_A':float(min(ib)),
                'Tj_min_C':float(min(tt)),'Tj_max_C':float(max(tt)),
                'forward_supported':support,'cells':cellrows,'branch_currents_A':ib.tolist(),
                '_solution':np.asarray(z).tolist()}

    def state(self,U,require_supported=True):
        key=round(float(U),12)
        if key not in self.cache:
            if self.cache:
                near=min(self.cache,key=lambda x:abs(x-key));prev=self.cache[near]['_solution'][:self.ns+self.n]
            else:prev=None
            self.cache[key]=self._solve(float(U),initial=prev)
        s=self.cache[key]
        if require_supported and not s['forward_supported']:raise UnsupportedState('State outside all-cell positive-generation support.')
        return s

    def bounds(self):
        if self._boundary is not None:return self._boundary
        z0,_=self._initial()
        tt=z0[self.ns:];p=core.parameters(self.powers,tt,self.cfg)
        isc=np.asarray(core.current_from_parameters(0,p));voc=np.asarray(core.voltage_from_parameters(np.zeros(self.n),p))
        lower=[]
        for g in self.groups:
            weak=int(g[np.argmin(isc[g])]);sub={k:np.asarray(v)[g] for k,v in p.items()}
            vl=float(sum(core.voltage_from_parameters(np.full(len(g),min(isc[g])),sub,False)))
            lower.append((vl,weak))
        predicted_low,cell=max(lower)
        low=None
        for _ in range(self.ns+2):
            low=self._solve(U=predicted_low,constraint=('cell_zero',cell))
            j=int(np.argmin([s['Vcell_V'] for s in low['cells']]))
            if low['minimum_cell_voltage_V']>=-2e-7:break
            cell=j
        if low['Vport_V']<0:
            low=self._solve(U=low['Vbus_V'],constraint=('port_zero',0),initial=low['_solution'])
        branch=int(np.argmin([sum(voc[g]) for g in self.groups]))
        high=None
        for _ in range(self.ns+2):
            high=self._solve(U=float(sum(voc[self.groups[branch]])),constraint=('branch_zero',branch))
            j=int(np.argmin(high['branch_currents_A']))
            if high['minimum_branch_current_A']>=-2e-9:break
            branch=j
        if not low['forward_supported'] or not high['forward_supported'] or low['Vbus_V']>=high['Vbus_V']:
            raise UnsupportedState('No common positive-generation electrothermal support interval.')
        self.cache[round(low['Vbus_V'],12)]=low;self.cache[round(high['Vbus_V'],12)]=high
        self._boundary=(low,high)
        return low,high

    def optimum(self,scan_points=17):
        t0=time.perf_counter();low,high=self.bounds();lo=low['Vbus_V'];hi=high['Vbus_V']
        us=np.linspace(lo,hi,int(scan_points));states=[self.state(float(u)) for u in us]
        powers=np.array([s['Pport_W'] for s in states]);cand=[states[0],states[-1]]
        peaks=np.flatnonzero((powers[1:-1]>=powers[:-2])&(powers[1:-1]>=powers[2:]))+1
        for k in peaks:
            sol=minimize_scalar(lambda u:-self.state(float(u))['Pport_W'],bounds=(us[k-1],us[k+1]),method='bounded',options={'xatol':2e-8})
            cand.append(self.state(float(sol.x)))
        best=dict(max(cand,key=lambda s:s['Pport_W']))
        edge=min(best['Vbus_V']-lo,hi-best['Vbus_V'])
        best.update({'supported_bus_min_V':lo,'supported_bus_max_V':hi,
          'supported_port_min_V':low['Vport_V'],'supported_port_max_V':high['Vport_V'],
          'optimum_label':'supported_interior_MPP' if edge>1e-5 else 'boundary_limited_supported_maximum',
          'is_interior_supported_MPP':bool(edge>1e-5),'full_network_GMPP_claimed':False,
          'groups_1based':[[int(j)+1 for j in g] for g in self.groups],
          'Tsink_C':self.Tsink,'Rth_each_K_per_W':self.rth.tolist(),'G_lat_W_per_K':self.glat,
          'Rwire_ohm':self.rwire,'wire_to_cell_fraction':self.fwire,
          'solve_count':self.solve_count,'solve_seconds':self.solve_seconds,'optimum_runtime_seconds':time.perf_counter()-t0,
          'scan_points':int(scan_points)})
        lo_active=[r['cell'] for r in low['cells'] if abs(r['Vcell_V'])<2e-6]
        hi_active=[j+1 for j,i in enumerate(high['branch_currents_A']) if abs(i)<2e-8]
        best.update({'lower_boundary_zero_voltage_cells_1based':lo_active,
                     'lower_boundary_port_zero':bool(abs(low['Vport_V'])<2e-6),
                     'upper_boundary_zero_current_strings_1based':hi_active,
                     'actual_load_at_optimum_ohm':best['Vport_V']/best['Iport_A']})
        data,di,dt=self._derivatives(np.asarray(best['_solution'])[:self.ns+self.n],U=best['Vbus_V'])
        # Linear stability of the thermal ODE at frozen bus voltage, with
        # instantaneous KVL elimination of the electrical branch currents.
        D=np.diag([sum(di[g]) for g in self.groups]);B=np.zeros((self.ns,self.n))
        C=np.zeros((self.n,self.ns));E=self.A+np.diag(np.asarray([r['Icell_A'] for r in best['cells']])*dt)
        for k,g in enumerate(self.groups):B[k,g]=dt[g]
        for j,r in enumerate(best['cells']):
            C[j,self.mapping[j]]=r['Vcell_V']+r['Icell_A']*di[j]
            C[j,:]-=self.fwire*self.weights[j]*2*self.rwire*best['Iport_A']
        K=E-C@np.linalg.solve(D,B)
        free=np.flatnonzero(~self.clamped)
        modes=np.linalg.eigvals(K[np.ix_(free,free)]) if len(free) else np.array([])
        best.update({'fixed_bus_thermal_stiffness_min_real_W_per_K':float(min(modes.real)) if len(modes) else None,
                     'fixed_bus_locally_thermally_stable':bool(np.all(modes.real>0)),
                     'fixed_bus_stability_perturbations_inside_support':bool(best['minimum_cell_voltage_V']>2e-5 and best['minimum_branch_current_A']>2e-7),
                     'fixed_bus_stability_validity':'Interior support: local diode linearization applies. At active support boundaries the eigenvalues are formal only; unsupported perturbations have no measured physical law.',
                     'stability_boundary':'fixed_bus_voltage; electrical currents eliminated, Cth positive; clamp temperatures excluded'})
        return best

    def curve(self,n=101):
        low,high=self.bounds()
        return [self.state(float(u)) for u in np.linspace(low['Vbus_V'],high['Vbus_V'],n)]

    def steady_load(self,Rload_ohm,initial=None):
        state=self._solve(constraint=('load',float(Rload_ohm)),initial=initial)
        if not state['forward_supported']:raise UnsupportedState('Load intersects unsupported cell domain.')
        state['Rload_ohm']=float(Rload_ohm)
        return state

    def electrical_load_at_T(self,Tj_C,Rload_ohm,initial=None):
        """Fast isothermal network for thermal ODE; no thermal steady substitution."""
        tt=np.broadcast_to(np.asarray(Tj_C,dtype=float),(self.n,))
        p=core.parameters(self.powers,tt,self.cfg)
        if initial is None:
            z0,ug=self._initial();z=np.r_[z0[:self.ns],ug]
        else:z=np.asarray(initial,dtype=float).copy()
        def calc(x):
            ib=x[:self.ns];u=x[-1];ii=ib[self.mapping]
            vv=np.asarray(core.voltage_from_parameters(ii,p,False));it=float(sum(ib))
            internal=vv+ii*p['Rs_ohm'];b=p['I0_A']/p['a_V']*np.exp(internal/p['a_V'])+1/p['Rsh_ohm']
            di=-1/b-p['Rs_ohm']
            return ib,u,ii,vv,it,di
        def fun(x):
            ib,u,ii,vv,it,di=calc(x)
            return np.r_[[sum(vv[g])-u for g in self.groups],u-(self.rwire+Rload_ohm)*it]
        def jac(x):
            ib,u,ii,vv,it,di=calc(x);J=np.zeros((self.ns+1,self.ns+1))
            for k,g in enumerate(self.groups):J[k,k]=sum(di[g]);J[k,-1]=-1
            J[-1,:self.ns]=-(self.rwire+Rload_ohm);J[-1,-1]=1
            return J
        sol=root(fun,z,jac=jac,method='hybr',options={'xtol':2e-9,'maxfev':120})
        if not np.all(np.isfinite(sol.x)) or not np.all(np.isfinite(fun(sol.x))) or max(abs(fun(sol.x)))>2e-7:
            raise UnsupportedState('Dynamic electrical network failed residual check.')
        ib,u,ii,vv,it,di=calc(sol.x);vo=u-self.rwire*it
        if min(vv)<-2e-7 or min(ib)<-2e-9 or vo< -2e-7:
            raise UnsupportedState('Thermal trajectory left all-cell positive-generation domain.')
        pw=self.rwire*it*it;pp=vv*ii;qbase=self.eta*self.powers-pp
        q=qbase+self.fwire*pw*self.weights
        if min(qbase)<-2e-7:raise UnsupportedState('Electrical cell output exceeds retained optical energy.')
        return {'Vbus_V':float(u),'Vport_V':float(vo),'Iport_A':it,'Pport_W':float(vo*it),
                'wire_loss_W':pw,'Vcell_V':vv,'Icell_A':ii,'Pcell_W':pp,
                'Qcell_W':q,'Qcell_base_W':qbase,'electrical_solution':sol.x.tolist(),
                'KVL_max_residual_V':float(max(abs(fun(sol.x)[:-1]))),
                'load_equation_residual_V':float(fun(sol.x)[-1]),
                'electrical_balance_residual_W':float(sum(pp)-vo*it-pw)}


def public_state(state):
    return {k:v for k,v in state.items() if not k.startswith('_')}


if __name__=='__main__':
    import json
    net=ArrayModel([8.,8.,8.,8.],topologies()['2S2P_rows'])
    result=net.optimum()
    print(json.dumps(public_state(result),indent=2))
