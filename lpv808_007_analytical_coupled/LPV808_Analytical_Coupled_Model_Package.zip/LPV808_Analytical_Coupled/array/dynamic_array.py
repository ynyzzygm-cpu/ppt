"""Fixed-resistor electrothermal step of two series/parallel array networks.

The optical CSV gives one *uniformly illuminated* Pin per cell.  The resistor is
selected once, then held fixed before, during, and after the simultaneous power
and beam-offset step.  Every ODE evaluation solves the instantaneous electrical
network at the actual four temperatures; no steady-state temperature or MPP is
substituted into the ODE.  Unsupported trajectories stop without clipping.
"""
from pathlib import Path
import csv
import json
import sys
import time
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
from array_model import ArrayModel, UnsupportedState, topologies, public_state
import core_model as core

INPUT = ROOT / 'optics' / 'array_dynamic_inputs.csv'
CTH = 0.3


def read_inputs(path=INPUT):
    with open(path, newline='', encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    out = {}
    for case in ('D_before', 'D_after'):
        selected = sorted((r for r in rows if r['case_id'] == case),
                          key=lambda r: int(r['cell']))
        if [int(r['cell']) for r in selected] != [1, 2, 3, 4]:
            raise ValueError(f'{case} must contain cells 1..4 exactly once.')
        out[case] = {
            'metadata': {k: (float(v) if k not in ('case_id', 'family', 'profile') else v)
                         for k, v in selected[0].items()
                         if k not in ('cell', 'row', 'column', 'cx_mm', 'cy_mm',
                                      'Pin_W', 'irradiance_W_cm2')},
            'Pin_W': [float(r['Pin_W']) for r in selected],
        }
    return out


def network(data, groups):
    m = data['metadata']
    return ArrayModel(data['Pin_W'], groups, Tsink_C=m['Tsink_C'],
                      Rth=m['Rth_K_per_W'], G_lat=m['G_lat_W_per_K'],
                      interconnectR=m['Rwire_ohm'], nrows=2, ncols=2,
                      wire_to_cell_fraction=0.)


def resistance(state):
    return np.inf if state['Iport_A'] <= 1e-10 else state['Vport_V'] / state['Iport_A']


def interval_json(interval):
    lo, hi = interval
    return {'minimum_Rload_ohm': float(lo),
            'maximum_Rload_ohm': None if not np.isfinite(hi) else float(hi),
            'upper_unbounded': bool(not np.isfinite(hi))}


def frozen_support_interval(net, temperatures):
    """Exact positive-generation support for a frozen-temperature network.

    Each string's current is in [0,min(Isc_i)]; its bus voltage consequently
    lies between its voltage at min(Isc_i) and its sum(Voc_i).  Intersect these
    intervals, then enforce nonnegative actual port voltage including Rwire.
    """
    p = core.parameters(net.powers, temperatures, net.cfg)
    isc = np.asarray(core.current_from_parameters(0., p))
    voc = np.asarray(core.voltage_from_parameters(np.zeros(net.n), p))
    subsets = [{k: np.asarray(v)[g] for k, v in p.items()} for g in net.groups]
    imax = [float(min(isc[g])) for g in net.groups]
    lower = [float(sum(core.voltage_from_parameters(np.full(len(g), im), pp, False)))
             for g, pp, im in zip(net.groups, subsets, imax)]
    upper = [float(sum(voc[g])) for g in net.groups]
    lo, hi = max(lower), min(upper)
    if lo >= hi:
        raise UnsupportedState('No frozen-temperature common generation support.')

    def port(u):
        currents = []
        for g, pp, im, vhigh in zip(net.groups, subsets, imax, upper):
            def residual(ii):
                return float(sum(core.voltage_from_parameters(np.full(len(g), ii), pp, False))) - u
            if abs(u - vhigh) < 1e-10:
                ii = 0.
            elif abs(residual(im)) < 1e-10:
                ii = im
            else:
                ii = brentq(residual, 0., im, xtol=2e-13)
            currents.append(ii)
        it = sum(currents)
        vp = u - net.rwire * it
        return vp, it

    if port(lo)[0] < 0:
        lo = brentq(lambda u: port(u)[0], lo, hi, xtol=1e-12)
    vl, il = port(lo)
    vh, ih = port(hi)
    return max(0., vl / il), (np.inf if ih <= 1e-10 else vh / ih)


def steady_at_load(net, rload, reference):
    z = np.asarray(reference['_solution'])[:net.ns + net.n]
    state = net._solve(U=reference['Vbus_V'], constraint=('load', rload),
                       initial=np.r_[z, reference['Vbus_V']])
    if not state['forward_supported']:
        raise UnsupportedState('Selected resistor has unsupported steady state.')
    state['Rload_ohm'] = float(rload)
    return state


def instantaneous(net, temperatures, rload, guess=None):
    s = net.electrical_load_at_T(temperatures, rload, initial=guess)
    scalars = [s['Vbus_V'], s['Vport_V'], s['Iport_A'], s['Pport_W']]
    arrays = [s[k] for k in ('Vcell_V', 'Icell_A', 'Pcell_W', 'Qcell_W')]
    if not all(np.all(np.isfinite(a)) for a in scalars + arrays):
        raise UnsupportedState('Nonfinite instantaneous electrical state.')
    return s


def select_fixed_load(before, after):
    bmpp = before.optimum(scan_points=33)
    ampp = after.optimum(scan_points=33)
    bi = tuple(resistance(s) for s in before.bounds())
    ai = tuple(resistance(s) for s in after.bounds())
    common = (max(bi[0], ai[0]), min(bi[1], ai[1]))
    if common[0] >= common[1]:
        raise UnsupportedState('No common before/after steady load support.')
    preferred = resistance(bmpp)
    upper = common[1] if np.isfinite(common[1]) else max(100 * preferred, common[0] * 100, 1.)
    floor = max(common[0] * (1 + 1e-6), 1e-7)
    ceiling = upper * (1 - 1e-6)
    midpoint = np.sqrt(floor * ceiling)
    candidates = ([preferred] if floor < preferred < ceiling else []) + [midpoint]
    candidates += np.geomspace(floor, ceiling, 81).tolist()
    rejected = []
    for candidate in candidates:
        try:
            b = steady_at_load(before, candidate, bmpp)
            a = steady_at_load(after, candidate, ampp)
            tb = np.array([c['Tj_C'] for c in b['cells']])
            instant_interval = frozen_support_interval(after, tb)
            if not instant_interval[0] < candidate < instant_interval[1]:
                raise UnsupportedState('Resistor outside post-step frozen-T support.')
            bguess = np.r_[b['branch_currents_A'], b['Vbus_V']]
            instant = instantaneous(after, tb, candidate, bguess)
            return float(candidate), b, a, instant, {
                'rule': ('initial_steady_supported_MPP_resistance' if candidate == preferred
                         else 'interior_common_support_resistance'),
                'before_steady_support': interval_json(bi),
                'after_steady_support': interval_json(ai),
                'common_steady_support': interval_json(common),
                'post_step_at_initial_temperature_support': interval_json(instant_interval),
                'initial_MPP_Rload_ohm': preferred,
                'initial_MPP_Pport_W': bmpp['Pport_W'],
                'post_step_supported_MPP_Pport_W': ampp['Pport_W'],
                'candidate_rejections': rejected,
            }
        except (UnsupportedState, ValueError, FloatingPointError) as exc:
            rejected.append({'Rload_ohm': float(candidate), 'reason': str(exc)})
    raise UnsupportedState('No tested common-support resistor also supports the instantaneous step.')


def sample_rows(topology, phase, t, temperatures, net, data, rload, state=None):
    s = instantaneous(net, temperatures, rload) if state is None else state
    temperatures = np.asarray(temperatures)
    sink = net.invr * (temperatures - net.Tsink)
    lateral = net.L @ (temperatures - net.Tsink)
    dt = (s['Qcell_W'] - sink - lateral) / CTH
    storage = CTH * dt
    cell_residual = s['Qcell_W'] - sink - lateral - storage
    total_pin = float(sum(net.powers))
    unretained = (1 - net.eta) * total_pin
    energy_residual = total_pin - unretained - s['Pport_W'] - s['wire_loss_W'] - sum(sink) - sum(storage)
    m = data['metadata']
    optical_losses = sum(m[k] for k in ('fiber_loss_W', 'optics_loss_W', 'path_loss_W',
                                      'gap_power_W', 'outside_power_W'))
    source_residual = m['source_power_W'] - optical_losses - unretained - s['Pport_W'] - s['wire_loss_W'] - sum(sink) - sum(storage)
    result = []
    for j in range(net.n):
        result.append({
            'topology': topology, 'phase': phase, 'time_s': float(t), 'cell': j + 1,
            'row': j // net.ncols + 1, 'column': j % net.ncols + 1,
            'string': int(net.mapping[j]) + 1, 'source_power_W': m['source_power_W'],
            'Pin_W': float(net.powers[j]), 'Tj_C': float(temperatures[j]),
            'Vcell_V': float(s['Vcell_V'][j]), 'Icell_A': float(s['Icell_A'][j]),
            'Pcell_W': float(s['Pcell_W'][j]), 'Qcell_W': float(s['Qcell_W'][j]),
            'heat_to_sink_W': float(sink[j]), 'lateral_heat_out_W': float(lateral[j]),
            'storage_rate_W': float(storage[j]), 'dTj_dt_K_per_s': float(dt[j]),
            'cell_dynamic_balance_residual_W': float(cell_residual[j]),
            'Rload_ohm': rload, 'Vbus_V': s['Vbus_V'], 'Vport_V': s['Vport_V'],
            'Iport_A': s['Iport_A'], 'Pport_W': s['Pport_W'],
            'wire_loss_W': s['wire_loss_W'], 'wire_heat_to_cells_W': 0.,
            'wire_heat_to_environment_W': s['wire_loss_W'],
            'KVL_max_residual_V': s['KVL_max_residual_V'],
            'load_equation_residual_V': s['load_equation_residual_V'],
            'electrical_balance_residual_W': s['electrical_balance_residual_W'],
            'intercepted_dynamic_energy_residual_W': float(energy_residual),
            'source_dynamic_energy_residual_W': float(source_residual),
            'lateral_heat_sum_residual_W': float(sum(lateral)),
            'forward_supported': True,
        })
    return result


def run_one(name, inputs):
    start = time.perf_counter()
    groups = topologies()[name]
    before = network(inputs['D_before'], groups)
    after = network(inputs['D_after'], groups)
    rload, b, a, step, selection = select_fixed_load(before, after)
    tb = np.array([c['Tj_C'] for c in b['cells']])
    ta = np.array([c['Tj_C'] for c in a['cells']])
    cache = {'guess': step['electrical_solution'], 'calls': 0,
             'last_supported_t': 0., 'last_supported_T': tb.copy(), 'failure': None}

    def rhs(t, temperatures):
        cache['calls'] += 1
        try:
            s = instantaneous(after, temperatures, rload, cache['guess'])
            cache['guess'] = s['electrical_solution']
            rate = (s['Qcell_W'] - after.A @ (temperatures - after.Tsink)) / CTH
            if not np.all(np.isfinite(rate)):
                raise UnsupportedState('Nonfinite thermal derivative.')
            cache['last_supported_t'] = float(t)
            cache['last_supported_T'] = np.asarray(temperatures).copy()
            return rate
        except (ValueError, FloatingPointError, OverflowError) as exc:
            cache['failure'] = {'time_s': float(t), 'Tj_C': np.asarray(temperatures).tolist(),
                                'reason': str(exc),
                                'last_supported_evaluation_time_s': cache['last_supported_t']}
            raise UnsupportedState(str(exc)) from exc

    segments = []
    status = 'completed'
    stop_reason = None
    endpoint = 0.
    y = tb.copy()
    # Short solve_ivp segments preserve a supported accepted history if a later
    # solver trial exits the domain. An unsupported trial is never clipped or
    # reused as an accepted ODE state.
    for end in np.arange(1., 49.):
        try:
            sol = solve_ivp(rhs, (endpoint, end), y, method='RK45', rtol=2e-8,
                            atol=2e-8, max_step=.10, dense_output=True)
            if not sol.success:
                status, stop_reason = 'integration_failed', sol.message
                break
            segments.append(sol)
            endpoint, y = float(sol.t[-1]), sol.y[:, -1]
            if end in (12., 24., 48.) and max(abs(y - ta)) < 1e-4 and max(abs(rhs(endpoint, y))) < 1e-4:
                break
        except UnsupportedState as exc:
            status, stop_reason = 'stopped_at_support_exit', str(exc)
            if cache['failure'] is not None:
                cache['failure']['last_accepted_segment_time_s'] = endpoint
                cache['failure']['last_accepted_Tj_C'] = y.tolist()
            break
    if status == 'completed' and (max(abs(y - ta)) >= 1e-4 or max(abs(rhs(endpoint, y))) >= 1e-4):
        status = 'completed_time_horizon_not_converged'
    rows = []
    b_electrical = instantaneous(before, tb, rload,
                                np.r_[b['branch_currents_A'], b['Vbus_V']])
    rows += sample_rows(name, 'before_steady_t0minus', 0., tb, before,
                        inputs['D_before'], rload, b_electrical)
    rows += sample_rows(name, 'after_step_t0plus', 0., tb, after,
                        inputs['D_after'], rload, step)
    # Dense sampling is performed only over successfully integrated segments;
    # unsupported ODE trial states never appear as a clipped time series.
    times = np.linspace(0., endpoint, max(2, int(round(endpoint / .05)) + 1))[1:]
    trajectory = []
    for t in times:
        segment = next(s for s in segments if s.t[0] - 1e-12 <= t <= s.t[-1] + 1e-12)
        temp = np.asarray(segment.sol(t))
        rr = sample_rows(name, 'after_step_transient', t, temp, after,
                         inputs['D_after'], rload)
        rows += rr
        trajectory.append((float(t), temp))
    if endpoint > 0:
        final = instantaneous(after, y, rload)
    else:
        final = step
    target_change = max(abs(ta - tb))
    settle = None
    if trajectory:
        tolerance = max(.02 * target_change, 1e-4)
        errs = np.array([max(abs(temp - ta)) for _, temp in trajectory])
        later_max = np.maximum.accumulate(errs[::-1])[::-1]
        candidates = np.flatnonzero(later_max <= tolerance)
        if len(candidates):
            settle = trajectory[int(candidates[0])][0]
    energy_rows = [r for r in rows if r['phase'] != 'before_steady_t0minus']
    energy_times = np.array(sorted(set(r['time_s'] for r in energy_rows)))
    heat_rates = np.array([[r['storage_rate_W'] for r in energy_rows if r['time_s'] == t]
                          for t in energy_times])
    sampled_energy_residual = np.trapezoid(heat_rates, energy_times, axis=0) - CTH * (y - tb)
    summary = {
        'topology': name, 'groups_1based': [[j + 1 for j in g] for g in groups],
        'status': status, 'stop_reason': stop_reason, 'support_exit': cache['failure'],
        'Rload_ohm': rload, 'load_policy': 'One actual resistor held fixed for all stages.',
        'load_selection': selection, 'Cth_each_J_per_K': CTH,
        'wire_heat_to_cell_fraction': 0.,
        'before_fixed_load_steady': public_state(b),
        'after_fixed_load_steady_target': public_state(a),
        'instantaneous_after_step': {
            'Tj_C': tb.tolist(), 'Vport_V': step['Vport_V'], 'Iport_A': step['Iport_A'],
            'Pport_W': step['Pport_W'], 'Vcell_V': step['Vcell_V'].tolist(),
            'Icell_A': step['Icell_A'].tolist(), 'Pcell_W': step['Pcell_W'].tolist(),
            'Qcell_W': step['Qcell_W'].tolist()},
        'integrated_to_s': endpoint, 'final_Tj_C': y.tolist(),
        'final_Pport_W': final['Pport_W'],
        'final_max_temperature_error_from_steady_K': float(max(abs(y - ta))),
        'final_max_abs_dTdt_K_per_s': float(max(abs((final['Qcell_W'] - after.A @ (y - after.Tsink)) / CTH))),
        'settling_time_2percent_of_max_temperature_step_s': settle,
        'ODE_electrical_solves': cache['calls'], 'runtime_seconds': time.perf_counter() - start,
        'timeseries_max_abs_KVL_residual_V': max(abs(r['KVL_max_residual_V']) for r in rows),
        'timeseries_max_abs_load_residual_V': max(abs(r['load_equation_residual_V']) for r in rows),
        'timeseries_max_abs_electrical_balance_residual_W': max(abs(r['electrical_balance_residual_W']) for r in rows),
        'timeseries_max_abs_intercepted_energy_residual_W': max(abs(r['intercepted_dynamic_energy_residual_W']) for r in rows),
        'timeseries_max_abs_source_energy_residual_W': max(abs(r['source_dynamic_energy_residual_W']) for r in rows),
        'timeseries_min_cell_voltage_V': min(r['Vcell_V'] for r in rows),
        'timeseries_min_cell_current_A': min(r['Icell_A'] for r in rows),
        'sampled_trapezoid_heat_integral_minus_cell_storage_J': sampled_energy_residual.tolist(),
        'sampled_energy_check_note': 'Independent time integration of exported 0.05 s heat-rate samples; nonzero quadrature error is expected.',
    }
    return summary, rows


def main():
    inputs = read_inputs()
    cases, all_rows = [], []
    for name in ('2S2P_rows', '2S2P_columns'):
        summary, rows = run_one(name, inputs)
        cases.append(summary)
        all_rows += rows
    output = {
        'model': 'Uniform-within-cell analytical diode array; four-node transient heat balance.',
        'input_file': str(INPUT.relative_to(ROOT)), 'inputs': inputs,
        'step_at_s': 0.,
        'simultaneous_step': 'Source power 32 to 48 W; beam offset (0,0) to (4,4) mm.',
        'temperature_step_policy': 'Temperatures are continuous across the optical step.',
        'heat_equation': 'Cth*dT/dt = eta_h*Pin - Vcell*Icell - (diag(1/Rth)+LateralLaplacian)*(T-Tsink)',
        'wire_heat_policy': 'External wire dissipates Iport^2*Rwire to environment; never added to cell heat.',
        'support_policy': 'Accept only all Vcell>=0, Ibranch>=0, Vport>=0 within numerical tolerances; stop on exit; never clip.',
        'reproducibility': {'command': 'python array/dynamic_array.py',
                            'ODE_solver': 'scipy.solve_ivp RK45', 'rtol': 2e-8,
                            'atol_K': 2e-8, 'max_step_s': .1,
                            'nominal_sample_interval_s': .05},
        'cases': cases,
    }
    summary_path = HERE / 'dynamic_summary.json'
    series_path = HERE / 'dynamic_timeseries.csv'
    summary_path.write_text(json.dumps(output, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')
    with open(series_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(all_rows[0]))
        writer.writeheader()
        writer.writerows(all_rows)
    print(json.dumps({'summary': str(summary_path), 'timeseries': str(series_path),
                      'rows': len(all_rows),
                      'cases': [{k: c[k] for k in ('topology', 'status', 'Rload_ohm',
                                 'integrated_to_s', 'final_Pport_W',
                                 'final_max_temperature_error_from_steady_K',
                                 'settling_time_2percent_of_max_temperature_step_s',
                                 'runtime_seconds')} for c in cases]}, indent=2))


if __name__ == '__main__':
    main()
