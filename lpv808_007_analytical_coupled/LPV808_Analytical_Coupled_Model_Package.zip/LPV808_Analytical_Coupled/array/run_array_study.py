"""Run the existing analytic cell model through joint optical/thermal networks.

The electrical objective is the largest sampled/refined PORT power over the
common all-cell V>=0,I>=0 support. No reverse-bias or bypass law is invented.
"""
from pathlib import Path
import csv,itertools,json,time,sys
import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(HERE))
from array_model import ArrayModel,topologies,public_state,UnsupportedState,core


def write_csv(path,rows):
    if not rows:return
    keys=list(dict.fromkeys(k for row in rows for k in row))
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,keys);w.writeheader();w.writerows(rows)


def read_cases():
    cases={}
    with (ROOT/'optics/optical_power_cases.csv').open(encoding='utf-8-sig') as f:
        for row in csv.DictReader(f):cases.setdefault(row['case_id'],[]).append(row)
    return {k:sorted(v,key=lambda r:int(r['cell'])) for k,v in cases.items()}


def make_model(rows,groups,isothermal=False):
    r=rows[0]
    return ArrayModel([float(a['Pin_W']) for a in rows],groups,
        Tsink_C=40. if isothermal else float(r['Tsink_C']),
        Rth=0. if isothermal else float(r['Rth_K_per_W']),
        G_lat=float(r['G_lat_W_per_K']),interconnectR=float(r['Rwire_ohm']),
        nrows=int(r['nrows']),ncols=int(r['ncols']),wire_to_cell_fraction=0.)


def metadata(rows,name):
    r=rows[0]
    fields=['case_id','family','profile','w_mm','angle_deg','offset_x_mm','offset_y_mm',
            'source_power_W','Tsink_C','Rth_K_per_W','G_lat_W_per_K','Rwire_ohm',
            'capture_fraction','eta_chain','active_power_W','gap_power_W','outside_power_W',
            'fiber_loss_W','optics_loss_W','path_loss_W']
    out={k:r[k] for k in fields};out['topology']=name
    for k in fields[3:]:out[k]=float(out[k])
    out.update(nrows=int(r['nrows']),ncols=int(r['ncols']),
               cell_Pin_min_W=min(float(a['Pin_W']) for a in rows),
               cell_Pin_max_W=max(float(a['Pin_W']) for a in rows))
    return out


def independent_reference(rows,mpp):
    pin=[float(a['Pin_W']) for a in rows]
    fixedT=[core.features(p,t['Tj_C'])['Pmpp_W'] for p,t in zip(pin,mpp['cells'])]
    iso40=[core.features(p,40.)['Pmpp_W'] for p in pin]
    isolated=[core.thermal_mpp(p,float(rows[0]['Tsink_C']),float(rows[0]['Rth_K_per_W'])) for p in pin]
    return {'same_array_MPP_temperatures_sum_cell_MPP_W':sum(fixedT),
            'isothermal40C_sum_cell_MPP_W':sum(iso40),
            'isolated_selfheated_cell_MPP_sum_W':sum(s['Pout_W'] for s in isolated),
            'isolated_selfheated_cell_Tj_C':[s['Tj_C'] for s in isolated],
            'same_temperature_bound_note':'An electrical upper bound only with temperatures frozen at this array optimum, independent cell loads and zero wire loss.',
            'isothermal40C_bound_note':'An electrical upper bound for the 40 C clamped network, independent cell loads and zero wire loss.',
            'isolated_thermal_note':'Reference with each cell independently at MPP and its own sink resistance, no lateral heat exchange; temperatures differ, so this is not asserted to bound the coupled thermal array.'}


def factorial_effects(summary):
    data=[r for r in summary if r['case_id'].startswith('F') and r['status']=='supported']
    names=['w_mm','angle_deg','offset','source_power_W','Tsink_C','Rth_K_per_W','topology']
    x=np.array([[1 if float(r['w_mm'])>15 else -1,
                 1 if float(r['angle_deg'])>20 else -1,
                 1 if float(r['offset_x_mm'])>2 else -1,
                 1 if float(r['source_power_W'])>40 else -1,
                 1 if float(r['Tsink_C'])>35 else -1,
                 1 if float(r['Rth_K_per_W'])>5.5 else -1,
                 1 if r['topology']=='2S2P_columns' else -1] for r in data])
    effects=[]
    for order in [1,2]:
        for inds in itertools.combinations(range(7),order):
            code=np.prod(x[:,inds],axis=1)
            row={'order':order,'factors':' x '.join(names[i] for i in inds),'n_joint_cases':len(data),
                 'definition':'2*mean(response*product(binary factor codes)); deterministic full factorial effect, no statistical uncertainty implied'}
            for y in ['Pport_W','Tj_max_C','end_to_end_efficiency_percent','relative_to_isothermal40C_percent']:
                row['effect_'+y]=float(2*np.mean(code*np.array([float(r[y]) for r in data])))
            effects.append(row)
    return effects


def run():
    start=time.perf_counter();cases=read_cases();records=[];summary=[];cells=[];curves=[];curvecells=[];failures=[]
    for case_id,rows in cases.items():
        top=topologies(int(rows[0]['nrows']),int(rows[0]['ncols']))
        if case_id.startswith('F'):top={k:v for k,v in top.items() if k in ('2S2P_rows','2S2P_columns')}
        for name,groups in top.items():
            meta=metadata(rows,name)
            try:
                net=make_model(rows,groups);s=net.optimum(17)
                iso=make_model(rows,groups,True);siso=iso.optimum(17)
                refs=independent_reference(rows,s)
                scan_delta=None
                if case_id.startswith('R_'):
                    fine=net.optimum(65);scan_delta=fine['Pport_W']-s['Pport_W'];s=fine
                    for mode,model in [('self_heated',net),('isothermal40C',iso)]:
                        for idx,state in enumerate(model.curve(81)):
                            curves.append({**meta,'mode':mode,'point':idx,**{k:v for k,v in public_state(state).items() if k!='cells' and not isinstance(v,(list,dict))}})
                            curvecells.extend({**meta,'mode':mode,'point':idx,**r} for r in state['cells'])
                retained=core.config()['eta_h']*s['Pin_total_W']
                source_balance=meta['source_power_W']-sum(meta[k] for k in ['fiber_loss_W','optics_loss_W','path_loss_W','gap_power_W','outside_power_W'])-(1-core.config()['eta_h'])*s['Pin_total_W']-s['Pport_W']-s['wire_loss_W']-s['heat_to_sink_total_W']
                scalar={k:v for k,v in public_state(s).items() if k!='cells' and not isinstance(v,(list,dict))}
                row={**meta,**scalar,'status':'supported','isothermal40C_Pport_W':siso['Pport_W'],
                     'selfheating_power_change_W':s['Pport_W']-siso['Pport_W'],
                     'relative_to_isothermal40C_percent':100*(s['Pport_W']/siso['Pport_W']-1),
                     'end_to_end_efficiency_percent':100*s['Pport_W']/meta['source_power_W'],
                     'same_T_independent_MPP_upper_bound_W':refs['same_array_MPP_temperatures_sum_cell_MPP_W'],
                     'electrical_mismatch_and_wire_gap_at_same_T_W':refs['same_array_MPP_temperatures_sum_cell_MPP_W']-s['Pport_W'],
                     'isothermal40C_independent_MPP_upper_bound_W':refs['isothermal40C_sum_cell_MPP_W'],
                     'isolated_selfheated_cell_MPP_reference_W':refs['isolated_selfheated_cell_MPP_sum_W'],
                     'full_source_energy_balance_residual_W':source_balance,
                     'refine65_minus_scan17_W':scan_delta,
                     'boundary_zero_voltage_cells':';'.join(map(str,s['lower_boundary_zero_voltage_cells_1based'])),
                     'boundary_zero_current_strings':';'.join(map(str,s['upper_boundary_zero_current_strings_1based']))}
                summary.append(row)
                for mode,state in [('self_heated',s),('isothermal40C',siso)]:
                    cells.extend({**meta,'mode':mode,**r} for r in state['cells'])
                records.append({'metadata':meta,'self_heated_supported_optimum':public_state(s),
                                'isothermal40C_supported_optimum':public_state(siso),
                                'independent_cell_references':refs,'scan65_minus_scan17_W':scan_delta})
            except (UnsupportedState,ValueError) as exc:
                failures.append({**meta,'status':'unsupported_or_solver_failure','reason':str(exc)})
                summary.append(failures[-1]);print('FAIL',case_id,name,str(exc),flush=True)
        if len(records)%20<5:print(case_id,len(records),'supported',len(failures),'failures',round(time.perf_counter()-start,2),'s',flush=True)
    write_csv(HERE/'results_summary.csv',summary);write_csv(HERE/'results_cells.csv',cells)
    write_csv(HERE/'representative_ivpv.csv',curves);write_csv(HERE/'representative_ivpv_cells.csv',curvecells)
    write_csv(HERE/'factorial_effects.csv',factorial_effects(summary))
    good=[r for r in summary if r['status']=='supported']
    validation={'expected_joint_networks':181,'completed':len(records),'failures':failures,
       'runtime_seconds':time.perf_counter()-start,'core_reference_sha256':core.REFERENCE_SHA256,
       'max_electrical_balance_residual_W':max(abs(r['electrical_balance_residual_W']) for r in good),
       'max_thermal_residual_W':max(abs(r['thermal_max_residual_W']) for r in good),
       'max_source_energy_balance_residual_W':max(abs(r['full_source_energy_balance_residual_W']) for r in good),
       'max_scan65_vs17_difference_W':max(abs(r['refine65_minus_scan17_W'] or 0.) for r in good),
       'optimum_residual_scope':'The unqualified maximum residual fields above cover 181 optima; representative curves are checked separately below.',
       'representative_curve_state_count':len(curves),
       'all_representative_curve_states_supported':all(r['forward_supported'] for r in curves),
       'max_curve_thermal_residual_W':max(abs(r['thermal_max_residual_W']) for r in curves),
       'max_curve_electrical_residual_W':max(abs(r['electrical_balance_residual_W']) for r in curves),
       'max_curve_intercepted_energy_residual_W':max(abs(r['full_energy_balance_residual_W']) for r in curves),
       'minimum_curve_cell_voltage_V':min(r['minimum_cell_voltage_V'] for r in curves),
       'minimum_curve_branch_current_A':min(r['minimum_branch_current_A'] for r in curves),
       'support_tolerance_note':'Exact mathematical domain is every Vcell>=0,Ibranch>=0,Vport>=0. Boundary-root roundoff accepted at 2e-7 V,2e-9 A; no state is clipped or given a reverse/bypass law.',
       'all_local_fixed_bus_thermally_stable':all(r['fixed_bus_locally_thermally_stable'] for r in good),
       'supported_boundary_limited_count':sum(not r['is_interior_supported_MPP'] for r in good),
       'objective':'Numerically searched/refined maximum actual PORT power on common all-cell V>=0,I>=0 support; not full-array GMPP.',
       'wire_thermal_boundary':'External common series resistance; 100% wire heat to environment, zero wire heat returned to cells.',
       'uniformity':'Each cell spatially uniform; only cell-to-cell intercepted total optical powers differ.',
       'factorial_definition':'64 six-factor Gaussian optical+thermal combinations x rows/columns topology = full 128-run seven-factor joint experiment.',
       'representative_curve_definition':'Nine beam-profile/condition combinations x five topologies x 81 support-domain states; selfheated and 40 C isothermal curves, each with cell states.',
       'scan_refinement_note':'Every supported interior local maximum on initial bus grid refined; nine representatives/five topologies checked on 65 vs17 grid. This numerical search is not a proof of global maximum outside the declared support.'}
    (HERE/'results.json').write_text(json.dumps({'validation':validation,'networks':records},indent=2),encoding='utf-8')
    (HERE/'validation_summary.json').write_text(json.dumps(validation,indent=2),encoding='utf-8')
    print(json.dumps(validation,indent=2),flush=True)


if __name__=='__main__':run()
