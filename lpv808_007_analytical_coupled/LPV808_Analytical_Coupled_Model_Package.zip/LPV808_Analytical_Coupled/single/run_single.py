"""Reproduce uniform-cell conditional electrical/thermal results.

Each single cell has one intercepted total Pin; no intra-cell irradiance network
is introduced. The five reference parameters come only from analytic_results.
Run: python single/run_single.py (from any directory).
"""
from pathlib import Path
import json
import sys
import hashlib
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from scipy.optimize import minimize_scalar

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import core_model as core

OUT = Path(__file__).resolve().parent
RLOAD = 8.8466
PINS = [2., 4., 8., 12., 16.]
TEMPERATURES = [20., 40., 60., 80., 100.]


def csv(name, rows):
    pd.DataFrame(rows).to_csv(OUT / name, index=False, float_format='%.15g')


def coupled_features(pin, sink, cfg):
    """MPP and endpoints of the full steady IV, with each point equilibrated."""
    mp = core.thermal_state(pin, sink, 'mpp', cfg)
    oc = core.thermal_state(pin, sink, 'open', cfg)
    sc = core.thermal_state(pin, sink, 'short', cfg)
    # A separate scalar maximization is an independent check of the MPPT
    # fixed-point construction on the thermally stable branch.
    opt = minimize_scalar(
        lambda v: -core.thermal_state(pin, sink, 'voltage', cfg, V_V=v)['Pout_W'],
        bounds=(0., oc['V_V']), method='bounded', options={'xatol': 1e-10})
    vf = float(opt.x)
    pc = core.thermal_state(pin, sink, 'voltage', cfg, V_V=vf)['Pout_W']
    return {**mp, 'coupled_Isc_A': sc['I_A'], 'coupled_Voc_V': oc['V_V'],
            'coupled_FF': mp['Pout_W'] / (sc['I_A'] * oc['V_V']),
            'Tj_short_C': sc['Tj_C'], 'Tj_open_C': oc['Tj_C'],
            'independent_steadyIV_max_P_W': pc,
            'independent_steadyIV_max_V_V': vf,
            'steadyIV_vs_MPPT_max_abs_error_W': abs(pc - mp['Pout_W'])}


def isothermal():
    grid, iv = [], []
    for t in TEMPERATURES:
        for pin in PINS:
            p = core.parameters(pin, t)
            f = core.features(pin, t)
            case = f'iso_T{t:g}_P{pin:g}'
            grid.append({'case_id': case, 'Tj_C': t, 'Pin_W': pin,
                         'thermal_regime': 'isothermal', **p, **f})
            for v in np.linspace(0., f['Voc_V'], 241):
                i = core.current(v, pin, t)
                if abs(i) < 1e-12:
                    i = 0.
                iv.append({'case_id': case, 'Tj_C': t, 'Pin_W': pin,
                           'thermal_regime': 'isothermal', 'V_V': v,
                           'I_A': i, 'Pout_W': v * i})
    csv('isothermal_grid.csv', grid)
    csv('isothermal_iv.csv', iv)
    return grid


def self_heating():
    summaries, iv = [], []
    for sink in [25., 45.]:
        for rth in [3., 8.]:
            cfg = core.config({'Rth_K_per_W': rth})
            for pin in [4., 8., 12., 16.]:
                case = f'steady_Ts{sink:g}_Rth{rth:g}_P{pin:g}'
                mp = coupled_features(pin, sink, cfg)
                res = core.thermal_state(pin, sink, 'resistor', cfg, Rload_ohm=RLOAD)
                summaries.append({'case_id': case, 'thermal_regime': 'full_steady',
                                  'Rload_ohm': np.nan, **mp})
                summaries.append({'case_id': case, 'thermal_regime': 'full_steady',
                                  'Rload_ohm': RLOAD, **res})
                for v in np.linspace(0., mp['coupled_Voc_V'], 241):
                    st = core.thermal_state(pin, sink, 'voltage', cfg, V_V=v)
                    # Freeze the entire comparison curve at the MPP's Tj.
                    fi = core.current(v, pin, mp['Tj_C'], cfg)
                    iv.append({'case_id': case, 'thermal_regime': 'full_steady',
                               **st, 'frozen_at_mpp_Tj_C': mp['Tj_C'],
                               'frozen_at_mpp_I_A': fi,
                               'frozen_at_mpp_Pout_W': v * fi,
                               'fixed_load_current_A': v / RLOAD})
    csv('self_heating_summary.csv', summaries)
    csv('self_heating_iv.csv', iv)
    loads = []
    for sink in [25., 45.]:
        for rth in [3., core.DEFAULT_CONFIG['Rth_K_per_W'], 8.]:
            cfg = core.config({'Rth_K_per_W': rth})
            for pin in np.linspace(2., 16., 57):
                for mode in ['mpp', 'resistor']:
                    loads.append({'Rload_ohm': RLOAD if mode == 'resistor' else np.nan,
                                  **core.thermal_state(pin, sink, mode, cfg, Rload_ohm=RLOAD)})
    csv('fixed_load_sweep.csv', loads)
    return summaries, iv


def reference_families():
    rows = []
    for tref in [25., 40., 55.]:
        cfg = core.anchor_family(tref)
        for sink in [25., 45.]:
            for pin in PINS:
                for mode in ['mpp', 'resistor']:
                    rows.append({'T_ref_C': tref,
                                 'Rload_ohm': RLOAD if mode == 'resistor' else np.nan,
                                 **core.thermal_state(pin, sink, mode, cfg, Rload_ohm=RLOAD)})
    csv('temperature_reference_family.csv', rows)
    return rows


def source_cases():
    path = ROOT / 'optics' / 'single_optical_cases.csv'
    if not path.exists():
        return {'status': 'pending_optical_input', 'path': str(path)}, []
    inputs = pd.read_csv(path)
    required = ['Pin_W', 'source_power_W', 'Tsink_C', 'Rth_K_per_W', 'case_id']
    if not set(required) <= set(inputs.columns):
        raise ValueError(f'Missing optical input columns: {set(required)-set(inputs.columns)}')
    rows, families, source_iv = [], [], []
    representative_ids = ['S000','S007','S018','S025','S038','S045','S056','S063']
    for raw in inputs.to_dict('records'):
        pin, sink = float(raw['Pin_W']), float(raw['Tsink_C'])
        cfg = core.config({'Rth_K_per_W': float(raw['Rth_K_per_W'])})
        st = coupled_features(pin, sink, cfg)
        res = core.thermal_state(pin, sink, 'resistor', cfg, Rload_ohm=RLOAD)
        optical_loss = float(raw['source_power_W']) - pin
        cell_escape = (1-cfg['eta_h'])*pin
        eta_source = 100 * st['Pout_W'] / float(raw['source_power_W'])
        row = {**raw, 'single_cell_internal_spatial_model': 'one_uniform_Pin',
               'thermal_regime': 'full_steady', 'T_ref_C': cfg['T_ref_C'],
               'Pin_model_extrapolation_outside_2_16W': pin < 2. or pin > 16.,
               **st, 'fixed_Rload_ohm': RLOAD,
               'fixed_load_Pout_W': res['Pout_W'], 'fixed_load_Tj_C': res['Tj_C'],
               'eta_source_percent': eta_source,
               'eta_cell_percent': st['electrical_efficiency_percent'],
               'source_to_electric_efficiency_percent': eta_source,
               'source_to_active_optical_loss_W': optical_loss,
               'cell_unretained_optical_W': cell_escape,
               'cell_retained_optical_W': cfg['eta_h']*pin,
               'source_energy_balance_residual_W': float(raw['source_power_W']) -
                   (optical_loss + cell_escape + st['Pout_W'] + st['Qheat_W'])}
        rows.append(row)
        if raw['case_id'] in representative_ids:
            for v in np.linspace(0., st['coupled_Voc_V'], 241):
                pt = core.thermal_state(pin, sink, 'voltage', cfg, V_V=v)
                fi = core.current(v, pin, st['Tj_C'], cfg)
                source_iv.append({**raw, 'thermal_regime':'full_steady', **pt,
                                  'frozen_at_mpp_Tj_C': st['Tj_C'],
                                  'frozen_at_mpp_I_A': fi,
                                  'frozen_at_mpp_Pout_W': v*fi,
                                  'fixed_load_current_A': v/RLOAD})
        # Reference-family uncertainty is independently reanchored; its Rth is
        # derived by that anchor, not the input case's chosen external Rth.
        for tref in [25., 40., 55.]:
            famcfg = core.anchor_family(tref)
            fs = core.thermal_state(pin, sink, 'mpp', famcfg)
            families.append({'case_id': raw['case_id'], 'T_ref_C': tref,
                             'source_power_W': raw['source_power_W'],
                             'Rth_interpretation': 'own_8W25C_MPPT_anchor', **fs})
    csv('coupled_source_summary.csv', rows)
    csv('coupled_source_reference_family.csv', families)
    csv('coupled_source_iv.csv', source_iv)
    return {'status': 'complete', 'rows': len(rows),
            'representative_iv_cases': representative_ids,
            'representative_iv_points': len(source_iv),
            'source_energy_balance_max_abs_residual_W':max(abs(r['source_energy_balance_residual_W']) for r in rows),
            'thermal_balance_max_abs_residual_K':max(abs(r['thermal_balance_residual_K']) for r in source_iv),
            'min_thermal_stability_margin':min(r['thermal_stability_margin'] for r in source_iv),
            'input_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}, rows


def dynamics():
    """Ideal electrical response, one lumped thermal state, Pin step at t=0.

    The electrical model has no capacitance, so power can jump while T remains
    continuous. Cth is an assumed scenario parameter, not a measured value.
    """
    rows, summaries = [], []
    sink = 25.
    cfg = core.config()
    rth, eta = cfg['Rth_K_per_W'], cfg['eta_h']
    pin0, pin1, end = 4., 12., 25.
    for mode in ['mpp', 'resistor']:
        initial = core.thermal_state(pin0, sink, mode, cfg, Rload_ohm=RLOAD)
        final = core.thermal_state(pin1, sink, mode, cfg, Rload_ohm=RLOAD)
        t0 = initial['Tj_C']
        st = lambda t, pin: core.electrical_state(pin, float(t), mode, cfg, Rload_ohm=RLOAD)
        post = st(t0, pin1)
        for cth in [.1, .3, .5]:
            case = f'dynamic_{mode}_Cth{cth:g}'
            def rhs(t, y):
                el = st(y[0], pin1)
                qout = (y[0] - sink) / rth
                po = el['Pout_W']
                return [(eta * pin1 - po - qout) / cth, eta * pin1, po, qout]
            sol = solve_ivp(rhs, (0., end), [t0, 0., 0., 0.], method='DOP853',
                            rtol=2e-10, atol=[1e-10, 1e-11, 1e-11, 1e-11],
                            dense_output=True, max_step=.1)
            if not sol.success:
                raise RuntimeError(sol.message)
            for t in [-1., -1e-6, 0.]:
                rows.append({'case_id': case, 'mode': mode, 'Cth_J_per_K': cth,
                             'T_sink_C':sink, 'Rth_K_per_W':rth, 'eta_h':eta,
                             'Rload_ohm': RLOAD if mode=='resistor' else np.nan,
                             't_s': t, 'step_side': 'pre', 'Pin_W': pin0,
                             'Tj_C': t0, **st(t0, pin0), 'Q_to_sink_W': (t0-sink)/rth,
                             'Qheat_W':eta*pin0-initial['Pout_W'], 'dTj_dt_K_per_s':0.,
                             'E_retained_J': 0., 'E_electric_J': 0., 'E_sink_J': 0.,
                             'E_stored_change_J': 0., 'energy_integral_residual_J': 0.})
            times = np.linspace(0., end, 2501)
            yy = sol.sol(times)
            ppower = []
            for k, t in enumerate(times):
                tj, ein, eelec, esink = yy[:, k]
                el = st(tj, pin1)
                ppower.append(el['Pout_W'])
                stored = cth * (tj - t0)
                rows.append({'case_id': case, 'mode': mode, 'Cth_J_per_K': cth,
                             'T_sink_C':sink, 'Rth_K_per_W':rth, 'eta_h':eta,
                             'Rload_ohm': RLOAD if mode=='resistor' else np.nan,
                             't_s': t, 'step_side': 'post', 'Pin_W': pin1,
                             'Tj_C': tj, **el, 'Q_to_sink_W': (tj-sink)/rth,
                             'Qheat_W':eta*pin1-el['Pout_W'],
                             'dTj_dt_K_per_s':(eta*pin1-el['Pout_W']-(tj-sink)/rth)/cth,
                             'E_retained_J': ein, 'E_electric_J': eelec, 'E_sink_J': esink,
                             'E_stored_change_J': stored,
                             'energy_integral_residual_J': stored - (ein-eelec-esink)})
            qnet = eta * pin1 - np.asarray(ppower) - (yy[0] - sink)/rth
            stored = cth * (yy[0, -1] - t0)
            trapfine = float(np.trapezoid(qnet, times))
            trapcoarse = float(np.trapezoid(qnet[::2], times[::2]))
            threshold = t0 + .6321205588 * (final['Tj_C'] - t0)
            crossed = np.flatnonzero(yy[0] >= threshold)
            tau = np.interp(threshold, yy[0], times) if len(crossed) else np.nan
            summaries.append({'case_id': case, 'mode': mode, 'Cth_J_per_K': cth,
                              'Rload_ohm': RLOAD if mode=='resistor' else np.nan,
                              'T_sink_C': sink, 'Rth_K_per_W': rth,
                              'initial_Pin_W': pin0, 'final_Pin_W': pin1,
                              'initial_Tj_C': t0, 'final_steady_Tj_C': final['Tj_C'],
                              'initial_Pout_W': initial['Pout_W'],
                              'immediate_poststep_Pout_W': post['Pout_W'],
                              'power_jump_at_continuous_T_W': post['Pout_W']-initial['Pout_W'],
                              'temperature_jump_C': 0., 'final_steady_Pout_W': final['Pout_W'],
                              't63_thermal_s': tau, 'end_time_s': end,
                              'end_T_error_to_steady_C': yy[0,-1]-final['Tj_C'],
                              'energy_integral_residual_J': stored-(yy[1,-1]-yy[2,-1]-yy[3,-1]),
                              'independent_trapezoid_residual_J_dt_0p01': stored-trapfine,
                              'independent_trapezoid_residual_J_dt_0p02': stored-trapcoarse,
                              'independent_trapezoid_richardson_residual_J': stored-(4*trapfine-trapcoarse)/3,
                              'E_stored_change_J': stored, 'E_retained_J': yy[1,-1],
                              'E_electric_J': yy[2,-1], 'E_sink_J': yy[3,-1]})
    csv('dynamic_step.csv', rows)
    csv('dynamic_summary.csv', summaries)
    return summaries


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    grid = isothermal()
    summary, iv = self_heating()
    family = reference_families()
    source_status, source = source_cases()
    dyn = dynamics()
    checks = []
    def check(name, value, tolerance):
        checks.append({'check': name, 'value': float(value), 'tolerance': tolerance,
                       'passed': bool(abs(value) <= tolerance)})
    check('reference_parameters_exactly_recovered_at_8W_Tref',
          max(abs(core.parameters(8.,40.)[k]-core.BASE[k]) for k in core.PARAMETER_KEYS), 1e-15)
    check('8W25C_MPPT_anchor_temperature_C', core.thermal_state(8.,25.)['Tj_C']-40., 1e-8)
    check('full_steady_IV_thermal_balance_max_K',
          max(abs(r['thermal_balance_residual_K']) for r in iv), 2e-8)
    check('independent_steady_IV_max_vs_MPPT_W',
          max(r.get('steadyIV_vs_MPPT_max_abs_error_W',0.) for r in summary), 1e-8)
    check('all_full_steady_IV_endpoints_temperature_equality_C',
          max(abs(r['Tj_short_C']-r['Tj_open_C']) for r in summary if r['mode']=='mpp'), 1e-10)
    check('dynamic_energy_integral_max_J', max(abs(r['energy_integral_residual_J']) for r in dyn), 1e-8)
    check('dynamic_independent_Richardson_energy_max_J',
          max(abs(r['independent_trapezoid_richardson_residual_J']) for r in dyn), 1e-6)
    check('dynamic_temperature_continuity_C', max(abs(r['temperature_jump_C']) for r in dyn), 0.)
    check('dynamic_final_temperature_max_error_C', max(abs(r['end_T_error_to_steady_C']) for r in dyn), .01)
    check('positive_heat_all_steady_W', min(0.,min(r['Qheat_W'] for r in summary)), 0.)
    anchors = [r for r in family if r['mode']=='mpp' and r['T_sink_C']==25. and r['Pin_W']==8.]
    check('Tref_family_same_anchor_power_W',max(abs(r['Pout_W']-core.BASE_FEATURES['Pmpp_W']) for r in anchors),1e-10)
    report = {'status': 'passed' if all(x['passed'] for x in checks) else 'failed',
              'reference_sha256': core.REFERENCE_SHA256,
              'reference_parameters': core.BASE, 'reference_features': core.BASE_FEATURES,
              'default_config': core.DEFAULT_CONFIG, 'fixed_resistance_ohm': RLOAD,
              'counts': {'isothermal_conditions':len(grid), 'steady_conditions':len(summary)//2,
                         'steady_iv_points':len(iv), 'reference_family_rows':len(family),
                         'dynamic_cases':len(dyn)}, 'source_cases': source_status,
              'checks':checks, 'dynamic_summary':dyn,
              'interpretation': {
                  'reference': 'Analytic 007 extraction, no joint fitting.',
                  'temperature': 'Tref40C is an assumed unknown-junction-temperature anchor; betaVoc is migrated conditionally.',
                  'thermal': 'Rth is derived from assumed eta_h=.9 and Tref using the 8W/25C/MPPT anchor; Cth .1/.3/.5 are assumptions.',
                  'spatial': 'One uniform Pin per single cell; source shape, angle and offset only set total intercepted Pin.',
                  'steady_iv': 'Every voltage point solves its own steady junction temperature; frozen comparison is separately labelled.',
                  'energy': 'Cth*dT/dt=eta_h*Pin-Pout-(Tj-Tsink)/Rth; eta_h represents net retained optical energy.'}}
    def json_finite(value):
        if isinstance(value, dict): return {k:json_finite(v) for k,v in value.items()}
        if isinstance(value, (list,tuple)): return [json_finite(v) for v in value]
        if isinstance(value, (float,np.floating)) and not np.isfinite(value): return None
        return value
    (OUT/'single_results.json').write_text(json.dumps(json_finite(report),ensure_ascii=False,indent=2,allow_nan=False))
    print(json.dumps({'status':report['status'],'counts':report['counts'],
                      'source_cases':source_status,'failed':[x for x in checks if not x['passed']]},indent=2))
    if report['status']!='passed':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
