"""Archive/provenance and selected conditional law audit, without a re-fit."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import core_model as core
from independent_kernels import BASE,REF,parameters,current,voltage,mpp,diode_residual

checks=[]
def ck(name,value,tol):checks.append({'check':name,'value':float(value),'tolerance':tol,'passed':bool(abs(value)<=tol)})
cfg=core.config()
ck('all five archive parameters exactly preserved',max(abs(core.BASE[k]-BASE[k]) for k in BASE),0.)
for k in BASE:ck('parameters(8W,Tref) exactly reproduces '+k,core.parameters(8.,40.)[k]-BASE[k],0.)
features=mpp(BASE)
for k,v in features.items():ck('original-equation Brent reference feature '+k,v-REF['main']['features'][k],8e-8)
states=[]
for pin,t in [(2.,0.),(8.,0.),(8.,40.),(16.,40.),(8.,100.),(16.,180.)]:
    p=parameters(pin,t,cfg);q=core.parameters(pin,t,cfg)
    for k in p:ck(f'conditional coefficient {k} Pin={pin} T={t}',(q[k]-p[k])/max(abs(p[k]),1e-30),2e-11)
    f=mpp(p);cf=core.features(pin,t,cfg)
    ck(f'Brent independent Pmpp Pin={pin} T={t}',cf['Pmpp_W']-f['Pmpp_W'],2e-10)
    ck(f'raw diode residual at Lambert MPP Pin={pin} T={t}',diode_residual(cf['Vmpp_V'],cf['Impp_A'],p),2e-12)
    ck(f'raw diode residual at Lambert Isc Pin={pin} T={t}',diode_residual(0.,cf['Isc_A'],p),2e-12)
    ck(f'raw diode residual at Lambert Voc Pin={pin} T={t}',diode_residual(cf['Voc_V'],0.,p),2e-10)
    states.append({'Pin_W':pin,'Tj_C':t,'independent_raw_equation_features':f,
                   'at_temperature_domain_boundary':bool(t in cfg['temperature_domain_C']),
                   'is_algebraic_reference_anchor':bool(pin==8 and t==40),
                   'is_independently_measured_P_T_condition':False,
                   'condition_note':'Tref40C is assumed; only ambient25C was recorded, so this is an algebraic anchor.'})
# betaVoc is imposed only at the reference intercepted power; other Pin changes
# the open-circuit law naturally through the diode equation.
for t in [0.,25.,40.,80.,140.,180.]:
    v=voltage(0.,parameters(8.,t,cfg))
    target=features['Voc_V']+cfg['beta_Voc_V_per_K']*(t-cfg['T_ref_C'])
    ck(f'8W imposed Voc temperature law T={t}',v-target,2e-12)
qref=cfg['eta_h']*8-features['Pmpp_W']
ck('conditional Rth anchor rise K',cfg['Rth_K_per_W']*qref-15.,3e-12)
out={'status':'passed' if all(c['passed'] for c in checks) else 'failed',
 'scope':'Numerical audit of archived analytical reference and declared extrapolation laws. No new fit or experimental validation.',
 'loaded_core_file':str(Path(core.__file__).resolve()),
 'reference_sha256':hashlib.sha256((ROOT/'input/analytic_results.json').read_bytes()).hexdigest(),
 'core_sha256':hashlib.sha256((ROOT/'core_model.py').read_bytes()).hexdigest(),
 'reference_parameters':BASE,'independent_reference_features':features,
 'inferred_ideality_scope':{'n_per_subcell_if_Tj25C_and_six_identical':BASE['a_V']/(6*8.617333262e-5*298.15),
                          'n_per_subcell_if_Tj40C_and_six_identical':BASE['a_V']/(6*8.617333262e-5*313.15),
                          'actual_junction_temperature_measured':False},
 'temperature_domain_C':cfg['temperature_domain_C'],
 'measurement_domain':'One nominal8W IV at ambient25C; actual Tj, Rth, Cth, eta_h, angular response and extensions were not measured.',
 'states':states,'checks':checks,'check_count':len(checks)}
(ROOT/'validation/reference_independent.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
print(json.dumps({'status':out['status'],'checks':len(checks),'failed':[c for c in checks if not c['passed']]},ensure_ascii=False))
if out['status']!='passed':raise SystemExit(1)
