"""Independent array audit with raw diode equations and nested scalar Brent."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
from scipy.optimize import root
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import core_model as core
from independent_kernels import parameters,diode_residual,array_at_t,thermal_matrix,array_stability

cfg=core.config();inputs=json.loads((ROOT/'array/results.json').read_text());networks=inputs['networks'];checks=[]
def ck(name,value,tol):checks.append({'check':name,'value':float(value),'tolerance':tol,'passed':bool(abs(value)<=tol)})
maxima={k:0. for k in ['diode_A','KCL_A','KVL_V','port_V','electrical_W','thermal_W','lateral_W','source_W','cell_heat_W']}
selected=[];chosen={('R_gaussian_B0','2S2P_rows'),('R_gaussian_B1','1S4P'),('R_gaussian_B1','2S2P_rows'),
 ('R_gaussian_B1','2S2P_columns'),('R_gaussian_B1','2S2P_diagonals'),('R_gaussian_B1','4S1P'),
 ('R_super_gaussian_m6_B1','2S2P_rows'),('R_top_hat_B1','2S2P_rows')}
for rec in networks:
    meta=rec['metadata'];s=rec['self_heated_supported_optimum'];rows=s['cells'];n=len(rows)
    pins=np.array([r['Pin_W'] for r in rows]);tt=np.array([r['Tj_C'] for r in rows]);vv=np.array([r['Vcell_V'] for r in rows]);ii=np.array([r['Icell_A'] for r in rows]);pp=vv*ii
    groups=[np.array(g,dtype=int)-1 for g in s['groups_1based']];ib=np.array(s['branch_currents_A']);rw=s['Rwire_ohm'];it=sum(ib)
    k=thermal_matrix(meta['nrows'],meta['ncols'],s['Rth_each_K_per_W'],s['G_lat_W_per_K']);sink=meta['Tsink_C']
    q=cfg['eta_h']*pins-pp+s['wire_heat_to_cells_W']/n
    for j,r in enumerate(rows):maxima['diode_A']=max(maxima['diode_A'],abs(diode_residual(vv[j],ii[j],parameters(pins[j],tt[j],cfg))))
    maxima['KCL_A']=max(maxima['KCL_A'],abs(s['Iport_A']-it),max(max(abs(ii[g]-ib[j])) for j,g in enumerate(groups)))
    maxima['KVL_V']=max(maxima['KVL_V'],max(abs(sum(vv[g])-s['Vbus_V']) for g in groups))
    maxima['port_V']=max(maxima['port_V'],abs(s['Vport_V']-(s['Vbus_V']-rw*it)))
    maxima['electrical_W']=max(maxima['electrical_W'],abs(sum(pp)-s['Pport_W']-rw*it*it))
    maxima['thermal_W']=max(maxima['thermal_W'],max(abs(k@(tt-sink)-q)))
    lap=k-np.diag(1/np.array(s['Rth_each_K_per_W']))
    maxima['lateral_W']=max(maxima['lateral_W'],abs(sum(lap@(tt-sink))))
    maxima['cell_heat_W']=max(maxima['cell_heat_W'],max(abs(q-np.array([r['Qcell_total_W'] for r in rows]))))
    source=meta['source_power_W'];loss=sum(meta[x] for x in ['fiber_loss_W','optics_loss_W','path_loss_W','gap_power_W','outside_power_W'])
    out=loss+(1-cfg['eta_h'])*sum(pins)+s['Pport_W']+s['wire_heat_to_environment_W']+sum((tt-sink)/np.array(s['Rth_each_K_per_W']))
    maxima['source_W']=max(maxima['source_W'],abs(source-out))
    pair=(meta['case_id'],meta['topology'])
    if pair not in chosen and not (meta['case_id'] in ['N2','N3'] and 'mixed' in meta['topology']):continue
    rl=s['Vport_V']/s['Iport_A'];b=array_at_t(pins,tt,groups,rl,rw,cfg)
    name='/'.join(pair)
    for key in ['Vbus_V','Vport_V','Iport_A','Pport_W']:ck(name+' independent nested Brent '+key,b[key]-s[key],3e-9)
    def residual(temp):
        z=array_at_t(pins,temp,groups,rl,rw,cfg)
        return k@(temp-sink)-(cfg['eta_h']*pins-z['Pcell_W'])
    sol=root(residual,tt+np.linspace(-.1,.1,n),method='hybr',options={'xtol':1e-10})
    ck(name+' independent electrothermal root residual W',max(abs(residual(sol.x))),2e-9)
    ck(name+' independent coupled Tj root C',max(abs(sol.x-tt)),5e-8)
    fixedload=array_stability(pins,tt,groups,rl,rw,cfg,s['Rth_each_K_per_W'],s['G_lat_W_per_K'],meta['nrows'],meta['ncols'])
    fixedbus=array_stability(pins,tt,groups,rl,rw,cfg,s['Rth_each_K_per_W'],s['G_lat_W_per_K'],meta['nrows'],meta['ncols'],bus_voltage=s['Vbus_V'])
    ck(name+' fixedbus stiffness independent eigenvalue W/K',-.3*fixedbus['max_real_eigenvalue_per_s']-s['fixed_bus_thermal_stiffness_min_real_W_per_K'],3e-7)
    checks.append({'check':name+' fixedload locally stable','max_real_eigenvalue_per_s':fixedload['max_real_eigenvalue_per_s'],'passed':fixedload['locally_stable']})
    checks.append({'check':name+' fixedbus locally stable','max_real_eigenvalue_per_s':fixedbus['max_real_eigenvalue_per_s'],'passed':fixedbus['locally_stable']})
    selected.append({'case_id':meta['case_id'],'topology':meta['topology'],'Pin_each_W':pins.tolist(),'independent_coupled_Tj_C':sol.x.tolist(),
      'actual_external_Rload_at_optimum_ohm':rl,'fixed_external_Rload_stability':fixedload,'fixed_bus_stability':fixedbus,
      'all_temperature_perturbations_supported':True,'temperature_domain_boundary_distance_K':float(min(min(tt),180-max(tt))),
      'support_boundary_distance_V':float(min(vv)),'current_boundary_distance_A':float(min(ib)),
      'scope':'Selected steady optimum is reproduced. Stability is for stated fixed bus or fixed external resistance; an unspecified MPPT controller has no supplied dynamic law.'})
for key,value in maxima.items():ck('181 networks independently reconstructed max '+key,value,3e-9)
ck('181 networks all represented',len(networks)-181,0.)
checks.append({'check':'all reported optima within common positive-generation domain','passed':all(r['self_heated_supported_optimum']['forward_supported'] for r in networks)})
out={'status':'passed' if all(x['passed'] for x in checks) else 'failed','check_count':len(checks),
 'scope':'Numerical physics and solver verification; no new experimental validation. Unknown reverse-bias, bypass and blocking laws are not invented.',
 'method':'Original exponential diode residuals for all181 actual states; independent KCL/KVL, energy and graph-Laplacian reconstruction; nested Brent electrical network and independently rooted temperature system at selected points; temperature finite-difference matrices for fixed load/bus.',
 'reference_sha256':core.REFERENCE_SHA256,'source_hashes':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in ['core_model.py','array/array_model.py','array/results.json']},
 'all_network_residual_maxima':maxima,'selected_independent_roots_and_dynamic_eigenvalues':selected,'checks':checks,
 'domain_notes':['All181 computed maxima are interior to the modeled all-cell positive-generation support. This is not a full reverse/bypass-network GMPP claim.',
 'At active Vcell=0 or Ibranch=0 boundaries, unsupported perturbations cannot establish a physical local stability law.',
 'Cth=.3J/K is per cell and assumed; multiplying Cth rescales eigenvalue time scales, not steady equilibrium.',
 'Thermal matrices include actual topology/load cross-temperature electrical coupling.']}
(ROOT/'validation/array_outputs_independent.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
print(json.dumps({'status':out['status'],'checks':len(checks),'selected':len(selected),'maxima':maxima,'failed':[x for x in checks if not x['passed']]},ensure_ascii=False))
if out['status']!='passed':raise SystemExit(1)
