"""Independent output audit: raw equations, thermal roots and energy quadrature."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
import pandas as pd
from scipy.optimize import brentq
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import core_model as core
from independent_kernels import parameters,diode_residual,mpp,load
checks=[]
def ck(name,value,tol):checks.append({'check':name,'value':float(value),'tolerance':tol,'passed':bool(abs(value)<=tol)})
cfg=core.config();src=pd.read_csv(ROOT/'single/coupled_source_summary.csv')
raw_res=[];heat_res=[]
for r in src.to_dict('records'):
    p=parameters(r['Pin_W'],r['Tj_C'],cfg)
    raw_res.append(diode_residual(r['V_V'],r['I_A'],p))
    heat_res.append((r['Tj_C']-r['Tsink_C'])/r['Rth_K_per_W']-(cfg['eta_h']*r['Pin_W']-r['Pout_W']))
ck('64 single source states original diode residual A',max(abs(np.array(raw_res))),2e-11)
ck('64 single source states independent thermal residual W',max(abs(np.array(heat_res))),2e-10)
ck('64 single source states each uses one scalar Pin',max(abs(src['Pin_W']-src['Pin_1_W'])),0.)
ck('64 single source states nrows*ncols=1',max(abs(src['nrows']*src['ncols']-1)),0.)
states=[]
for case in ['S000','S007','S018','S025','S038','S045','S056','S063']:
    r=src.loc[src.case_id==case].iloc[0].to_dict();pin=r['Pin_W'];sink=r['Tsink_C'];rth=r['Rth_K_per_W']
    def power(t):return mpp(parameters(pin,t,cfg))['Pmpp_W']
    t=brentq(lambda t:t-sink-rth*(cfg['eta_h']*pin-power(t)),sink,180.,xtol=1e-11,rtol=1e-14)
    ck(case+' independent nested Brent thermal Tj C',t-r['Tj_C'],2e-8)
    ck(case+' independent raw diode MPP W',power(t)-r['Pout_W'],2e-10)
    rl=r['fixed_Rload_ohm']
    tl=brentq(lambda t:t-sink-rth*(cfg['eta_h']*pin-load(pin,t,rl,cfg)['Pout_W']),sink,180.,xtol=1e-11,rtol=1e-14)
    ck(case+' independent nested Brent fixedload Tj C',tl-r['fixed_load_Tj_C'],2e-8)
    ck(case+' independent fixedload P W',load(pin,tl,rl,cfg)['Pout_W']-r['fixed_load_Pout_W'],2e-10)
    states.append({'case_id':case,'independent_Tj_mpp_C':t,'independent_Pmpp_W':power(t),
                   'independent_Tj_fixed_Rload_C':tl,'independent_Rload_ohm':rl})
dyn=pd.read_csv(ROOT/'single/dynamic_step.csv');summ=pd.read_csv(ROOT/'single/dynamic_summary.csv');dynamics=[]
for case,g in dyn.groupby('case_id'):
    r=summ.loc[summ.case_id==case].iloc[0].to_dict();g=g.loc[g.step_side=='post'].sort_values('t_s');t=g.t_s.to_numpy();temp=g.Tj_C.to_numpy()
    c=r['Cth_J_per_K'];sink=r['T_sink_C'];rth=r['Rth_K_per_W'];rl=r['Rload_ohm'];pin=r['final_Pin_W']
    # Integrate the exported physical powers independently of ODE energy states.
    net=cfg['eta_h']*g.Pin_W.to_numpy()-g.Pout_W.to_numpy()-(temp-sink)/rth
    stored=c*(temp[-1]-temp[0]);e1=float(np.trapezoid(net,t));e2=float(np.trapezoid(net[::2],t[::2]));rich=(4*e1-e2)/3
    ck(case+' independent energy Richardson residual J',stored-rich,2e-8)
    errs=[]
    for row in g.iloc[::125].to_dict('records'):
        st=mpp(parameters(pin,row['Tj_C'],cfg)) if r['mode']=='mpp' else load(pin,row['Tj_C'],rl,cfg)
        pw=st['Pmpp_W'] if r['mode']=='mpp' else st['Pout_W'];errs.append(pw-row['Pout_W'])
    ck(case+' original diode independent dynamic electrical samples W',max(abs(np.array(errs))),2e-10)
    eps=1e-3;tf=r['final_steady_Tj_C']
    def pw(tt):return mpp(parameters(pin,tt,cfg))['Pmpp_W'] if r['mode']=='mpp' else load(pin,tt,rl,cfg)['Pout_W']
    dp=(pw(tf+eps)-pw(tf-eps))/(2*eps);eig=-(1/rth+dp)/c
    checks.append({'check':case+' equilibrium thermal eigenvalue real<0','value':eig,'passed':bool(eig<0)})
    dynamics.append({'case_id':case,'independent_storage_J':stored,'independent_net_heat_integral_J_dt001':e1,
       'independent_net_heat_integral_J_dt002':e2,'independent_Richardson_residual_J':stored-rich,
       'eigenvalue_per_s':eig,'effective_time_constant_s':-1/eig,'load':r['mode'],
       'numerical_scope':'Temperature storage and quasistatic electrical response; no electrical bandwidth inference.'})
files=['core_model.py','single/run_single.py','single/coupled_source_summary.csv','single/dynamic_step.csv']
out={'status':'passed' if all(x['passed'] for x in checks) else 'failed','check_count':len(checks),
 'scope':'Independent numerical verification, not independent experiment or parameter calibration.',
 'method':'Archived coefficients; original exponential diode equation; nested scalar Brent for selected steady roots; physical-power trapezoid/Richardson energy integral independent of accumulated ODE energies.',
 'source_hashes':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in files},'selected_steady_states':states,
 'dynamic_energy_and_linear_stability':dynamics,'checks':checks}
(ROOT/'validation/single_outputs_independent.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
print(json.dumps({'status':out['status'],'checks':len(checks),'failed':[x for x in checks if not x['passed']]},ensure_ascii=False))
if out['status']!='passed':raise SystemExit(1)
