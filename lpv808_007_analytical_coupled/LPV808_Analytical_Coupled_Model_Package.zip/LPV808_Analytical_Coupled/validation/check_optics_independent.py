"""Independent optical checks; no model changes and no experimental validation."""
from pathlib import Path
import importlib.util, math, json, hashlib
import numpy as np
import pandas as pd
from functools import lru_cache
from scipy.integrate import quad

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('checked_beam',ROOT/'optics/beam_integrals.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
profiles=['gaussian','super_gaussian_m6','top_hat']
checks=[]
def ck(name,error,tolerance,**extra):
    checks.append(dict(check=name,absolute_error=abs(float(error)),tolerance=float(tolerance),passed=bool(abs(error)<=tolerance),**extra))

# Normalize by quadrature of the dimensionless radial integral, independent of
# the gamma-function normalization and of the model's Cartesian quadrature.
norms={}
for name in profiles:
    if name=='top_hat':den=math.pi*12**2
    else:
        m=2 if name=='gaussian' else 6
        den=2*math.pi*12**2*quad(lambda s:s*math.exp(-2*s**m),0,np.inf,epsabs=2e-14,epsrel=2e-13)[0]
    norms[name]=36/den
    ck(name+' central normalization via radial quadrature',b.normalization_density(36,12,name)-norms[name],2e-14)

# Direct receiver-plane density is independently written and includes a single
# projected cos. It is integrated in receiver x/y, not the transformed box.
def density(x,y,name,offset=(0,0),angle=0,w=12,power=36):
    co=math.cos(math.radians(angle));u=(x-offset[0])*co;v=y-offset[1]
    ss=(u*u+v*v)/w**2
    if name=='top_hat':return co*power/(math.pi*w*w)*float(ss<=1)
    m=2 if name=='gaussian' else 6
    den=2*math.pi*w*w*quad(lambda z:z*math.exp(-2*z**m),0,np.inf,epsabs=2e-14,epsrel=2e-13)[0]
    return co*power/den*math.exp(-2*ss**(m/2))

# Independent top-hat area from radial ray intervals: the production model
# instead integrates vertical disk slices. Split angle at box-corner rays.
def disk_rectangle_polar(rect,radius):
    x0,x1,y0,y1=rect
    pts=[0.,math.pi/2,math.pi,3*math.pi/2,2*math.pi]
    for x in [x0,x1]:
        for y in [y0,y1]:pts.append(math.atan2(y,x)%(2*math.pi))
    pts=sorted(set(pts))
    def radial_area(t):
        lo,hi=0.,radius
        for left,right,d in [(x0,x1,math.cos(t)),(y0,y1,math.sin(t))]:
            if abs(d)<1e-15:
                if not left<=0<=right:return 0.
            else:
                a,z=left/d,right/d
                lo=max(lo,min(a,z));hi=min(hi,max(a,z))
        return max(0.,hi*hi-lo*lo)/2 if hi>=lo else 0.
    return sum(quad(radial_area,a,z,epsabs=2e-10,epsrel=3e-12,limit=200)[0] for a,z in zip(pts[:-1],pts[1:]))

@lru_cache(maxsize=None)
def independent_density_constant(name,w,power):
    m=2 if name=='gaussian' else 6
    den=2*math.pi*w*w*quad(lambda z:z*math.exp(-2*z**m),0,np.inf,epsabs=2e-14,epsrel=2e-13)[0]
    return power/den

def independent_rect(rect,name,offset=(0,0),angle=0,w=12,power=36):
    if name=='top_hat':
        co=math.cos(math.radians(angle))
        rr=((rect[0]-offset[0])*co,(rect[1]-offset[0])*co,rect[2]-offset[1],rect[3]-offset[1])
        return power*disk_rectangle_polar(rr,w)/(math.pi*w**2)
    m=2 if name=='gaussian' else 6;co=math.cos(math.radians(angle));c=independent_density_constant(name,w,power)
    def line(x):
        return quad(lambda y:co*c*math.exp(-2*((((x-offset[0])*co)**2+(y-offset[1])**2)/(w*w))**(m/2)),rect[2],rect[3],epsabs=2e-11,epsrel=2e-11,limit=150)[0]
    return quad(line,rect[0],rect[1],epsabs=3e-11,epsrel=2e-11,limit=150)[0]

cases=[]
cells=b.cell_rectangles();rects=[c['bounds_mm'] for c in cells]
outer=[-10.15,10.15,-10.15,10.15]
for name in profiles:
    for offset,angle in [((0,0),0),((4,0),0),((4,4),0),((4,4),30),((4,4),60)]:
        result=b.receiver_budget(profile=name,offset_mm=offset,angle_deg=angle)
        pins=[independent_rect(rect,name,offset,angle) for rect in rects]
        aperture=independent_rect(outer,name,offset,angle)
        gap=aperture-sum(pins);outside=36-aperture
        errors=[abs(pins[j]-result[f'Pin_{j+1}_W']) for j in range(4)]
        ck(f'{name} offset={offset} angle={angle} per-cell integral',max(errors),2e-8)
        ck(f'{name} offset={offset} angle={angle} source budget',40-(4+sum(pins)+gap+outside),2e-10)
        ck(f'{name} offset={offset} angle={angle} gap',gap-result['gap_power_W'],2e-8)
        ck(f'{name} offset={offset} angle={angle} outside',outside-result['outside_power_W'],2e-8)
        cases.append(dict(profile=name,offset_mm=offset,angle_deg=angle,Pin_W=pins,active_W=sum(pins),gap_W=gap,outside_W=outside,minimum_budget_term_W=min(pins+[gap,outside]),maximum_per_cell_difference_W=max(errors)))

# For the independent receiver-plane integral, widen the x span by sec(theta):
# a second global cos multiplier would fail this check by 36*(1-cos(theta)).
for name in ['gaussian','super_gaussian_m6']:
    m=2 if name=='gaussian' else 6;c=norms[name]
    for angle in [0,30,60]:
        co=math.cos(math.radians(angle));extent=7*12
        def line(x):return quad(lambda y:co*c*math.exp(-2*(((x*co)**2+y*y)/144)**(m/2)),-extent,extent,epsabs=2e-10,epsrel=1e-10,limit=200)[0]
        integral=quad(line,-extent/co,extent/co,epsabs=2e-9,epsrel=1e-10,limit=200)[0]
        ck(f'{name} whole projected receiver-plane integral at {angle}deg',integral-36,5e-8,integral_W=float(integral))
for angle in [0,30,60]:
    co=math.cos(math.radians(angle));area=math.pi*(12/co)*12
    ck(f'top_hat whole projected ellipse integral at {angle}deg',co*norms['top_hat']*area-36,1e-12)

# Small square entirely inside a broad top-hat beam has Pin proportional to
# projected cosine. This tests local geometric response without any extra cos.
for angle in [0,30,60]:
    co=math.cos(math.radians(angle));expected=36*100*co/(math.pi*12**2)
    ck(f'top_hat single 10mm square interior cosine {angle}deg',b.rectangle_power((-5,5,-5,5),36,12,'top_hat',(0,0),angle)-expected,2e-12)

for key,kwargs in [('angle_90',{'angle_deg':90}),('negative_beam_power',{'beam_power_W':-1}),('nonpositive_radius',{'w_mm':0})]:
    try:b.rectangle_power((-5,5,-5,5),**kwargs)
    except ValueError:rejected=True
    else:rejected=False
    checks.append(dict(check=key+' invalid input rejected',passed=rejected))

# Final generated cases: recompute every row from independent geometry and
# direct integrals. Repeated thermal-boundary cases reuse the same optical key.
scenario_checks=[];cache={};scenario_records=[]
summary=pd.read_csv(ROOT/'optics/optical_case_summary.csv')
single=pd.read_csv(ROOT/'optics/single_optical_cases.csv')
long=pd.read_csv(ROOT/'optics/optical_power_cases.csv')
dynlong=pd.read_csv(ROOT/'optics/array_dynamic_inputs.csv')
dynamic=dynlong.drop_duplicates('case_id').copy()
for table,frame,longframe in [('array',summary,long),('single',single,None),('dynamic',dynamic,dynlong)]:
    expected_count={'array':77,'single':64,'dynamic':2}[table]
    ck(table+' final case count',len(frame)-expected_count,0)
    for _,r in frame.iterrows():
        nr,nc=int(r.nrows),int(r.ncols);gap=float(r.gap_mm);side=10.;pitch=side+gap
        rects_own=[]
        for row in range(nr):
            for col in range(nc):
                cx=(col-(nc-1)/2)*pitch;cy=((nr-1)/2-row)*pitch
                rects_own.append([cx-5,cx+5,cy-5,cy+5])
        outer_own=[-(nc*side+(nc-1)*gap)/2,(nc*side+(nc-1)*gap)/2,-(nr*side+(nr-1)*gap)/2,(nr*side+(nr-1)*gap)/2]
        profile=r.profile;w=float(r.w_mm);angle=float(r.angle_deg);offset=(float(r.offset_x_mm),float(r.offset_y_mm))
        source=float(r.source_power_W);eta=float(r.eta_fiber*r.eta_optics*r.eta_path);power=source*eta
        key=(profile,w,angle,offset,source,eta,nr,nc,gap)
        if key not in cache:
            pp=[independent_rect(rect,profile,offset,angle,w,power) for rect in rects_own]
            aa=independent_rect(outer_own,profile,offset,angle,w,power)
            cache[key]=(pp,aa-sum(pp),power-aa)
        pp,gg,oo=cache[key]
        if longframe is not None:
            lr=longframe[longframe.case_id==r.case_id].sort_values('cell')
            recorded=lr.Pin_W.to_numpy();count_ok=len(lr)==nr*nc
        else:recorded=np.asarray([float(r.Pin_W)]);count_ok=True
        err=float(np.max(np.abs(recorded-pp))) if count_ok else float('inf')
        budget=source-(float(r.fiber_loss_W)+float(r.optics_loss_W)+float(r.path_loss_W)+sum(pp)+gg+oo)
        aggregate=max(abs(float(r.active_power_W)-sum(pp)),abs(float(r.gap_power_W)-gg),abs(float(r.outside_power_W)-oo),abs(float(r.beam_power_W)-power))
        if table!='dynamic':
            aggregate=max(aggregate,max(abs(float(r[f'Pin_{j+1}_W'])-p) for j,p in enumerate(pp)))
        if longframe is not None:
            for column in ['source_power_W','active_power_W','gap_power_W','outside_power_W','beam_power_W']:
                aggregate=max(aggregate,float(np.max(np.abs(lr[column].to_numpy()-float(r[column])))))
            aggregate=max(aggregate,float(np.max(np.abs(lr.irradiance_W_cm2.to_numpy()-pp))))
        ck(table+' '+r.case_id+' all per-cell optical powers',err,2e-8)
        ck(table+' '+r.case_id+' source energy closure',budget,2e-10)
        ck(table+' '+r.case_id+' aggregate and long-form consistency',aggregate,2e-8)
        scenario_records.append(dict(table=table,case_id=r.case_id,cells=nr*nc,max_Pin_difference_W=err,aggregate_difference_W=aggregate,source_closure_W=budget,minimum_budget_term_W=min(pp+[gg,oo])))

report={
 'status':'passed' if all(c['passed'] for c in checks) else 'failed',
 'scope':'Independent numerical verification of optical geometry and conservation; not independent experimental accuracy.',
 'model_sha256':hashlib.sha256((ROOT/'optics/beam_integrals.py').read_bytes()).hexdigest(),
 'methods':['numerical radial normalization independent of Gamma closed form','adaptive receiver-plane Cartesian double integration independent of erf/Gauss-Legendre production integral','top-hat polar ray area independent of production vertical disk slices','whole projected receiver-plane and ellipse integration'],
 'cell_uniformity':'A beam integral supplies one intercepted total Pin per cell. The electrical/thermal model keeps each cell spatially uniform; no within-cell current mismatch is introduced.',
 'angle_scope':'Pure geometry for 0<=theta<90 degrees about the receiver y axis. Beam center offset is specified in receiver-plane coordinates, total beam-normal power is fixed, and cos(theta) appears once in projected density. Unknown AR angle response is not calibrated or applied.',
 'power_planes':'40 W source; 4 W upstream loss; 36 W receiver-plane beam; active+gap+outside=36 W. Fitted Iph already includes normal-incidence surface/electrical response, so no extra surface multiplier.',
 'gap_scope':'Finite 2x2 outer bounding rectangle is 20.3x20.3 mm for cell side10 mm and gap0.3 mm. Gap power is independently integrated aperture minus active; do not multiply by a second fill factor.',
 'cautions':['Zero intercepted power is valid for the optical integrator but outside the positive-Pin electrical extension.','Optical validity does not establish experimental validity at new electrical power or junction-temperature conditions.','Ideal circular Gaussian, m6 super-Gaussian and top-hat profiles and geometric projection omit measured wavefront, aberration, speckle, packaging shading and angle-dependent AR response.'],
 'checks':checks,'cases':cases,'final_generated_scenarios':{'cases':scenario_records,'array_count':len(summary),'single_count':len(single),'dynamic_count':len(dynamic),'unique_optical_integrals':len(cache),'long_form_array_cell_rows':len(long),'long_form_dynamic_cell_rows':len(dynlong),'source_chain_efficiency':0.98*0.96*0.96},
 'summary':{'check_count':len(checks),'failed_count':sum(not c['passed'] for c in checks),'max_per_cell_absolute_difference_W':max([c['maximum_per_cell_difference_W'] for c in cases]+[c['max_Pin_difference_W'] for c in scenario_records])}
}
(ROOT/'validation/optics_independent.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report['summary'],ensure_ascii=False));print(report['status'])
