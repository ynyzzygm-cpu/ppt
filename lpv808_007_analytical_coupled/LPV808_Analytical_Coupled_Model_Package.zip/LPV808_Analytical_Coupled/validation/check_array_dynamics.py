"""Independent original-equation electrical/thermal trajectory and energy audit."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
import pandas as pd
from scipy.integrate import simpson,solve_ivp
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import core_model as core
from independent_kernels import parameters,diode_residual,array_at_t,thermal_matrix,array_stability
cfg=core.config();report=json.loads((ROOT/'array/dynamic_summary.json').read_text());df=pd.read_csv(ROOT/'array/dynamic_timeseries.csv');checks=[];cases=[]
def ck(name,value,tol):checks.append({'check':name,'value':float(value),'tolerance':tol,'passed':bool(abs(value)<=tol)})
for case in report['cases']:
    name=case['topology'];g=df.loc[(df.topology==name)&(df.phase!='before_steady_t0minus')].copy()
    times=np.sort(g.time_s.unique());temps=np.array([g.loc[g.time_s==t].sort_values('cell').Tj_C.to_numpy() for t in times])
    pins=np.array(report['inputs']['D_after']['Pin_W']);beforepins=np.array(report['inputs']['D_before']['Pin_W'])
    meta=report['inputs']['D_after']['metadata'];rth=meta['Rth_K_per_W'];sink=meta['Tsink_C'];glat=meta['G_lat_W_per_K'];rw=meta['Rwire_ohm'];c=case['Cth_each_J_per_K'];rl=case['Rload_ohm']
    groups=[np.array(z,dtype=int)-1 for z in case['groups_1based']];k=thermal_matrix(2,2,rth,glat)
    qnet=[];port=[];wire=[];sinkpower=[];raw=[];kvl=[];electrical=[];load=[]
    for t in times:
        rows=g.loc[g.time_s==t].sort_values('cell');tt=rows.Tj_C.to_numpy();vv=rows.Vcell_V.to_numpy();ii=rows.Icell_A.to_numpy();pp=vv*ii
        z=rows.iloc[0];qnet.append(cfg['eta_h']*pins-pp-k@(tt-sink));port.append(z.Pport_W);wire.append(rw*z.Iport_A**2);sinkpower.append(sum((tt-sink)/rth))
        for j in range(4):raw.append(diode_residual(vv[j],ii[j],parameters(pins[j],tt[j],cfg)))
        kvl.extend(sum(vv[group])-z.Vbus_V for group in groups);load.append(z.Vport_V-rl*z.Iport_A);electrical.append(sum(pp)-z.Pport_W-rw*z.Iport_A**2)
    qnet=np.array(qnet);stored=c*(temps[-1]-temps[0]);trap=np.trapezoid(qnet,times,axis=0);simp=simpson(qnet,x=times,axis=0);simp2=simpson(qnet[::2],x=times[::2],axis=0)
    ck(name+' all dynamic points original diode residual A',max(abs(np.array(raw))),3e-11)
    ck(name+' all dynamic KVL V',max(abs(np.array(kvl))),3e-9)
    ck(name+' fixed actual load equation V',max(abs(np.array(load))),2e-12)
    ck(name+' all dynamic original electrical identity W',max(abs(np.array(electrical))),3e-9)
    ck(name+' independent percell Simpson energy residual J',max(abs(simp-stored)),1e-6)
    ck(name+' Simpson dt005 vs dt010 energy J',max(abs(simp-simp2)),1e-5)
    retained=cfg['eta_h']*sum(pins)*(times[-1]-times[0]);electric=simpson(port,x=times);ewire=simpson(wire,x=times);esink=simpson(sinkpower,x=times)
    whole=retained-electric-ewire-esink-sum(stored)
    ck(name+' whole control volume independent Simpson residual J',whole,2e-6)
    before=np.array([r['Tj_C'] for r in case['before_fixed_load_steady']['cells']]);ck(name+' T continuity at optical step K',max(abs(temps[0]-before)),0.)
    sampled_errors=[]
    for j in range(0,len(times),40):
        z=array_at_t(pins,temps[j],groups,rl,rw,cfg);r=g.loc[g.time_s==times[j]].iloc[0];sampled_errors.append(z['Pport_W']-r.Pport_W)
    ck(name+' independent nested Brent dynamic electrical samples W',max(abs(np.array(sampled_errors))),3e-9)
    def rhs(t,tt):
        z=array_at_t(pins,tt,groups,rl,rw,cfg)
        return (cfg['eta_h']*pins-z['Pcell_W']-k@(tt-sink))/c
    independent=solve_ivp(rhs,[times[0],times[-1]],before,method='DOP853',rtol=2e-10,atol=2e-11,max_step=.2,dense_output=True)
    if not independent.success:raise RuntimeError(independent.message)
    compare=times[::20];index=np.arange(len(times))[::20];err=max(abs(independent.sol(compare).T-temps[index]).flat)
    ck(name+' independently integrated trajectory max temperature difference K',err,2e-6)
    eq0=array_stability(beforepins,before,groups,rl,rw,cfg,rth,glat,2,2,c)
    end=np.array([r['Tj_C'] for r in case['after_fixed_load_steady_target']['cells']]);eq1=array_stability(pins,end,groups,rl,rw,cfg,rth,glat,2,2,c)
    checks.append({'check':name+' before/after actual-load eigenvalues stable','passed':eq0['locally_stable'] and eq1['locally_stable']})
    cases.append({'topology':name,'Rload_ohm':rl,'Cth_each_J_per_K':c,'sample_count':len(times),
      'independent_percell_storage_J':stored.tolist(),'independent_trapezoid_heat_integral_minus_storage_J':(trap-stored).tolist(),
      'independent_Simpson_heat_integral_minus_storage_J':(simp-stored).tolist(),'whole_retained_energy_J':retained,
      'independent_electrical_energy_J':float(electric),'independent_external_wire_energy_J':float(ewire),'independent_sink_energy_J':float(esink),
      'independent_whole_energy_residual_J':float(whole),'independent_trajectory_solver':'DOP853, rtol2e-10, atol2e-11, maxstep.2s, nested raw-equation Brent electrical network',
      'trajectory_max_temperature_difference_K':float(err),'initial_actual_load_stability':eq0,'final_actual_load_stability':eq1,
      'dynamic_scope':'Low-frequency quasi-static electrical network coupled to lumped thermal nodes; no measured capacitance, control-loop or signal bandwidth.'})
out={'status':'passed' if all(x['passed'] for x in checks) else 'failed','check_count':len(checks),
 'scope':'Numerical conservation, convergence and local stability audit; not experimental validation.',
 'source_hashes':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in ['array/array_model.py','array/dynamic_array.py','array/dynamic_summary.json','array/dynamic_timeseries.csv']},
 'cases':cases,'checks':checks,'domain':'All audited trajectories stay inside all-cell V>=0,I>=0 and 0..180C domain. Unknown reverse/bypass laws are not evaluated.'}
(ROOT/'validation/array_dynamic_independent.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps({'status':out['status'],'checks':len(checks),'failed':[x for x in checks if not x['passed']]},ensure_ascii=False))
if out['status']!='passed':raise SystemExit(1)
