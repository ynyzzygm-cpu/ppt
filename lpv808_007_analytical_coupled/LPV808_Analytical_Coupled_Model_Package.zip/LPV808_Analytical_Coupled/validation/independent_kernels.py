"""Independent numerical audit kernels: raw diode equation and nested Brent.

These kernels do not call the production Lambert-W inverse, array root solver,
or thermal fixed-point solver. Parameters are reconstructed from the archived
analytical reference and the declared conditional scenario, never re-fitted.
"""
from pathlib import Path
import json
import math
import numpy as np
from scipy.optimize import brentq

ROOT = Path(__file__).resolve().parents[1]
REF = json.loads((ROOT/'input/analytic_results.json').read_text())
BASE = {k: REF['main']['parameters'][k] for k in ['Iph_A','I0_A','a_V','Rs_ohm','Rsh_ohm']}


def diode_residual(v, i, p):
    u = v + p['Rs_ohm']*i
    return p['Iph_A'] - p['I0_A']*np.expm1(u/p['a_V']) - u/p['Rsh_ohm'] - i


def current(v, p):
    # Generation points require no diode inverse or Lambert W.
    if abs(diode_residual(v,0.,p))<2e-13:return 0.
    return brentq(lambda i: diode_residual(v,i,p), 0., p['Iph_A'], xtol=5e-15, rtol=1e-14)


def voltage(i, p):
    upper = p['a_V']*math.log1p(p['Iph_A']/p['I0_A'])
    u = brentq(lambda u: p['Iph_A']-p['I0_A']*math.expm1(u/p['a_V'])-u/p['Rsh_ohm']-i,
               0., upper, xtol=5e-15, rtol=1e-14)
    return u - p['Rs_ohm']*i


BASE_VOC = voltage(0.,BASE)


def parameters(pin, t, cfg):
    dt = t-cfg['T_ref_C']
    a = BASE['a_V']*(t+273.15)/(cfg['T_ref_C']+273.15)
    iph = BASE['Iph_A']*(1+cfg['alpha_Iph_per_K']*dt)
    rs = BASE['Rs_ohm']*(1+cfg['gamma_Rs_per_K']*dt)
    vr = BASE_VOC+cfg['beta_Voc_V_per_K']*dt
    i0 = BASE['I0_A'] if abs(dt)<1e-12 else (iph-vr/BASE['Rsh_ohm'])/math.expm1(vr/a)
    return {'Iph_A':iph*pin/cfg['P_ref_W'],'I0_A':i0,'a_V':a,'Rs_ohm':rs,'Rsh_ohm':BASE['Rsh_ohm']}


def mpp(p):
    voc = voltage(0.,p)
    def dp(v):
        i=current(v,p);u=v+i*p['Rs_ohm']
        g=p['I0_A']/p['a_V']*math.exp(u/p['a_V'])+1/p['Rsh_ohm']
        return i-v*g/(1+p['Rs_ohm']*g)
    vm=brentq(dp,0.,voc,xtol=5e-14,rtol=1e-14);im=current(vm,p)
    return {'Isc_A':current(0.,p),'Voc_V':voc,'Vmpp_V':vm,'Impp_A':im,'Pmpp_W':vm*im}


def load(pin,t,rload,cfg):
    p=parameters(pin,t,cfg)
    if rload==0:
        v=0.;i=current(0.,p)
    else:
        i=brentq(lambda i:diode_residual(rload*i,i,p),0.,p['Iph_A'],xtol=5e-15,rtol=1e-14);v=rload*i
    return {'V_V':v,'I_A':i,'Pout_W':v*i}


def array_at_t(pins,temperatures,groups,rload,rwire,cfg,bus_voltage=None):
    """Nested scalar original-equation solution on all-cell generation support."""
    pars=[parameters(p,t,cfg) for p,t in zip(pins,temperatures)]
    iscs=np.array([current(0.,p) for p in pars])
    vocs=np.array([voltage(0.,p) for p in pars])
    lower=max(sum(voltage(min(iscs[g]),pars[j]) for j in g) for g in groups)
    upper=min(sum(vocs[g]) for g in groups)
    def branches(bus):
        out=[]
        for g in groups:
            imax=min(iscs[g]); vmax=sum(vocs[g])
            def eq(i):return sum(voltage(i,pars[j]) for j in g)-bus
            if abs(vmax-bus)<2e-11:i=0.
            elif abs(eq(imax))<2e-11:i=imax
            else:i=brentq(eq,0.,imax,xtol=5e-15,rtol=1e-14)
            out.append(i)
        return np.array(out)
    if bus_voltage is None:
        bus=brentq(lambda u:u-(rwire+rload)*sum(branches(u)),lower,upper,xtol=5e-14,rtol=1e-14)
    else:
        bus=bus_voltage
    ib=branches(bus);ii=np.zeros(len(pins))
    for k,g in enumerate(groups):ii[g]=ib[k]
    vv=np.array([voltage(i,p) for i,p in zip(ii,pars)]);it=sum(ib)
    return {'Vbus_V':bus,'Vport_V':bus-rwire*it,'Iport_A':it,'Pport_W':(bus-rwire*it)*it,
            'wire_loss_W':rwire*it*it,'Vcell_V':vv,'Icell_A':ii,'Pcell_W':vv*ii,'branch_currents_A':ib,
            'support_bus_min_isothermal_V':lower,'support_bus_max_isothermal_V':upper}


def thermal_matrix(nrows,ncols,rth,glat):
    n=nrows*ncols;rth=np.broadcast_to(np.asarray(rth,dtype=float),(n,))
    k=np.diag(1/rth)
    for row in range(nrows):
        for col in range(ncols):
            a=row*ncols+col
            for b in ([a+1] if col+1<ncols else [])+([a+ncols] if row+1<nrows else []):
                k[a,a]+=glat;k[b,b]+=glat;k[a,b]-=glat;k[b,a]-=glat
    return k


def array_stability(pins,temperatures,groups,rload,rwire,cfg,rth,glat,nrows,ncols,cth=.3,fwire=0.,weights=None,bus_voltage=None):
    t=np.array(temperatures,dtype=float);n=len(t);weights=np.ones(n)/n if weights is None else np.array(weights)
    def gen(tt):
        s=array_at_t(pins,tt,groups,rload,rwire,cfg,bus_voltage)
        return -s['Pcell_W']+fwire*s['wire_loss_W']*weights
    j=np.zeros((n,n));eps=1e-3
    for k in range(n):
        ta=t.copy();tb=t.copy();ta[k]-=eps;tb[k]+=eps;j[:,k]=(gen(tb)-gen(ta))/(2*eps)
    k=thermal_matrix(nrows,ncols,rth,glat)
    dyn=(j-k)/np.broadcast_to(np.array(cth),(n,))[:,None]
    eig=np.linalg.eigvals(dyn)
    return {'dynamic_matrix_per_s':dyn.tolist(),'eigenvalues_real_per_s':eig.real.tolist(),
            'eigenvalues_imag_per_s':eig.imag.tolist(),'max_real_eigenvalue_per_s':float(max(eig.real)),
            'locally_stable':bool(max(eig.real)<0),'Cth_each_J_per_K':np.broadcast_to(np.array(cth),(n,)).tolist(),
            'load': 'fixed_bus_voltage' if bus_voltage is not None else 'fixed_external_resistance',
            'Rload_ohm':rload,'temperature_difference_step_K':eps}
