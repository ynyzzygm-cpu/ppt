808 nm 六结GaAs激光光伏电池 解析法基线的联合光热电与阵列研究

基线与范围
主参数从input/analytic_results.json的main.parameters读取，为007号Five Points解析法五参数，未采用原联合标定或GA结果。参考8W扫描的电流NRMSE为0.57099%，该值不代表不同功率/温度的预测精度。
用户固定约束：单体片内辐照均匀，不建立片内电热微单元。光束积分仅产生每片一个Pin及平均辐照强度；阵列仅考虑各片之间差异。study_config.json保存此约束。

主情景
Tref40°C不是实测结温；实际测试记录只有环境25°C。betaVoc=-0.00815V/K来自另一六结808nm器件文献迁移，alphaIph和Rs温系置0、Rsh恒定均为情景。eta_h=.9，Rth参考5.43722732249K/W是以8W/sink25/理想MPPT重新锚定得到；Cth=.3J/K/片是假设。
上游eta_fiber=.98,eta_optics=.96,eta_path=.96，乘积.903168。投影几何只计一次cos(theta)。不再额外施加填充因子或正常入射反射损失。角响应暂只含几何投影，未移植裸GaAs菲涅耳损耗。
每片10x10mm，gap=.3mm，四片2x2和九片3x3。横向热导.03W/K，公共互联电阻.02ohm，线损热量散到环境、不返回单体。机壳/外溢光加热散热器未建，热沉是给定边界。

结果与文件
single：25个给定温度/功率组合、16组自热边界、64源端六因素联合工况、8组完整自热IV、3个Tref族、6个动态对照。
array：181个实际电热网络=128个七因子组合(64光热边界x行/列2S2P)+45代表光束/边界/拓扑+8个九片。另保存9代表x5拓扑x81点x自热/40°C等温=7290个曲线状态及逐片数据。
所有阵列电热工作点联立求KVL/KCL、实际ViIi及热矩阵，端口P=(U-I Rwire)I。独立单体MPP之和不是实际阵列输出。same_T_independent_MPP_upper_bound_W是在各片实际阵列工作温度冻结后的独立MPP电上界；isolated_selfheated_cell_MPP_reference_W边界不同，不作严格上界。
阵列仅计算所有Vi>=0、各支路Ik>=0的共同发电支撑域。域内最大值不声称未知反偏/旁路全域GMPP。曲线端点未必是真正端口短路/开路。主181个最优点均为支持域内点。
dynamic_array：源32→48W与偏移(0,0)→(4,4)mm同时发生，w12mm/40°保持，实际约14.167ohm固定负载。每步求当前温度下电网络，再推进4节点热ODE。全程支持域内，温度连续，电输出允许瞬时跳变。动态为热响应，不用于电信号带宽推断。

目录
input 原始007选定数据、解析结果与文献来源
optics 光束库、光学工况及预算
single 单体脚本与结果
array 电热网络/扫描/动态脚本与结果
analysis 全因子对比、交互、预算及示例设计约束
validation 独立原方程/Brent/积分核验，759项通过
review 物理与实现审查
report 最终Word，20幅可编辑图表及整片热图，英文Times New Roman、中文宋体

复算
python -m pip install -r requirements.txt
python optics/build_optical_cases.py
python single/run_single.py
python array/run_array_study.py
python array/dynamic_array.py
python analysis/analyze_joint.py
python build_report.py
按上述顺序在解压目录执行。脚本会更新同目录结果。数值库/硬件会影响运行时间和末位浮点数，不改变报告有效显示位。生成Word无需LibreOffice；要检查排版可用LibreOffice或Word渲染，缺字体设备会替代显示。

交互量
analysis中主效应=2beta，二阶平均差中之差=4beta，beta=mean(y*xA*xB)，x为±1编码。array/factorial_effects.csv使用常用2beta交互效应，勿与4beta表混淆。均为确定性情景对比，不是实验置信区间或显著性检验。

验证
759项仅证明源码及数值实现的一致性、守恒与抽查稳定性；新的功率/温度/光束/阵列工况仍需实物验证。主温度参考、热阻热容、各效率均未从单条I-V中辨识。独立核验原始二极管和热矩阵、光学几何积分与独立DOP853重积分；不等同于重复真实实验。
