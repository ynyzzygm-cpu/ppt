"""Independent numerical audit; no parameter fitting or model mutation.
Run from any directory: python review/audit_core.py.
"""
from pathlib import Path
import sys,json
import numpy as np
from scipy.optimize import minimize_scalar
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import core_model as m

def audit():
    residual=inverse=voc_error=0.
    minimum={k:float('inf') for k in m.PARAMETER_KEYS}
    for power in [2.,4.,8.,12.,16.]:
        for temperature in [0.,20.,40.,60.,80.,100.,180.]:
            p=m.parameters(power,temperature)
            for k,v in p.items(): minimum[k]=min(minimum[k],v)
            f=m.features(power,temperature)
            vv=np.linspace(0.,f['Voc_V'],501)
            ii=m.current(vv,p)
            uu=vv+ii*p['Rs_ohm']
            residual=max(residual,float(np.max(np.abs(ii-m.current_internal_u(uu,p)))))
            inverse=max(inverse,float(np.max(np.abs(m.voltage_from_parameters(ii,p)-vv))))
            if power==8.:
                expected=m.BASE_FEATURES['Voc_V']+m.DEFAULT_CONFIG['beta_Voc_V_per_K']*(temperature-40.)
                voc_error=max(voc_error,abs(f['Voc_V']-expected))
    rows=[]
    for power in [4.,8.,12.,16.]:
        for sink in [25.,45.]:
            for resistance in [3.,8.]:
                c=m.config({'Rth_K_per_W':resistance})
                sm=m.thermal_state(power,sink,'mpp',c)
                so=m.thermal_state(power,sink,'open',c)
                ss=m.thermal_state(power,sink,'short',c)
                curve=[m.thermal_state(power,sink,'voltage',c,V_V=float(v)) for v in np.linspace(0.,so['V_V'],101)]
                opt=minimize_scalar(lambda v:-m.thermal_state(power,sink,'voltage',c,V_V=v)['Pout_W'],bounds=(0.,so['V_V']),method='bounded',options={'xatol':1e-10})
                exact=m.thermal_state(power,sink,'voltage',c,V_V=opt.x)
                rows.append({'Pin_W':power,'Tsink_C':sink,'Rth_K_per_W':resistance,
                    'Tj_mpp_C':sm['Tj_C'],'Tj_open_short_C':so['Tj_C'],
                    'open_short_temperature_difference_K':ss['Tj_C']-so['Tj_C'],
                    'mpp_full_curve_minus_thermal_mpp_W':exact['Pout_W']-sm['Pout_W'],
                    'minimum_thermal_stability_margin':min(x['thermal_stability_margin'] for x in curve),
                    'maximum_thermal_balance_residual_K':max(abs(x['thermal_balance_residual_K']) for x in curve)})
    base_exact=all(m.parameters(8.,40.)[k]==v for k,v in m.BASE.items())
    result={'reference_sha256':m.REFERENCE_SHA256,'loaded_core':str(Path(m.__file__).resolve()),
       'baseline_exact_parameter_equality':base_exact,'reference_parameters':m.BASE,
       'anchor':m.thermal_state(8.,25.),'isothermal_checks':{
       'powers_W':[2,4,8,12,16],'temperatures_C':[0,20,40,60,80,100,180],
       'points_per_IV':501,'max_implicit_current_residual_A':residual,
       'max_voltage_inverse_roundtrip_error_V':inverse,'max_8W_linear_Voc_error_V':voc_error,
       'minimum_parameters':minimum},'fully_equilibrated_IV_checks':rows,
       'thermal_mpp_equivalence': 'Along a thermally stable branch dPe/dV=(partial Pe/partial V)/(1+Rth*partial Pe/partial T); hence isothermal MPP solved together with heat balance is also the full steady IV maximum.',
       'limits':['Conditional numerical validation, not additional experimental validation.','Single positive intercepted Pin and one uniform temperature per cell.','No reverse-bias, bypass or off-source Pin=0 behavior is validated.']}
    assert base_exact
    assert residual<1e-10 and inverse<1e-9 and voc_error<1e-9
    assert all(x>0 for x in minimum.values())
    assert max(abs(x['mpp_full_curve_minus_thermal_mpp_W']) for x in rows)<1e-8
    assert min(x['minimum_thermal_stability_margin'] for x in rows)>0
    assert max(x['maximum_thermal_balance_residual_K'] for x in rows)<1e-7
    return result

if __name__=='__main__':
    result=audit()
    path=Path(__file__).with_name('core_numerical_audit.json')
    path.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(path)
