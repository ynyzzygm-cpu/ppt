from pathlib import Path
import json,itertools
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[1];OUT=Path(__file__).resolve().parent
S=pd.read_csv(ROOT/'single/coupled_source_summary.csv');A=pd.read_csv(ROOT/'array/results_summary.csv');F=A[A.family=='factorial_6factors'].copy()

def codes(df,array=False):
 d={}
 for k in ['w_mm','angle_deg','source_power_W','Tsink_C','Rth_K_per_W']:
  vals=sorted(df[k].unique());assert len(vals)==2;d[k]=np.where(df[k]==vals[-1],1.,-1.)
 d['offset']=np.where(df.offset_x_mm>0,1.,-1.)
 if array:d['topology']=np.where(df.topology=='2S2P_columns',1.,-1.)
 return d

def effects(df,response,array=False):
 c=codes(df,array);rows=[];n=len(df)
 for order in [1,2]:
  for names in itertools.combinations(c,order):
   x=np.prod([c[k] for k in names],axis=0);b=float(np.mean(df[response]*x))
   rows.append({'order':order,'factors':' x '.join(names),'N':n,'response':response,'beta':b,'factorial_effect_2beta':2*b,'averaged_DID_4beta':4*b if order==2 else np.nan,'main_high_minus_low':2*b if order==1 else np.nan})
 return pd.DataFrame(rows)
E=effects(S,'Pout_W');E.to_csv(OUT/'single_joint_effects.csv',index=False)
EA=effects(F,'Pport_W',True);EA.to_csv(OUT/'array_joint_effects.csv',index=False)
# Grouped two-way response means (all other factors averaged).
for label,df,y in [('single',S,'Pout_W'),('array',F,'Pport_W')]:
 d=df.copy();d['offset_level_mm']=d.offset_x_mm
 d.groupby(['w_mm','offset_level_mm'])[y].mean().reset_index().to_csv(OUT/f'{label}_width_offset_response.csv',index=False)
 d.groupby(['source_power_W','Rth_K_per_W'])[y].mean().reset_index().to_csv(OUT/f'{label}_power_Rth_response.csv',index=False)
G=F.pivot(index='case_id',columns='topology',values='Pport_W');G['columns_minus_rows_W']=G['2S2P_columns']-G['2S2P_rows'];G.reset_index().to_csv(OUT/'grouping_difference.csv',index=False)
# Full source energy budget at each representative output point.
rep=A[A.family=='representative'].copy();bud=[]
for _,r in rep.iterrows():
 d={k:r[k] for k in ['case_id','topology','source_power_W']}
 d.update({k:float(r[k]) for k in ['fiber_loss_W','optics_loss_W','path_loss_W','outside_power_W','gap_power_W','optical_unretained_W','heat_to_sink_total_W','wire_loss_W','Pport_W']})
 d['sum_partition_W']=sum(d[k] for k in ['fiber_loss_W','optics_loss_W','path_loss_W','outside_power_W','gap_power_W','optical_unretained_W','heat_to_sink_total_W','wire_loss_W','Pport_W'])
 d['source_closure_W']=d['source_power_W']-d['sum_partition_W'];bud.append(d)
pd.DataFrame(bud).to_csv(OUT/'source_energy_budgets.csv',index=False)
# Conditional optimization under a chosen illustrative temperature threshold.
feasible=[]
for lim in [60,80,100]:
 valid=F[F.Tj_max_C<=lim]
 for topo,group in valid.groupby('topology'):
  row=group.loc[group.Pport_W.idxmax()];feasible.append({'illustrative_Tmax_C':lim,'topology':topo,**{k:row[k] for k in ['case_id','Pport_W','Tj_max_C','source_power_W','w_mm','angle_deg','offset_x_mm','Tsink_C','Rth_K_per_W','end_to_end_efficiency_percent']}})
pd.DataFrame(feasible).to_csv(OUT/'conditional_design_choices.csv',index=False)
summary={'single_cases':len(S),'array_networks':len(A),'array_factorial_cases':len(F),'single_Pout_range_W':[float(S.Pout_W.min()),float(S.Pout_W.max())],'single_Tj_range_C':[float(S.Tj_C.min()),float(S.Tj_C.max())],'array_factorial_Pout_range_W':[float(F.Pport_W.min()),float(F.Pport_W.max())],'array_factorial_Tmax_range_C':[float(F.Tj_max_C.min()),float(F.Tj_max_C.max())],'single_strongest_second_order_DID':E[E.order==2].assign(magnitude=lambda x:abs(x.averaged_DID_4beta)).sort_values('magnitude',ascending=False).head(5).drop(columns=['magnitude','main_high_minus_low']).to_dict('records'),'array_strongest_second_order_DID':EA[EA.order==2].assign(magnitude=lambda x:abs(x.averaged_DID_4beta)).sort_values('magnitude',ascending=False).head(5).drop(columns=['magnitude','main_high_minus_low']).to_dict('records'),'grouping_max_difference_W':float(G.columns_minus_rows_W.abs().max()),'source_budget_max_abs_residual_W':float(max(abs(x['source_closure_W']) for x in bud)),'factorial_effect_definition':'binary +/-1 beta=mean(y*product codes); main difference=2beta; second-order averaged difference-in-differences=4beta. Do not confuse 4beta with DOE interaction effect 2beta. Deterministic scenario contrasts; no statistical confidence/p-values.'}
(OUT/'joint_analysis.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False))
print(json.dumps(summary,ensure_ascii=False,allow_nan=False))
