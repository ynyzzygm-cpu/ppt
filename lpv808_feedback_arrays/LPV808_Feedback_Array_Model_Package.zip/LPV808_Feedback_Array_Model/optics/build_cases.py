"""Build the agreed 128 optical inputs; no electrical/thermal model edits."""
from pathlib import Path
import json,csv,hashlib,sys
import numpy as np
from optics import cells_geometry,beam_cell_powers,independent_capture_checks,circle_rectangle,gaussian_rectangle

ROOT=Path(__file__).resolve().parent.parent
OUT=Path(__file__).resolve().parent
CONTRACT=ROOT/'study_contract.json'

def token(x):return f'{float(x):g}'.replace('.','p')

def main():
    cfg=json.loads(CONTRACT.read_text());cases=[];geometries={};quadchecks=[]
    for R,C in cfg['layouts']:
        geometry=cells_geometry(R,C,cfg['cell_side_mm'],cfg['gap_mm'])
        geometries[f'R{R}C{C}']=geometry
        for beam in ['Gaussian','TopHat']:
            for uniform in [True,False]:
                quadchecks.append(independent_capture_checks(R,C,beam,uniform,cfg['cell_side_mm'],cfg['gap_mm']))
                for policy,levels in [('received_fixed',cfg['mean_received_power_W']),('source_fixed',cfg['source_power_sweep_W'])]:
                    for value in levels:
                        kw={'meanPin_W':value} if policy=='received_fixed' else {'Ps_W':value}
                        d=beam_cell_powers(R,C,beam,uniform,policy,eta_chain=cfg['eta_chain'],
                                          side_mm=cfg['cell_side_mm'],gap_mm=cfg['gap_mm'],**kw)
                        ending=f'received_mean_{token(value)}' if policy=='received_fixed' else f'source_Ps_{token(value)}'
                        d['id']=d['case_id']=f"R{R}C{C}_{d['profile']}_{ending}"
                        d['is_main_case']=policy=='received_fixed' and value==cfg['representative_mean_received_W']
                        d['target_meanPin_W']=float(value) if policy=='received_fixed' else None
                        d['target_Ps_W']=float(value) if policy=='source_fixed' else None
                        cases.append(d)
    meta={'schema_version':'1.0','contract_file':str(CONTRACT),'contract_sha256':hashlib.sha256(CONTRACT.read_bytes()).hexdigest(),
          'units':{'length':'mm','power':'W','irradiance':'W/cm2 for min_G/max_G; Pin per 1cm2 cell numerically equals cell-average W/cm2',
                   'CV_G':'population standard deviation / mean; dimensionless',
                   'fractions_of_Ps':'source-normalized; active+gap+outside+chain_loss=1',
                   'fractions_of_Pbeam':'after-chain beam-normalized; active+gap+outside=1'},
          'geometry_by_layout':geometries,'main_case_count':sum(c['is_main_case'] for c in cases),'case_count':len(cases),
          'comparison_policy_descriptions':{'received_fixed':'Fix total active-area received power N*target_meanPin; source power differs by capture.',
                                            'source_fixed':'Fix source Ps before eta_chain; active received power differs by beam capture.'},
          'Gaussian_uniform_reference_limitation':'Ideal zero-extra-loss equalization after actual Gaussian active-area capture. Same actual Gaussian capture and source/loss budget as paired nonuniform case; not a truly uniform Gaussian or a characterized homogenizer.',
          'intra_cell_policy':cfg['intra_cell_irradiance'],'cases':cases}
    (OUT/'cases.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8')
    fields=['case_id','R','C','N','profile','uniform','comparison_policy','is_main_case','meanPin_W','totalPin_W','Ps_W','Pbeam_W',
            'active_W','gap_loss_W','outside_loss_W','chain_loss_W','CV_G','minPin_W','maxPin_W','power_balance_residual_W']
    with (OUT/'cases_summary.csv').open('w',newline='',encoding='utf8') as f:
        wr=csv.DictWriter(f,fieldnames=fields);wr.writeheader()
        for d in cases:wr.writerow({k:d[k] for k in fields})
    tests=[]
    def check(name,passed,details=None):tests.append({'name':name,'passed':bool(passed),'details':details})
    check('Expected case count 128',len(cases)==128,len(cases));check('Expected main case count 16',sum(c['is_main_case'] for c in cases)==16)
    check('Unique case IDs',len({c['case_id'] for c in cases})==len(cases))
    maxbal=max(abs(c['power_balance_residual_W']) for c in cases)
    check('All source power balances',maxbal<1e-9,{'max_abs_W':maxbal})
    check('All source/beam fractions sum to one',all(abs(sum(c['fractions_of_Ps'].values())-1)<1e-13 and abs(sum(c['fractions_of_Pbeam'].values())-1)<1e-13 for c in cases))
    check('All power inputs nonnegative',all(min(c['powers'])>=0 and min(c['fractions_of_Ps'].values())>=0 for c in cases))
    check('All row-major matrices/powers agree',all(np.array_equal(np.array(c['Pin_matrix_W']).ravel(),c['powers']) for c in cases))
    check('All received-fixed targets met',all(abs(c['meanPin_W']-c['target_meanPin_W'])<1e-11 for c in cases if c['comparison_policy']=='received_fixed'))
    check('All source-fixed targets met',all(c['Ps_W']==c['target_Ps_W'] for c in cases if c['comparison_policy']=='source_fixed'))
    check('All uniform profiles equal-power per cell',all(c['CV_G']<1e-13 for c in cases if c['uniform']))
    pairs=[]
    for d in cases:
        if d['beam']=='Gaussian' and d['uniform']:
            partner=next(c for c in cases if c['case_id']==d['case_id'].replace('Gaussian_uniform_reference','Gaussian_nonuniform'))
            pairs.append(abs(d['Ps_W']-partner['Ps_W'])<1e-12 and abs(d['totalPin_W']-partner['totalPin_W'])<1e-11 and d['fractions_of_Pbeam']==partner['fractions_of_Pbeam'])
    check('Gaussian ideal reference preserves actual capture and source/loss budget',all(pairs),{'pair_count':len(pairs)})
    for q in quadchecks:check(f"independent quadrature {q['R']}x{q['C']} {q['beam']} uniform={q['uniform']}",q['passed'],q)
    check('Known full circle rectangle area',abs(circle_rectangle((-3,3,-3,3),2)['fraction']-1)<1e-10)
    check('Known fully covered unit square in unit circle',abs(circle_rectangle((-.5,.5,-.5,.5),1)['fraction']-1/np.pi)<1e-13)
    check('Known quarter unit circle',abs(circle_rectangle((0,2,0,2),1)['fraction']-.25)<1e-10)
    check('Known Gaussian full quadrant',abs(gaussian_rectangle((0,20,0,20),1)['fraction']-.25)<1e-14)
    check('No overlap circle rectangle',circle_rectangle((2,3,2,3),1)['fraction']==0)
    val={'passed':all(t['passed'] for t in tests),'test_count':len(tests),'checks':tests,
         'max_quadrature_fraction_error':max(q['max_absolute_fraction_error'] for q in quadchecks),'max_balance_error_W':maxbal,
         'case_count':len(cases),'main_case_count':sum(c['is_main_case'] for c in cases)}
    (OUT/'validation.json').write_text(json.dumps(val,indent=2),encoding='utf8')
    notes='''Optical input map conventions
- R rows/C columns, row0 positive y, each complete cell 10mm square, gap0.3mm.
- Gaussian w is the 1/e^2 intensity radius. Exact rectangle integrals use erf products.
- Actual Gaussian uses w=.60*sqrt(LxLy), center(.10Lx,.07Ly). Its uniform reference equalizes the same active-area captured total; it is an ideal reference, not an actual uniform Gaussian or calibrated homogenizer.
- Uniform TopHat is a centered circle of radius1.02*halfdiagonal covering the entire frame. Nonuniform TopHat uses radius .60*sqrt(LxLy) and center(.10Lx,.07Ly).
- TopHat circle/rectangle integration uses adaptive vertical-strip overlap quadrature with geometry breakpoints, checked by independently split horizontal strips; Gaussian integrals checked by numerical 2D integration.
- Ps is before eta_chain=.9; Pbeam=.9Ps is beam power at receiver plane before finite aperture capture. Active+gap+outside=Pbeam, and active+gap+outside+chainloss=Ps. Fractions are explicitly separately normalized by Ps and Pbeam.
- active is power incident on cells, gap is illumination of inter-cell gaps inside the rectangular outer frame, outside is all beam power outside that frame. Active is not absorbed optical power.
- Every electrical input is a cell-area integrated scalar. No claim about within-cell electrical/thermal response to spatial irradiance is supported by this scalar map.
- Same received-power comparison isolates mismatch at equal total active incident power but needs different Ps. Same-source comparison includes profile-specific capture differences.
- cases.json includes 128 unique cases, with the 16 meanPin8W cases flagged is_main_case. Source levels40/80/120/160W are before chain transmission. All beam maps use the same geometry across a paired comparison.
'''
    (OUT/'notes.txt').write_text(notes,encoding='utf8')
    print(json.dumps({k:val[k] for k in ['passed','test_count','case_count','main_case_count','max_quadrature_fraction_error','max_balance_error_W']},indent=2))
    if not val['passed']:
        print(json.dumps([t for t in tests if not t['passed']],indent=2));raise SystemExit(1)

if __name__=='__main__':main()
