"""Full 128-case area-averaged irradiance atlas; no input/model mutation."""
from pathlib import Path
import os,json,math,hashlib
ROOT=Path(__file__).resolve().parent.parent
OUT=Path(__file__).resolve().parent/'atlas'
OUT.mkdir(exist_ok=True)
os.environ.setdefault('MPLCONFIGDIR',str(OUT/'mplconfig'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
from matplotlib.text import Text

FONTS=Path(os.environ.get('LPV_FONT_DIR','/workspace/work/lpv_response_figures/fonts'))
for name in ['Times.TTF','Timesbd.TTF','Timesi.TTF','Timesbi.TTF','SimSun-Regular.ttf']:
    if (FONTS/name).exists():fm.fontManager.addfont(str(FONTS/name))
for family in ['Times New Roman','SimSun']:
    fm.findfont(fm.FontProperties(family=family),fallback_to_default=False)
plt.rcParams.update({'font.family':['Times New Roman','SimSun'],'font.size':9,
 'axes.unicode_minus':False,'pdf.fonttype':42,'ps.fonttype':42,'figure.facecolor':'white',
 'savefig.facecolor':'white','text.color':'#15252f','axes.edgecolor':'#6d7b86',
 'xtick.color':'#344651','ytick.color':'#344651'})

PROFILES=['Gaussian_uniform_reference','Gaussian_nonuniform','TopHat_uniform','TopHat_nonuniform']
LABELS={'Gaussian_uniform_reference':'Gaussian 均匀参照（理想均分）',
        'Gaussian_nonuniform':'Gaussian 非均匀光束',
        'TopHat_uniform':'TopHat 均匀光束（宽圆覆盖）',
        'TopHat_nonuniform':'TopHat 非均匀光束（有限圆斑）'}

def bbox_audit(fig):
    fig.canvas.draw();ren=fig.canvas.get_renderer();W,H=fig.canvas.get_width_height()
    bboxes=[];bad=[]
    for a in fig.findobj(match=Text):
        if not a.get_visible() or not a.get_text():continue
        b=a.get_window_extent(ren)
        if not np.isfinite([b.x0,b.y0,b.x1,b.y1]).all():continue
        d={'text':a.get_text(),'bbox_normalized':[b.x0/W,b.y0/H,b.x1/W,b.y1/H]}
        bboxes.append(d)
        if b.x0 < -.5 or b.y0 < -.5 or b.x1>W+.5 or b.y1>H+.5:bad.append(d)
    return {'valid':len(bad)==0,'text_bbox_count':len(bboxes),'outside_page':bad,
            'overall_text_bbox_normalized':[min(b['bbox_normalized'][0] for b in bboxes),
              min(b['bbox_normalized'][1] for b in bboxes),max(b['bbox_normalized'][2] for b in bboxes),
              max(b['bbox_normalized'][3] for b in bboxes)]}


def main():
    source=ROOT/'optics/cases.json';resultfile=ROOT/'arrays/results.json'
    data=json.loads(source.read_text());arr=json.loads(resultfile.read_text())
    cases=data['cases'];primary={d['case_id']:d for d in arr['results'] if d['connection']=='primary'}
    assert len(cases)==128 and len(primary)==128
    vals=np.concatenate([np.array(c['powers'])/(c['geometry']['side_mm']/10)**2 for c in cases])
    vmin=0.;vmax=2*math.ceil(float(vals.max())/2)
    norm=Normalize(vmin,vmax,clip=False);cmap=plt.get_cmap('viridis')
    pdfdir=Path(os.environ.get('LPV_OUTPUT_DIR','/workspace/output' if Path('/workspace/output').exists() else str(ROOT/'output')))
    pdfpath=pdfdir/'LPV808_All_Case_Irradiance_Atlas.pdf'
    pdfpath.parent.mkdir(exist_ok=True)
    pages=[];drawn=[]
    layouts=[(3,3),(4,4),(4,5),(5,5)]
    with PdfPages(pdfpath,metadata={'Title':'808 nm 六结 GaAs 光伏阵列：全128工况面积平均辐照度图谱',
                                  'Author':'Laser photovoltaic simulation study',
                                  'Subject':'16页；128工况；完整电池面积平均辐照度，含支持域最大功率和边界标记'}) as pdf:
        for R,C in layouts:
            for profile in PROFILES:
                page=len(pages)+1
                selected=[]
                for policy,levels in [('received_fixed',[2.,4.,6.,8.]),('source_fixed',[40.,80.,120.,160.])]:
                    for value in levels:
                        matches=[c for c in cases if c['R']==R and c['C']==C and c['profile']==profile
                                 and c['comparison_policy']==policy and
                                 (abs(c['target_meanPin_W']-value)<1e-12 if policy=='received_fixed' else abs(c['target_Ps_W']-value)<1e-12)]
                        assert len(matches)==1
                        selected.append(matches[0])
                fig=plt.figure(figsize=(297/25.4,210/25.4),dpi=120)
                fig.text(.055,.965,f'{R}×{C} 阵列｜{LABELS[profile]}',fontsize=17,va='top',weight='bold')
                fig.text(.055,.924,f'主连接 {R}S{C}P；固定每片冷端25°C；Pmax为正向支持域中的最大输出。统一全局色标，所有色块无插值、无隐藏截断。',fontsize=9.2,va='top')
                fig.text(.055,.883,'同收光策略：固定所有电池总入射功率 N×mean Pin，各光束按捕获效率反算源功率。',fontsize=10,va='center',weight='bold')
                fig.text(.055,.452,'同源功率策略：固定链路之前的 Ps，计入链路、间隙和阵列外溢光，实际 mean Pin 随捕获率变化。',fontsize=10,va='center',weight='bold')
                pagecases=[]
                for n,case in enumerate(selected):
                    row,col=divmod(n,4);left=.055+col*.2115;width=.177
                    bottom=.535 if row==0 else .105;height=.24
                    ax=fig.add_axes([left,bottom,width,height])
                    G=np.array(case['Pin_matrix_W'])/(case['geometry']['side_mm']/10)**2
                    image=ax.imshow(G,cmap=cmap,norm=norm,origin='upper',interpolation='nearest',aspect='equal')
                    ax.set_xticks(range(C),labels=[str(c) for c in range(C)],fontsize=8)
                    ax.set_yticks(range(R),labels=[str(r) for r in range(R)],fontsize=8)
                    ax.set_xlabel('列 c',fontsize=8,labelpad=2);ax.set_ylabel('行 r',fontsize=8,labelpad=2)
                    ax.tick_params(length=0,pad=3)
                    ax.set_xticks(np.arange(-.5,C,.999999999999),minor=True)
                    ax.set_yticks(np.arange(-.5,R,.999999999999),minor=True)
                    ax.grid(which='minor',color='white',linewidth=.65,alpha=.85)
                    ax.tick_params(which='minor',bottom=False,left=False)
                    for rr in range(R):
                        for cc in range(C):
                            color='black' if norm(G[rr,cc])>.64 else 'white'
                            ax.text(cc,rr,f'{G[rr,cc]:.2f}',ha='center',va='center',fontsize=8.4 if C<5 else 7.6,color=color)
                    yy=.845 if row==0 else .414
                    cx=left+width/2
                    fixedtitle=f'mean Pin = {case["target_meanPin_W"]:g} W' if row==0 else f'Ps = {case["target_Ps_W"]:g} W'
                    fig.text(cx,yy,fixedtitle,ha='center',va='center',fontsize=11,weight='bold')
                    result=primary[case['case_id']]
                    fig.text(cx,yy-.027,f'Ps={case["Ps_W"]:.2f} W   mean Pin={case["meanPin_W"]:.3f} W',ha='center',va='center',fontsize=8.5)
                    boundary=not result['is_interior_supported_MPP']
                    mark='边界受限' if boundary else '支持域内极值'
                    fig.text(cx,yy-.051,f'Pmax={result["Pmax_W"]:.2f} W  ·  {mark}',ha='center',va='center',fontsize=8.4,
                             color='#a13c24' if boundary else '#254d42')
                    pagecases.append({'case_id':case['case_id'],'row_in_page':row,'col_in_page':col,
                                      'comparison_policy':case['comparison_policy'],'meanPin_W':case['meanPin_W'],
                                      'Ps_W':case['Ps_W'],'Pmax_supported_W':result['Pmax_W'],
                                      'boundary_limited':boundary,'minimum_G_W_cm2':float(G.min()),
                                      'maximum_G_W_cm2':float(G.max())})
                    drawn.append(case['case_id'])
                cax=fig.add_axes([.925,.145,.016,.585])
                cb=fig.colorbar(ScalarMappable(norm=norm,cmap=cmap),cax=cax)
                cb.set_label('G / (W/cm²)',fontsize=9,labelpad=8);cb.ax.tick_params(labelsize=8,length=3)
                cb.set_ticks(np.arange(0,vmax+1e-9,4 if vmax>=20 else 2))
                fig.text(.055,.056,'每个数字和色块仅为一个完整六结电池的面积平均入射辐照度；不表示片内温度场或片内辐照细节。行列索引从0起，行0位于上方。',fontsize=8.4,va='center')
                fig.text(.055,.033,'Gaussian均匀参照是同实际截获总功率后的理想等分，未计实际匀光器附加损耗。标“边界受限”的Pmax不称全网GMPP。',fontsize=8.4,va='center')
                fig.text(.975,.015,f'{page} / 16',ha='right',fontsize=8.5)
                audit=bbox_audit(fig)
                if not audit['valid']:raise AssertionError(f'Page {page} text overflow: {audit["outside_page"]}')
                pdf.savefig(fig)
                preview=OUT/f'page_{page:02d}_R{R}C{C}_{profile}.png'
                fig.savefig(preview,dpi=145)
                plt.close(fig)
                pages.append({'page':page,'R':R,'C':C,'profile':profile,'case_ids':[d['case_id'] for d in pagecases],
                              'cases':pagecases,'preview_png':str(preview),'bbox_valid':audit['valid'],
                              'bbox_audit':audit})
    manifest={'pdf_path':str(pdfpath),'page_count':len(pages),'total_case_blocks':len(drawn),'unique_case_count':len(set(drawn)),
              'all_128_cases_shown_once':len(drawn)==128 and len(set(drawn))==128 and set(drawn)=={c['case_id'] for c in cases},
              'all_bbox_valid':all(p['bbox_valid'] for p in pages),'paper':'A4 landscape 297x210 mm',
              'global_color_norm_W_cm2':{'vmin':vmin,'vmax':vmax,'actual_min':float(vals.min()),'actual_max':float(vals.max()),
                                        'clip':False,'cmap':'viridis','interpolation':'nearest'},
              'power_annotation_definition':'Pmax from actual arrays/results.json, primary connection, limited to supported forward-generation domain; explicit boundary flag.',
              'case_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
              'array_result_sha256':hashlib.sha256(resultfile.read_bytes()).hexdigest(),
              'font_files_referenced_not_bundled':[str(FONTS/f) for f in ['Times.TTF','Timesbd.TTF','Timesi.TTF','Timesbi.TTF','SimSun-Regular.ttf']],
              'font_family':'English/digits Times New Roman; Chinese SimSun (宋体); embedded subsets in PDF.',
              'intra_cell_limitation':'Full complete-cell area-average incident irradiance only; not within-cell thermal or electrical field.',
              'pages':pages}
    assert manifest['all_128_cases_shown_once'] and manifest['all_bbox_valid'] and len(pages)==16
    (OUT/'atlas_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({k:manifest[k] for k in ['pdf_path','page_count','total_case_blocks','unique_case_count','all_128_cases_shown_once','all_bbox_valid','global_color_norm_W_cm2']},indent=2))

if __name__=='__main__':main()
