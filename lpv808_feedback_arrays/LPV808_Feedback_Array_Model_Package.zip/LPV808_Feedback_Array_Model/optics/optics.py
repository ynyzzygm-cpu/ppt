"""Area-integrated beam maps for the agreed rectangular complete-cell geometry.

Coordinates are in mm, powers in W. Gaussian w is the 1/e^2 intensity radius.
All electrical cell inputs are area averages; intra-cell fields are not resolved.
"""
from functools import lru_cache
from math import erf, exp, pi, sqrt, hypot
import copy
import numpy as np
from scipy.integrate import quad, dblquad


def cells_geometry(R, C, side_mm=10.0, gap_mm=0.3):
    R, C = int(R), int(C)
    if R < 1 or C < 1 or side_mm <= 0 or gap_mm < 0:
        raise ValueError('Positive integer rows/columns/side and nonnegative gap required.')
    side_mm, gap_mm = float(side_mm), float(gap_mm)
    Lx, Ly = C * side_mm + (C - 1) * gap_mm, R * side_mm + (R - 1) * gap_mm
    pitch = side_mm + gap_mm
    cells = []
    for r in range(R):
        for c in range(C):
            xc, yc = (c - (C - 1) / 2) * pitch, ((R - 1) / 2 - r) * pitch
            cells.append({'index': r*C+c, 'row': r, 'col': c, 'xc_mm': xc, 'yc_mm': yc,
                          'x0_mm': xc-side_mm/2, 'x1_mm': xc+side_mm/2,
                          'y0_mm': yc-side_mm/2, 'y1_mm': yc+side_mm/2,
                          'area_mm2': side_mm**2})
    return {'R':R, 'C':C, 'N':R*C, 'side_mm':side_mm, 'gap_mm':gap_mm, 'pitch_mm':pitch,
            'Lx_mm':Lx, 'Ly_mm':Ly, 'outer_bounds_mm':[-Lx/2,Lx/2,-Ly/2,Ly/2],
            'outer_area_mm2':Lx*Ly, 'active_area_mm2':R*C*side_mm**2,
            'geometrical_fill_factor':R*C*side_mm**2/(Lx*Ly),
            'row_convention':'row 0 at positive y; columns increasing x; row-major powers', 'cells':cells}


def _gaussian_1d(a,b,mu,w):
    z = sqrt(2)/w
    fraction = .5*(erf(z*(b-mu))-erf(z*(a-mu)))
    moment = mu*fraction + w/(2*sqrt(2*pi))*(exp(-2*((a-mu)/w)**2)-exp(-2*((b-mu)/w)**2))
    return fraction,moment


def gaussian_rectangle(bounds, w_mm, offset_mm=(0.,0.)):
    """Return normalized power fraction and x/y first moments (mm)."""
    x0,x1,y0,y1 = map(float,bounds);cx,cy=map(float,offset_mm);w=float(w_mm)
    if w <= 0 or x1 < x0 or y1 < y0: raise ValueError('Invalid Gaussian/rectangle.')
    fx,mx=_gaussian_1d(x0,x1,cx,w);fy,my=_gaussian_1d(y0,y1,cy,w)
    return {'fraction':fx*fy,'moment_x_mm':mx*fy,'moment_y_mm':my*fx}


def _circle_integrals(bounds, radius_mm, offset_mm=(0.,0.), axis='x', _force_quad=False):
    """Circle/rectangle area and first moments; independent horizontal/vertical strips.

    Every crossing of a rectangle edge and the circle is an explicit integration
    breakpoint, in addition to the circle center and clipped support endpoints.
    """
    x0,x1,y0,y1=map(float,bounds);cx,cy=map(float,offset_mm);rad=float(radius_mm)
    if rad <= 0 or x1 < x0 or y1 < y0: raise ValueError('Invalid circle/rectangle.')
    if axis=='y':
        z=_circle_integrals((y0,y1,x0,x1),rad,(cy,cx),'x',True)
        return {'area_mm2':z['area_mm2'],'moment_x_mm3':z['moment_y_mm3'],
                'moment_y_mm3':z['moment_x_mm3'],'quad_error_area_mm2':z['quad_error_area_mm2']}
    lo,hi=max(x0,cx-rad),min(x1,cx+rad)
    if lo>=hi or y1<=cy-rad or y0>=cy+rad:
        return {'area_mm2':0.,'moment_x_mm3':0.,'moment_y_mm3':0.,'quad_error_area_mm2':0.}
    # This exact covered-rectangle result is also checked by independent strips.
    if not _force_quad and max(hypot(x-cx,y-cy) for x in (x0,x1) for y in (y0,y1))<=rad:
        ar=(x1-x0)*(y1-y0)
        return {'area_mm2':ar,'moment_x_mm3':ar*(x0+x1)/2,'moment_y_mm3':ar*(y0+y1)/2,'quad_error_area_mm2':0.}
    cuts=[lo,hi]
    if lo<cx<hi:cuts.append(cx)
    for ye in (y0,y1):
        dy=ye-cy
        if abs(dy)<rad:
            dx=sqrt(max(0.,rad*rad-dy*dy))
            for xx in (cx-dx,cx+dx):
                if lo<xx<hi:cuts.append(xx)
    cuts=sorted(set(cuts))
    def ends(x):
        span=sqrt(max(0.,rad*rad-(x-cx)**2))
        yl,yu=max(y0,cy-span),min(y1,cy+span)
        return yl,max(yl,yu)
    def fun(x,j):
        yl,yu=ends(x)
        if j==0:return yu-yl
        if j==1:return x*(yu-yl)
        return .5*(yu*yu-yl*yl)
    vals=[];err=0.
    for j in range(3):
        val=0.
        for a,b in zip(cuts[:-1],cuts[1:]):
            q,e=quad(lambda x:fun(x,j),a,b,epsabs=1e-9,epsrel=2e-11,limit=200)
            val+=q
            if j==0:err+=e
        vals.append(val)
    return {'area_mm2':vals[0],'moment_x_mm3':vals[1],'moment_y_mm3':vals[2],'quad_error_area_mm2':err}


def circle_rectangle(bounds, radius_mm, offset_mm=(0.,0.)):
    z=_circle_integrals(bounds,radius_mm,offset_mm,'x');area=pi*float(radius_mm)**2
    return {**z,'fraction':z['area_mm2']/area,'moment_x_mm':z['moment_x_mm3']/area,
            'moment_y_mm':z['moment_y_mm3']/area}


def _bounds(cell):return (cell['x0_mm'],cell['x1_mm'],cell['y0_mm'],cell['y1_mm'])


@lru_cache(maxsize=32)
def _capture(R,C,beam,uniform,side_mm,gap_mm):
    g=cells_geometry(R,C,side_mm,gap_mm);Lx,Ly=g['Lx_mm'],g['Ly_mm']
    if beam=='Gaussian':
        radius=.60*sqrt(Lx*Ly);offset=(.10*Lx,.07*Ly)
        fn=lambda b:gaussian_rectangle(b,radius,offset)
        kind='Gaussian 1/e^2 intensity radius w'
    elif beam=='TopHat':
        radius=1.02*.5*hypot(Lx,Ly) if uniform else .60*sqrt(Lx*Ly)
        offset=(0.,0.) if uniform else (.10*Lx,.07*Ly)
        fn=lambda b:circle_rectangle(b,radius,offset)
        kind='TopHat hard-edge circle radius'
    else:raise ValueError('beam must be Gaussian or TopHat')
    cells=[fn(_bounds(c)) for c in g['cells']];frame=fn(g['outer_bounds_mm'])
    fr=np.array([c['fraction'] for c in cells]);active=float(fr.sum());framefrac=frame['fraction']
    if not 0<active<=framefrac+1e-12 or framefrac>1+1e-12:
        raise AssertionError('Invalid optical capture fractions')
    gap=max(0.,float(framefrac-active));outside=max(0.,1-float(framefrac))
    return {'geometry':g,'physical_fractions':fr.tolist(),'active_fraction':active,'frame_fraction':float(framefrac),
            'gap_fraction':gap,'outside_fraction':outside,'radius_mm':radius,'radius_definition':kind,
            'offset_mm':list(offset),'captured_physical_centroid_mm':[
                sum(c['moment_x_mm'] for c in cells)/active,sum(c['moment_y_mm'] for c in cells)/active]}


def beam_cell_powers(R,C,beam='Gaussian',uniform=False,policy='received_fixed',meanPin_W=8.,Ps_W=None,
                     eta_chain=.9,side_mm=10.,gap_mm=.3):
    """Power map with explicit fixed-received or fixed-source normalization.

    Gaussian uniform=True means ideal equalization *after actual Gaussian
    capture*. It has the identical capture/source/loss budget of its Gaussian
    nonuniform pair. Uniform TopHat is a physically wider centered circle.
    """
    cap=copy.deepcopy(_capture(int(R),int(C),str(beam),bool(uniform),float(side_mm),float(gap_mm)))
    g=cap['geometry'];N=g['N'];eta_chain=float(eta_chain)
    if not 0<eta_chain<=1:raise ValueError('eta_chain in (0,1] required.')
    if policy=='received_fixed':
        total=float(meanPin_W)*N
        if total<0:raise ValueError('Nonnegative mean received power required.')
        Ps=total/(eta_chain*cap['active_fraction'])
    elif policy=='source_fixed':
        if Ps_W is None or float(Ps_W)<0:raise ValueError('Nonnegative source Ps_W required.')
        Ps=float(Ps_W)
    else:raise ValueError('policy must be received_fixed or source_fixed')
    Pbeam=eta_chain*Ps
    physical=np.array(cap['physical_fractions'])*Pbeam
    powers=np.full(N,physical.sum()/N) if beam=='Gaussian' and uniform else physical.copy()
    totalPin=float(powers.sum());mean=float(powers.mean());std=float(powers.std(ddof=0))
    chain=(1-eta_chain)*Ps;gap=Pbeam*cap['gap_fraction'];outside=Pbeam*cap['outside_fraction']
    center=np.array([[c['xc_mm'],c['yc_mm']] for c in g['cells']])
    centroid=(powers@center/totalPin).tolist() if totalPin>0 else [None,None]
    uniform_status='uniform_reference' if beam=='Gaussian' and uniform else ('uniform' if uniform else 'nonuniform')
    profile=f'{beam}_{uniform_status}'
    comment=('Gaussian ideal equalized reference AFTER the same actual Gaussian active-area capture; '
             'not a uniform Gaussian beam, measured homogenizer, or zero-loss realizable optical device.'
             if beam=='Gaussian' and uniform else
             'Centered wider TopHat circle covers the entire outer frame; every equal-area cell has equal input.'
             if uniform else 'Actual area-integrated beam distribution with prescribed offset and radius.')
    out={'R':g['R'],'C':g['C'],'N':N,'beam':beam,'profile':profile,'uniform':bool(uniform),
         'uniform_status':uniform_status,'policy':policy,'comparison_policy':policy,'eta_chain':eta_chain,
         'meanPin_W':mean,'meanPin':mean,'totalPin_W':totalPin,'Pin_matrix_W':powers.reshape(g['R'],g['C']).tolist(),
         'powers':powers.tolist(),'Ps_W':Ps,'Ps':Ps,'Pbeam_W':Pbeam,'Pbeam':Pbeam,
         'active_W':totalPin,'gap_loss_W':gap,'outside_loss_W':outside,'chain_loss_W':chain,
         'power_balance_residual_W':Ps-(chain+gap+outside+totalPin),
         'fractions_of_Pbeam':{'active':cap['active_fraction'],'gap':cap['gap_fraction'],'outside':cap['outside_fraction']},
         'fractions_of_Ps':{'active':eta_chain*cap['active_fraction'],'gap':eta_chain*cap['gap_fraction'],
                            'outside':eta_chain*cap['outside_fraction'],'chain_loss':1-eta_chain},
         'active_fraction':eta_chain*cap['active_fraction'],'gap_loss_fraction':eta_chain*cap['gap_fraction'],
         'outside_loss_fraction':eta_chain*cap['outside_fraction'],'chain_loss_fraction':1-eta_chain,
         'CV_G':std/mean if mean>0 else 0.,'CV_G_percent':100*std/mean if mean>0 else 0.,
         'minPin_W':float(powers.min()),'maxPin_W':float(powers.max()),
         'min_G_W_cm2':float(powers.min())/(g['side_mm']/10)**2,
         'max_G_W_cm2':float(powers.max())/(g['side_mm']/10)**2,
         'centroid_mm':centroid,'centroid_definition':'power-weighted cell-center centroid of supplied cell-average map',
         'physical_captured_centroid_mm':cap['captured_physical_centroid_mm'],
         'geometry':{k:v for k,v in g.items() if k!='cells'},'radius_mm':cap['radius_mm'],
         'radius_definition':cap['radius_definition'],'offset_mm':cap['offset_mm'],
         'physical_Pin_before_Gaussian_equalization_W':physical.reshape(g['R'],g['C']).tolist() if beam=='Gaussian' and uniform else None,
         'intra_cell_policy':'One area-integrated Pin scalar per complete 6-junction cell; no within-cell electrical/thermal nonuniformity.',
         'comment':comment}
    return out


def independent_capture_checks(R,C,beam,uniform,side_mm=10.,gap_mm=.3):
    """Validate production integrals against different quadrature/strip orientation."""
    cap=_capture(int(R),int(C),str(beam),bool(uniform),float(side_mm),float(gap_mm));g=cap['geometry']
    radius=cap['radius_mm'];cx,cy=cap['offset_mm'];boxes=[_bounds(c) for c in g['cells']]+[g['outer_bounds_mm']]
    exact=cap['physical_fractions']+[cap['frame_fraction']];errors=[]
    for b,ref in zip(boxes,exact):
        x0,x1,y0,y1=b
        if beam=='Gaussian':
            fn=lambda y,x:2/(pi*radius**2)*exp(-2*((x-cx)**2+(y-cy)**2)/radius**2)
            q,e=dblquad(fn,x0,x1,lambda _:y0,lambda _:y1,epsabs=1e-11,epsrel=1e-10)
        else:
            # Production uses vertical strips; check uses independently split horizontal strips.
            z=_circle_integrals(b,radius,(cx,cy),'y');q=z['area_mm2']/(pi*radius**2)
        errors.append(abs(q-ref))
    return {'R':R,'C':C,'beam':beam,'uniform':uniform,'boxes_checked':len(boxes),
            'check_method':'2D adaptive numerical Gaussian integration vs exact erf product' if beam=='Gaussian' else
                           'horizontal-strip circle/rectangle quadrature vs production vertical-strip integration',
            'max_absolute_fraction_error':max(errors),'sum_cell_fraction_error_bound':sum(errors[:-1]),
            'passed':max(errors)<2e-10}
