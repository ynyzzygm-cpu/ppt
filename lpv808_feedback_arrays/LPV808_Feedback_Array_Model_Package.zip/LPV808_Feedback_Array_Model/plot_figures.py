"""Publication figures for the conditional cell/array feedback study.

Uses the supplied, real Times New Roman and SimSun font files. Heatmaps are
vector rectangles for complete cells; no within-cell smoothing is introduced.
Only this script and figures/ are owned by the figure task.
"""
from pathlib import Path
import json
import math
import os
os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parent/".mpl_cache"))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt, font_manager, colors, ticker
from matplotlib.patches import Rectangle

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'figures';OUT.mkdir(parents=True,exist_ok=True)
FONTS=Path(os.environ.get('LPV_FONT_DIR','/workspace/work/lpv_response_figures/fonts'))
if FONTS.is_dir():
    for name in ['Times.TTF','Timesbd.TTF','Timesi.TTF','Timesbi.TTF','SimSun-Regular.ttf']:
        if (FONTS/name).is_file():font_manager.fontManager.addfont(str(FONTS/name))
FONT_PATHS={}
for family in ['Times New Roman','SimSun']:
    try:
        FONT_PATHS[family]=font_manager.findfont(font_manager.FontProperties(family=family),fallback_to_default=False)
    except ValueError as exc:
        raise RuntimeError('Figure export requires Times New Roman and SimSun. Install those fonts, or set LPV_FONT_DIR to a licensed font folder containing Times.TTF and SimSun-Regular.ttf. Numerical replay does not require this plotting script.') from exc
matplotlib.rcParams.update({
    'font.family':['Times New Roman','SimSun'],
    'font.serif':['Times New Roman','SimSun'],
    'font.size':11, 'axes.titlesize':11.5,'axes.labelsize':11,
    'xtick.labelsize':10.5,'ytick.labelsize':10.5,'legend.fontsize':10,
    'pdf.fonttype':42,'ps.fonttype':42,
    'axes.unicode_minus':True,'figure.dpi':120,'savefig.dpi':320,
    'axes.spines.top':False,'axes.spines.right':False,
    'axes.linewidth':.7,'xtick.direction':'out','ytick.direction':'out',
    'grid.linewidth':.45,'grid.alpha':.30,
    'mathtext.fontset':'custom','mathtext.rm':'Times New Roman',
    'mathtext.it':'Times New Roman:italic','mathtext.bf':'Times New Roman:bold',
    'mathtext.cal':'Times New Roman','mathtext.sf':'Times New Roman','mathtext.tt':'Times New Roman',
})
MANIFEST=[]
CASE_NAMES={
    'Gaussian_uniform_reference':'理想均匀参照',
    'Gaussian_nonuniform':'高斯非均匀接收',
    'TopHat_uniform':'平顶均匀接收',
    'TopHat_nonuniform':'平顶非均匀接收',
}
COLORS={'uniform':'#222222','Gaussian_nonuniform':'#1B66A4','TopHat_nonuniform':'#C84B38'}
LAYOUTS=[(3,3),(4,4),(4,5),(5,5)]


def save(fig,key,caption,conditions,extra=None):
    png=OUT/(key+'.png');pdf=OUT/(key+'.pdf')
    fig.savefig(png,dpi=320,bbox_inches='tight',pad_inches=.045,facecolor='white')
    fig.savefig(pdf,bbox_inches='tight',pad_inches=.045,facecolor='white')
    item={'key':key,'caption':caption,'conditions':conditions,'png':str(png),'pdf':str(pdf),
          'dpi':320,'fonts':{'latin':'Times New Roman','eastAsia':'SimSun / 宋体'},
          'figure_size_inches':list(fig.get_size_inches())}
    if extra:item.update(extra)
    MANIFEST.append(item);plt.close(fig)
    (OUT/'figures.json').write_text(json.dumps(MANIFEST,ensure_ascii=False,indent=2),encoding='utf-8')


def condition_note(ax,text):
    ax.text(.02,.02,text,transform=ax.transAxes,va='bottom',ha='left',fontsize=9.5,
            bbox={'facecolor':'white','edgecolor':'none','alpha':.82,'pad':2})


def panel_label(ax,label):
    ax.text(.01,1.03,label,transform=ax.transAxes,ha='left',va='bottom',fontsize=11)


def regular_axes(ax,xlabel,ylabel):
    ax.set_xlabel(xlabel);ax.set_ylabel(ylabel);ax.grid(True)
    ax.tick_params(length=3,width=.6)


def block_map(ax,data,norm,cmap,fmt):
    a=np.asarray(data,float);rows,cols=a.shape
    for r in range(rows):
        for c in range(cols):
            value=float(a[r,c]);rgba=cmap(norm(value))
            ax.add_patch(Rectangle((c,r),1,1,facecolor=rgba,edgecolor='white',linewidth=.65))
            lum=.2126*rgba[0]+.7152*rgba[1]+.0722*rgba[2]
            ax.text(c+.5,r+.5,fmt.format(value),ha='center',va='center',fontsize=9.6,
                    color='white' if lum<.48 else '#111111')
    ax.set_xlim(0,cols);ax.set_ylim(rows,0);ax.set_aspect('equal')
    ax.set_xticks(np.arange(cols)+.5,labels=np.arange(1,cols+1))
    ax.set_yticks(np.arange(rows)+.5,labels=np.arange(1,rows+1))
    ax.tick_params(length=0,pad=2,labelsize=9.5)
    for sp in ax.spines.values():sp.set_visible(False)


def heatmap_pair(layout,beam,uniform,nonuniform,norms):
    """Each record has arrays Pin_W, Pcell_W and Tj_C in row-major order."""
    rows,cols=layout
    fig,axs=plt.subplots(2,3,figsize=(6.7,4.6))
    fig.subplots_adjust(left=.10,right=.985,bottom=.16,top=.85,wspace=.20,hspace=.30)
    metrics=[('Pin_W','平均辐照度 (W/cm²)','YlOrBr','{:.1f}'),
             ('Pcell_W','单体电功率 (W)','YlGnBu','{:.2f}'),
             ('Tj_C','单体结温 (°C)','YlOrRd','{:.1f}')]
    for rid,record in enumerate([uniform,nonuniform]):
        for cid,(key,title,cmapname,fmt) in enumerate(metrics):
            a=np.asarray(record[key],float).reshape(rows,cols)
            block_map(axs[rid,cid],a,norms[key],plt.get_cmap(cmapname),fmt)
            if rid==0:axs[rid,cid].set_title(title,pad=6)
            if cid==0:
                label='理想均匀\n参照' if rid==0 and beam=='Gaussian' else ('均匀\n接收' if rid==0 else '非均匀\n接收')
                axs[rid,cid].set_ylabel(label,fontsize=10.5,labelpad=10)
    for cid,(key,title,cmapname,fmt) in enumerate(metrics):
        # One colorbar per metric shared by the two comparison rows.
        box=axs[1,cid].get_position()
        cbax=fig.add_axes([box.x0,.085,box.width,.022])
        cb=fig.colorbar(plt.cm.ScalarMappable(norm=norms[key],cmap=cmapname),cax=cbax,orientation='horizontal')
        cb.ax.tick_params(labelsize=9.2,length=2,pad=2)
        cb.locator=ticker.MaxNLocator(nbins=4);cb.update_ticks()
    beamzh='高斯光束' if beam=='Gaussian' else '圆形平顶光束'
    fig.suptitle(f'{rows}×{cols} 阵列｜{beamzh}｜{rows}S{cols}P',fontsize=12.3,y=.97)
    fig.text(.54,.015,'列号（横轴）与行号（纵轴）；每块代表一片完整六结电池',ha='center',fontsize=9.5)
    key=f'heatmap_R{rows}C{cols}_{beam}'
    cap=f'{rows}×{cols} 阵列在{beamzh}下的完整单体分布：上行为'+('理想均匀参照' if beam=='Gaussian' else '均匀接收')+'，下行为非均匀接收；三列依次为平均辐照度、实际拓扑工作点的单体电功率及结温。'
    conditions={'mean_Pin_per_cell_W':8,'sink_C':25,'topology':f'{rows}S{cols}P','same_active_received_total_W':rows*cols*8,
                'optimum_scope':'forward-generation-supported network maximum; see result support flag','intracell_uniform':True,'no_spatial_smoothing':True}
    save(fig,key,cap,conditions,{'norms':{k:[float(n.vmin),float(n.vmax)] for k,n in norms.items()},
                              'uniform_support_flag':uniform.get('optimum_label'), 'nonuniform_support_flag':nonuniform.get('optimum_label')})


def common_heatmap_norms(records):
    result={}
    for k in ['Pin_W','Pcell_W','Tj_C']:
        vals=np.concatenate([np.asarray(r[k],float).ravel() for r in records])
        lo,hi=float(vals.min()),float(vals.max())
        if not np.isfinite(vals).all():raise ValueError('Nonfinite map values')
        if k in ['Pin_W','Pcell_W']:lo=0.
        if hi<=lo:hi=lo+1
        result[k]=colors.Normalize(lo,hi,clip=False)
    return result



def read_array_results():
    raw=json.loads((ROOT/'arrays/results.json').read_text())
    records=raw['results'] if isinstance(raw,dict) else raw
    primary=[r for r in records if r['connection']=='primary']
    main=[r for r in primary if r['is_main_case']]
    if len(main)!=16:raise ValueError(f'Expected 16 primary main cases, got {len(main)}')
    return primary,main


def map_record(record):
    ss=sorted(record['cells'],key=lambda x:x['cell'])
    return {k:[s[k] for s in ss] for k in ['Pin_W','Pcell_W','Tj_C']}|{
        'optimum_label':record.get('maximum_label',record.get('optimum_label',record.get('boundary_flag',record.get('is_interior_mpp'))))}


def main_heatmaps(main):
    transformed=[map_record(r) for r in main]
    norms=common_heatmap_norms(transformed)
    for layout in LAYOUTS:
        rr,cc=layout
        for beam in ['Gaussian','TopHat']:
            profiles=[beam+'_uniform_reference' if beam=='Gaussian' else beam+'_uniform',beam+'_nonuniform']
            selected=[]
            for profile in profiles:
                matches=[r for r in main if r['R']==rr and r['C']==cc and r['profile']==profile]
                if len(matches)!=1:raise ValueError(f'Ambiguous map {layout} {profile}')
                selected.append(map_record(matches[0]))
            heatmap_pair(layout,beam,*selected,norms)


def pv_comparison(main):
    curves=pd.read_csv(ROOT/'arrays/main_curves.csv')
    fig,axs=plt.subplots(2,2,figsize=(6.7,5.4))
    fig.subplots_adjust(left=.10,right=.985,bottom=.15,top=.90,wspace=.28,hspace=.58)
    handles=[];labels=[];overlap=[]
    for ax,(R,C) in zip(axs.flat,LAYOUTS):
        subset=[r for r in main if r['R']==R and r['C']==C]
        for profile in ['Gaussian_uniform_reference','Gaussian_nonuniform','TopHat_nonuniform']:
            rec=next(r for r in subset if r['profile']==profile)
            cr=curves[curves['case_id']==rec['case_id']].sort_values('Vport_V')
            if cr.empty:raise ValueError(f'No PV curve {rec["case_id"]}')
            color=COLORS.get(profile,COLORS['uniform']);label=CASE_NAMES[profile]
            if profile=='Gaussian_uniform_reference':label='均匀对照'
            elif profile=='Gaussian_nonuniform':label='高斯非均匀'
            else:label='平顶非均匀'
            line,=ax.plot(cr.Vport_V,cr.Pport_W,color=color,lw=1.6,label=label)
            ax.scatter([rec['Vmpp_V']],[rec['Pmax_W']],s=21,color=color,zorder=4)
            if R==3:handles.append(line);labels.append(label)
        ur=next(r for r in subset if r['profile']=='Gaussian_uniform_reference')
        ut=next(r for r in subset if r['profile']=='TopHat_uniform')
        overlap.append({'R':R,'C':C,'uniform_Pmax_difference_W':abs(ur['Pmax_W']-ut['Pmax_W'])})
        ax.set_title(f'{R}×{C}；{R}S{C}P',pad=5)
        regular_axes(ax,'阵列端口电压 (V)','阵列输出功率 (W)')
        if (R,C) in [(3,3),(4,4)]:ax.set_xlabel('')
    fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.5,.005),ncol=3,frameon=False,fontsize=9.9)
    fig.suptitle('相同有源面接收功率：阵列 P–V 特性',fontsize=12.5,y=.985)
    save(fig,'array_pv','四种几何布局的阵列稳态 P–V 曲线。每一电压点均求实际拓扑下的各片热平衡；圆点标示正向发电支持域内最大功率。两类均匀参照在相同片均接收功率下重合。',
         {'mean_Pin_W':8,'sink_C':25,'connection':'primary','curves':'load-specific thermally closed at each port voltage','scope':'forward-generation-supported curves'}, {'uniform_overlap_checks':overlap})


def sweep_figure(primary,policy):
    fig,axs=plt.subplots(2,2,figsize=(6.7,5.3))
    fig.subplots_adjust(left=.10,right=.985,bottom=.18,top=.90,wspace=.28,hspace=.62)
    same_received=policy=='received_fixed'
    fig.subplots_adjust(bottom=.17 if same_received else .24)
    profiles=['Gaussian_uniform_reference','Gaussian_nonuniform','TopHat_nonuniform'] if same_received else ['Gaussian_uniform_reference','Gaussian_nonuniform','TopHat_uniform','TopHat_nonuniform']
    colors_by={'Gaussian_uniform_reference':'#252525','Gaussian_nonuniform':'#1B66A4','TopHat_uniform':'#3A8E58','TopHat_nonuniform':'#C84B38'}
    markers={'Gaussian_uniform_reference':'o','Gaussian_nonuniform':'s','TopHat_uniform':'^','TopHat_nonuniform':'D'}
    xkey='meanPin_W' if same_received else 'Ps_W'
    legend_h=[];legend_l=[]
    for ax,(R,C) in zip(axs.flat,LAYOUTS):
        for profile in profiles:
            rows=sorted([r for r in primary if r['R']==R and r['C']==C and r['profile']==profile and r['comparison_policy']==policy],key=lambda r:r[xkey])
            if len(rows)!=4:raise ValueError(f'Expected 4 sweep nodes {R,C,profile,policy}: got {len(rows)}')
            label=CASE_NAMES[profile]
            if same_received:
                label={'Gaussian_uniform_reference':'均匀对照','Gaussian_nonuniform':'高斯非均匀','TopHat_nonuniform':'平顶非均匀'}[profile]
            line,=ax.plot([r[xkey] for r in rows],[r['Pmax_W'] for r in rows],color=colors_by[profile],marker=markers[profile],ms=4,lw=1.5,label=label)
            if R==3:legend_h.append(line);legend_l.append(label)
            boundary=[r for r in rows if not r.get('is_interior_supported_MPP',True)]
            if boundary:
                ax.scatter([r[xkey] for r in boundary],[r['Pmax_W'] for r in boundary],
                           marker='^',s=62,facecolors='white',edgecolors=colors_by[profile],linewidths=1.25,zorder=8)

        ax.set_title(f'{R}×{C}；{R}S{C}P',pad=5)
        regular_axes(ax,'平均单片接收功率 (W)' if same_received else '激光源输出光功率 (W)','阵列输出功率 (W)')
        if (R,C) in [(3,3),(4,4)]:ax.set_xlabel('')
        ax.set_xticks([2,4,6,8] if same_received else [40,80,120,160])
    if not same_received:
        from matplotlib.lines import Line2D
        legend_h.append(Line2D([],[],marker='^',ms=6,markerfacecolor='white',markeredgecolor='#333333',linestyle='None'))
        legend_l.append('空心三角：支持域边界最大值')
    fig.legend(legend_h,legend_l,loc='lower center',bbox_to_anchor=(.5,.002),ncol=3 if same_received else 2,frameon=False,fontsize=9.4,columnspacing=1.15)

    title='相同有源面平均接收功率的比较' if same_received else '相同激光源功率的比较（含截获损失）'
    fig.suptitle(title,fontsize=12.5,y=.985)
    save(fig,'received_sweep' if same_received else 'source_sweep',
         ('片均接收功率 2、4、6、8 W 下的阵列支持域最大输出功率；两类均匀对照电学结果重合。' if same_received else '激光源功率 40、80、120、160 W 下的阵列支持域最大输出功率；此口径包含上游传输、阵列外和间隙截获差异，四种情景分别展示。空心三角标示支持域边界最大值，不能解读为已建反偏全网络的真实 MPP。'),
         {'comparison_policy':policy,'connection':'primary','sink_C':25,'Rbus_ohm':0,'intracell_uniform':True})


def single_iteration_figure():
    df=pd.read_csv(ROOT/'single/fixedpoint_iterations.csv')
    fig,axs=plt.subplots(3,1,figsize=(6.7,5.9),sharex=True)
    fig.subplots_adjust(left=.12,right=.985,bottom=.10,top=.91,hspace=.16)
    for pin,color in [(12,'#1B66A4'),(16,'#C84B38')]:
        d=df[np.isclose(df.Pin_W,pin)].sort_values('iteration')
        if d.empty:raise ValueError('Missing iteration history')
        axs[0].plot(d.iteration,d.Tj_C,'o-',color=color,ms=3.4,lw=1.3,label=f'{pin} W')
        axs[1].plot(d.iteration,d.Pe_W,'o-',color=color,ms=3.4,lw=1.3)
        axs[2].semilogy(d.iteration,np.maximum(np.abs(d.thermal_residual_K),1e-13),'o-',color=color,ms=3.4,lw=1.3)
    for ax,label in zip(axs,['当前迭代温度 (°C)','当前迭代功率 (W)','热平衡残差绝对值 (K)']):
        ax.set_ylabel(label);ax.grid(True)
    axs[0].legend(frameon=False,ncol=2,loc='best')
    axs[2].set_xlabel('固定点迭代次数')
    axs[2].xaxis.set_major_locator(ticker.MaxNLocator(integer=True,nbins=8))
    fig.suptitle('单体光—电—热闭环的逐次更新',fontsize=12.5,y=.975)
    save(fig,'single_iterations','12 W 与 16 W 单片入射功率下的固定点迭代历史。每步根据当前温度重新生成五参数、求最大功率，再更新热平衡温度；迭代次数不是物理时间。',
         {'Pin_W':[12,16],'sink_C':25,'electrical_load':'ideal instantaneous single-cell MPPT','x_axis':'numerical iteration, not time'})


def feedback_stage_figure():
    df=pd.read_csv(ROOT/'single/freeze_onepass_converged.csv')
    stages=[('freeze_T25','冻结温度 25°C','#525252','o'),('one_pass','仅更新一次','#CE812D','s'),('closed_loop_Brent','闭环收敛','#1B66A4','D')]
    fig,axs=plt.subplots(1,2,figsize=(6.7,3.3))
    fig.subplots_adjust(left=.09,right=.985,bottom=.19,top=.80,wspace=.30)
    hs=[];ls=[]
    for stage,label,col,marker in stages:
        d=df[df.model_stage==stage].sort_values('Pin_W')
        if d.empty:raise ValueError('Missing feedback comparison stage '+stage)
        h,=axs[0].plot(d.Pin_W,d.Pout_W,color=col,marker=marker,ms=4,lw=1.4)
        axs[1].plot(d.Pin_W,d.Tj_C,color=col,marker=marker,ms=4,lw=1.4)
        hs.append(h);ls.append(label)
    regular_axes(axs[0],'单片入射功率 (W)','输出功率 (W)')
    regular_axes(axs[1],'单片入射功率 (W)','模型采用的温度 (°C)')
    for ax in axs:ax.set_xticks([4,8,12,16])
    fig.legend(hs,ls,loc='upper center',bbox_to_anchor=(.5,.94),ncol=3,frameon=False,fontsize=9.8)
    fig.suptitle('冻结、一次更新与闭环收敛的差别',fontsize=12.5,y=1.015)
    save(fig,'single_comparison','冻结 25°C、单次温度更新与完整光热电闭环的输出功率及温度比较。冻结和一次更新情景一般仍有非零热平衡残差，其偏差不是独立实验测得的误差。',
         {'Pin_W':[4,8,12,16],'sink_C':25,'electrical_load':'single-cell ideal MPPT','baseline':'uploaded integrated report joint-calibrated parameters'})


def thermal_ode_figure():
    df=pd.read_csv(ROOT/'single/thermal_ODE_steps.csv')
    fig,axs=plt.subplots(2,2,figsize=(6.7,4.8),sharex='col')
    fig.subplots_adjust(left=.10,right=.985,bottom=.13,top=.88,wspace=.27,hspace=.18)
    for c,(case,title) in enumerate([('4to12W','4→12 W 光功率阶跃'),('8to16W','8→16 W 光功率阶跃')]):
        rows=df[df['case']==case]
        for seg in ['pre','post']:
            d=rows[rows.segment==seg].sort_values('t_s')
            if d.empty:raise ValueError(f'Missing ODE segment {case}:{seg}')
            axs[0,c].plot(d.t_s,d.Tj_C,color='#B34432',lw=1.6)
            axs[1,c].plot(d.t_s,d.Pout_W,color='#1B66A4',lw=1.6)
        for ax in axs[:,c]:
            ax.axvline(.5,color='#8B8B8B',ls='--',lw=.8);ax.grid(True)
        axs[0,c].set_title(title,pad=5)
        axs[1,c].set_xlabel('时间 (s)')
    axs[0,0].set_ylabel('单体结温 (°C)');axs[1,0].set_ylabel('输出电功率 (W)')
    fig.suptitle('热容引入后的准静态光热电时间响应',fontsize=12.5,y=.98)
    save(fig,'thermal_ode','两种入射光功率阶跃的准静态热响应；阶跃时刻为 0.5 s，结温连续，输出电功率允许瞬时跳变。该秒级曲线由假设热容和理想 MPPT 给出，不能用于推断高频信号带宽。',
         {'Cth_J_K':.3,'sink_C':25,'step_time_s':.5,'load':'ideal instantaneous single-cell MPPT','scope':'thermal ODE, no electrical RC model'})


def main():
    primary,main=read_array_results()
    main_heatmaps(main)
    pv_comparison(main)
    sweep_figure(primary,'received_fixed')
    sweep_figure(primary,'source_fixed')
    single_iteration_figure()
    feedback_stage_figure()
    thermal_ode_figure()
    print(json.dumps({'figure_count':len(MANIFEST),'manifest':str(OUT/'figures.json')},ensure_ascii=False))


if __name__=='__main__':main()
