"""Anchored conditional optical-electrical-thermal model of the 808 nm 6J cell.

Only the five reference terminal parameters are calibrated to the supplied IV.
The junction reference temperature, temperature laws and thermal boundary are
explicit conditional scenarios, not measurements of the target cell.
"""
from pathlib import Path
import json
import math
import numpy as np
from scipy.special import wrightomega
from scipy.optimize import brentq, minimize_scalar

BASE = {
    'Iph_A': 0.7368150204535772,
    'I0_A': 3.0801435297375124e-22,
    'a_V': 0.14422017047980343,
    'Rs_ohm': 0.3555319407340008,
    'Rsh_ohm': 379.1480253451301,
}
BASE_FEATURES = {
    'Isc_A': 0.7361247468865589,
    'Voc_V': 7.095740478956522,
    'Vmpp_V': 6.30051490586258,
    'Impp_A': 0.7031580083775969,
    'Pmpp_W': 4.430257512959694,
}
DEFAULT_CONFIG = {
    'T_ref_C': 40.0,
    'P_ref_W': 8.0,
    'beta_Voc_V_per_K': -0.00815,
    'alpha_Iph_per_K': 0.0,
    'gamma_Rs_per_K': 0.0,
    'eta_h': 0.9,
    'Rth_K_per_W': 15.0/(0.9*8.0-BASE_FEATURES['Pmpp_W']),
    'temperature_domain_C': [0.0,180.0],
    'interpretation': 'Conditional model; reference junction temperature and derived Rth are not independently measured.',
}

def config(overrides=None):
    c=dict(DEFAULT_CONFIG)
    if overrides:c.update(overrides)
    return c

def parameters(P_W,T_C,cfg=None):
    """Return temperature and optical-power adjusted terminal parameters."""
    c=config(cfg);p=float(P_W);t=float(T_C)
    if not math.isfinite(p) or p<=0:raise ValueError('Incident power must be positive.')
    if not math.isfinite(t) or not c['temperature_domain_C'][0]<=t<=c['temperature_domain_C'][1]:
        raise ValueError('Junction temperature outside declared scenario domain.')
    dt=t-c['T_ref_C'];tr=c['T_ref_C']+273.15
    scale=1+c['alpha_Iph_per_K']*dt
    rs=BASE['Rs_ohm']*(1+c['gamma_Rs_per_K']*dt)
    a=BASE['a_V']*(t+273.15)/tr
    sh=BASE['Rsh_ohm']
    voc8=BASE_FEATURES['Voc_V']+c['beta_Voc_V_per_K']*dt
    iph8=BASE['Iph_A']*scale
    numerator=iph8-voc8/sh
    if scale<=0 or rs<=0 or a<=0 or voc8<=0 or numerator<=0:
        raise ValueError('Scenario parameters violate positive-current constraints.')
    i0=numerator/np.expm1(voc8/a)
    if abs(dt)<1e-12:i0=BASE['I0_A']
    return {'Iph_A':float(iph8*p/c['P_ref_W']),'I0_A':float(i0),'a_V':float(a),
            'Rs_ohm':float(rs),'Rsh_ohm':float(sh)}

def current_from_parameters(V,p):
    """Stable explicit Lambert-W solution, output-positive current."""
    v=np.asarray(V,dtype=float)
    iph,i0,a,rs,sh=[p[k] for k in ['Iph_A','I0_A','a_V','Rs_ohm','Rsh_ohm']]
    g=1/sh;d=1+rs*g
    logarg=np.log(rs)+np.log(i0)-np.log(a*d)+(rs*(iph+i0)+v)/(a*d)
    out=(iph+i0-v*g)/d-a/rs*wrightomega(logarg)
    return float(out) if out.ndim==0 else out

def current(V,P_W,T_C,cfg=None):
    return current_from_parameters(V,parameters(P_W,T_C,cfg))

def current_internal_u(U,p):
    return p['Iph_A']-p['I0_A']*np.expm1(np.asarray(U)/p['a_V'])-np.asarray(U)/p['Rsh_ohm']

def features(P_W,T_C,cfg=None):
    p=parameters(P_W,T_C,cfg)
    fn=lambda v:current_from_parameters(v,p)
    voc=brentq(fn,0,20,xtol=1e-12)
    opt=minimize_scalar(lambda v:-v*fn(v),bounds=(0,voc),method='bounded',options={'xatol':1e-11})
    vm=float(opt.x);im=float(fn(vm));pm=vm*im;isc=float(fn(0))
    u=vm+im*p['Rs_ohm'];b=p['I0_A']/p['a_V']*np.exp(u/p['a_V'])+1/p['Rsh_ohm']
    slope=-b/(1+p['Rs_ohm']*b)
    return {'Isc_A':isc,'Voc_V':float(voc),'Vmpp_V':vm,'Impp_A':im,'Pmpp_W':pm,
            'FF':pm/(isc*voc),'efficiency_percent':100*pm/P_W,'Rmpp_ohm':vm/im,
            'dI_dV_mpp_A_per_V':float(slope)}

def loadpoint(R_ohm,P_W,T_C,cfg=None):
    if not math.isfinite(R_ohm) or R_ohm<0:raise ValueError('Finite nonnegative resistance required.')
    p=parameters(P_W,T_C,cfg)
    if R_ohm==0:return {'V_V':0.0,'I_A':current_from_parameters(0,p),'Pout_W':0.0}
    voc=brentq(lambda v:current_from_parameters(v,p),0,20,xtol=1e-12)
    v=brentq(lambda v:v-R_ohm*current_from_parameters(v,p),0,voc,xtol=1e-12)
    i=current_from_parameters(v,p)
    return {'V_V':float(v),'I_A':float(i),'Pout_W':float(v*i)}

def voltage_at_current(I_A,P_W,T_C,cfg=None):
    """Generation-quadrant inverse only; reverse bias is not modeled."""
    p=parameters(P_W,T_C,cfg);ii=float(I_A)
    isc=current_from_parameters(0,p)
    if ii < -1e-10 or ii > isc+1e-10:
        raise ValueError('Current outside forward-generation support; reverse bias not supplied.')
    ii=max(0.,min(ii,isc))
    uoc=brentq(lambda u:current_internal_u(u,p),0,20,xtol=1e-12)
    u=brentq(lambda u:current_internal_u(u,p)-ii,0,uoc,xtol=1e-12)
    return float(u-ii*p['Rs_ohm'])

def _electrical_state(mode,P_W,T_C,cfg,Rload_ohm,V_V):
    if mode=='mpp':
        f=features(P_W,T_C,cfg)
        # Open/short endpoints of a fully coupled steady curve have different
        # temperatures. Do not label isothermal endpoints as coupled features.
        same_t={k:val for k,val in f.items() if k not in ['Isc_A','Voc_V','FF']}
        return {'V_V':f['Vmpp_V'],'I_A':f['Impp_A'],'Pout_W':f['Pmpp_W'],**same_t,
                'isothermal_Isc_at_Tj_A':f['Isc_A'],'isothermal_Voc_at_Tj_V':f['Voc_V'],
                'isothermal_FF_at_Tj':f['FF']}
    if mode=='resistor':return loadpoint(Rload_ohm,P_W,T_C,cfg)
    if mode=='open':return {'V_V':features(P_W,T_C,cfg)['Voc_V'],'I_A':0.,'Pout_W':0.}
    if mode=='short':return {'V_V':0.,'I_A':current(0,P_W,T_C,cfg),'Pout_W':0.}
    if mode=='voltage':
        ii=current(V_V,P_W,T_C,cfg)
        return {'V_V':float(V_V),'I_A':float(ii),'Pout_W':float(V_V*ii)}
    raise ValueError('Unknown thermal load mode.')

def thermal_state(P_W,T_sink_C,mode='mpp',cfg=None,Rload_ohm=8.960311666505538,V_V=None):
    """Solve temperature for the actual specified electrical operating condition.

    Qheat = eta_h*Pincident - Pout. eta_h is net retained optical-energy
    fraction after reflected/transmitted/emitted optical escape, assumed fixed.
    Linear stability is checked at fixed specified load (or ideal MPPT).
    """
    c=config(cfg);r=c['Rth_K_per_W'];ts=float(T_sink_C)
    lo,hi=c['temperature_domain_C']
    if not lo<=ts<=hi or r<0 or not 0<c['eta_h']<=1:raise ValueError('Invalid thermal scenario.')
    def state(t):return _electrical_state(mode,P_W,t,c,Rload_ohm,V_V)
    def residual(t):return t-ts-r*(c['eta_h']*P_W-state(t)['Pout_W'])
    if r==0:t=ts
    else:
        # Root must be bracketed in the stated absolute temperature interval.
        a=max(lo,ts);fa=residual(a);fb=residual(hi)
        if fa>1e-9 or fb<0:raise ValueError('No thermal root inside 0–180 C; do not clip.')
        t=brentq(residual,a,hi,xtol=1e-10)
    s=state(t);q=c['eta_h']*P_W-s['Pout_W']
    if q < -1e-8:raise ValueError('Electrical output exceeds retained optical-energy assumption.')
    eps=1e-3;ta=max(lo,t-eps);tb=min(hi,t+eps)
    dPdT=(state(tb)['Pout_W']-state(ta)['Pout_W'])/(tb-ta)
    stability=1+r*dPdT
    if stability<=0:raise ValueError('Thermally unstable root for the specified load.')
    return {'Pin_W':float(P_W),'T_sink_C':ts,'Tj_C':float(t),'mode':mode,'Rth_K_per_W':r,
            'eta_h':c['eta_h'],**s,'Qheat_W':float(q),'thermal_balance_residual_K':float(t-ts-r*q),
            'electrical_efficiency_percent':100*s['Pout_W']/P_W,
            'thermal_stability_margin':float(stability)}

def anchor_family(T_ref_C,eta_h=.9):
    """Reanchor unknown Tj families to the same observed 8W/25C/MPPT datum."""
    rise=float(T_ref_C)-25.
    if rise<0:raise ValueError('Passive baseline thermal family requires Tref >= 25 C.')
    return config({'T_ref_C':float(T_ref_C),'eta_h':eta_h,
                   'Rth_K_per_W':rise/(eta_h*8.-BASE_FEATURES['Pmpp_W'])})

if __name__=='__main__':
    print(json.dumps({'config':DEFAULT_CONFIG,'reference':features(8,40),
                      'thermal_anchor':thermal_state(8,25)},indent=2))
