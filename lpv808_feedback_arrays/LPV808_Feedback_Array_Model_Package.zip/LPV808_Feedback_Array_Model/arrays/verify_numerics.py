"""Mesh/scan refinement and scalar thermal-root checks, independent of tables."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.optimize import brentq
from network import CellBank,ArrayNetwork,groups_for_layout,core

HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
opt=json.loads((ROOT/'optics/cases.json').read_text())
source=json.loads((HERE/'results.json').read_text())
selected=['R3C3_Gaussian_uniform_reference_received_mean_8',
          'R4C5_Gaussian_nonuniform_received_mean_8',
          'R5C5_TopHat_nonuniform_received_mean_8',
          'R5C5_Gaussian_nonuniform_source_Ps_40']
rows=[];scalar=[]
for caseid in selected:
    c=next(c for c in opt['cases'] if c['case_id']==caseid)
    original=next(r for r in source['results'] if r['case_id']==caseid and r['connection']=='primary')
    for ngrid,scan in [(201,65),(801,257)]:
        bank=CellBank(c['powers'],n_grid=ngrid)
        net=ArrayNetwork(bank,groups_for_layout(c['R'],c['C']))
        refined=net.optimum(scan_n=scan)
        rows.append({'case_id':caseid,'current_grid_points':ngrid,'power_scan_points':scan,
                     'refined_Pmax_W':refined['Pport_W'],'original_Pmax_W':original['Pmax_W'],
                     'relative_difference_percent':100*(refined['Pport_W']/original['Pmax_W']-1),
                     'original_label':original['maximum_label'],'refined_label':refined['maximum_label']})
    cfg=core.config();r=cfg['Rth_K_per_W'];eta=cfg['eta_h']
    for cell in original['cells']:
        pin=cell['Pin_W'];ii=cell['Icell_A'];ts=original['Tsink_C'];hot=ts+r*eta*pin
        def vv(t):return float(core.voltage(ii,pin,t,cfg,generation_only=False))
        def residual(t):return t-ts-r*(eta*pin-ii*vv(t))
        if abs(residual(hot))<1e-10:t=hot
        else:t=brentq(residual,ts,hot,xtol=1e-11)
        scalar.append({'case_id':caseid,'cell':cell['cell'],
                       'scalar_Tj_C':t,'vector_Tj_C':cell['Tj_C'],'temperature_difference_K':t-cell['Tj_C'],
                       'scalar_Vcell_V':vv(t),'vector_Vcell_V':cell['Vcell_V'],
                       'voltage_difference_V':vv(t)-cell['Vcell_V']})
pd.DataFrame(rows).to_csv(HERE/'mesh_refinement.csv',index=False)
pd.DataFrame(scalar).to_csv(HERE/'scalar_thermal_root_checks.csv',index=False)
curve=pd.read_csv(HERE/'main_curves.csv')
check={'mesh_cases':len(selected),'mesh_comparisons':len(rows),
       'max_mesh_Pmax_relative_difference_percent':max(abs(r['relative_difference_percent']) for r in rows),
       'all_refinement_boundary_labels_unchanged':all(r['original_label']==r['refined_label'] for r in rows),
       'scalar_root_cell_count':len(scalar),
       'max_vector_vs_scalar_thermal_root_difference_K':max(abs(r['temperature_difference_K']) for r in scalar),
       'max_vector_vs_scalar_voltage_difference_V':max(abs(r['voltage_difference_V']) for r in scalar),
       'curve_point_count':len(curve),
       'curve_max_residuals':{k:float(curve[k].abs().max()) for k in ['thermal_max_residual_K','KVL_max_residual_V','KCL_residual_A','electrical_power_residual_W','retained_energy_residual_W']},
       'curve_minimum_cell_voltage_V':float(curve.minimum_cell_voltage_V.min()),
       'curve_minimum_branch_current_A':float(curve.minimum_branch_current_A.min())}
(HERE/'numerical_refinement_checks.json').write_text(json.dumps(check,indent=2))
print(json.dumps(check,indent=2))
