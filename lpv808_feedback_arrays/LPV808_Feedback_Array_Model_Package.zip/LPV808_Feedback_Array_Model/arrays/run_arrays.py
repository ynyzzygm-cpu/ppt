"""Run the contracted received-power and source-power array comparisons."""
from pathlib import Path
import json,time,hashlib,platform,sys
import numpy as np
import pandas as pd
from network import CellBank,ArrayNetwork,groups_for_layout,UnsupportedState,core

HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
contract=json.loads((ROOT/'study_contract.json').read_text())
optics_path=ROOT/'optics/cases.json'
optics=json.loads(optics_path.read_text())
cases=optics['cases']
cfg=contract['thermal_config'];ts=contract['temperature_C'];rbus=contract['Rbus_ohm']
results=[];summaries=[];cellrows=[];curves=[];curvecells=[];errors=[]
started=time.perf_counter()


def metadata(c,connection):
    R,C=c['R'],c['C']
    topology=f'{R}S{C}P' if connection=='primary' else f'{C}S{R}P'
    return {'case_id':c['case_id'],'R':R,'C':C,'N':R*C,'profile':c['profile'],
            'uniform':c['uniform'],'comparison_policy':c['comparison_policy'],
            'meanPin_W':c['meanPin_W'],'Ps_W':c['Ps_W'],
            'is_main_case':c['is_main_case'],'connection':connection,'topology':topology,
            'target_meanPin_W':c.get('target_meanPin_W'),'target_Ps_W':c.get('target_Ps_W'),
            'CV_G_percent':c['CV_G_percent'],'eta_chain':c['eta_chain'],
            'Gaussian_reference_is_ideal_equalization':c['profile']=='Gaussian_uniform_reference'}


for k,c in enumerate(cases,1):
    connections=['primary','secondary'] if c['is_main_case'] else ['primary']
    try:bank=CellBank(c['powers'],Tsink_C=ts,cfg=cfg,n_grid=401)
    except Exception as exc:
        for connection in connections:errors.append({**metadata(c,connection),'status':'unsupported','reason':str(exc)})
        print('UNSUPPORTED_BANK',c['case_id'],str(exc),flush=True)
        continue
    for connection in connections:
        meta=metadata(c,connection)
        try:
            net=ArrayNetwork(bank,groups_for_layout(c['R'],c['C'],connection),Rbus_ohm=rbus)
            best=net.optimum()
            source_balance=c['Ps_W']-c['chain_loss_W']-c['gap_loss_W']-c['outside_loss_W']-(1-bank.eta)*sum(c['powers'])-best['total_cell_heat_W']-best['wire_loss_W']-best['Pport_W']
            result={**meta,'status':'ok',**best,
                    'Pmax_W':best['Pport_W'],'Vmpp_V':best['Vport_V'],'Impp_A':best['Iport_A'],
                    'Tmin_C':best['Tj_min_C'],'Tmax_C':best['Tj_max_C'],
                    'efficiency_source_percent':100*best['Pport_W']/c['Ps_W'],
                    'source_energy_residual_W':float(source_balance),
                    'optical_chain_loss_W':c['chain_loss_W'],'optical_gap_loss_W':c['gap_loss_W'],
                    'optical_outside_loss_W':c['outside_loss_W'],
                    'optical_unretained_at_cells_W':float((1-bank.eta)*sum(c['powers'])),
                    'Tsink_C':ts,'Rth_each_K_per_W':bank.rth,'eta_h':bank.eta}
            for j,row in enumerate(result['cells']):
                row.update({'row':j//c['C']+1,'col':j%c['C']+1})
                cellrows.append({**meta,**row})
            results.append(result)
            summaries.append({key:val for key,val in result.items() if not isinstance(val,(dict,list))})
            if c['is_main_case'] and connection=='primary':
                for point,st in enumerate(net.curve(161)):
                    curves.append({**meta,'point':point,**{key:val for key,val in st.items() if not isinstance(val,(dict,list))},
                                   'supported_bus_min_V':net.umin,'supported_bus_max_V':net.umax,
                                   'maximum_label':best['maximum_label']})
                    for cell in st['cells']:curvecells.append({**meta,'point':point,'Vbus_V':st['Vbus_V'],**cell})
        except Exception as exc:
            errors.append({**meta,'status':'unsupported','reason':str(exc)})
            print('UNSUPPORTED_NETWORK',c['case_id'],connection,str(exc),flush=True)
    if k%16==0 or k==len(cases):
        (HERE/'run_progress.json').write_text(json.dumps({'processed_optical_cases':k,'total_optical_cases':len(cases),'successful_networks':len(results),'errors':len(errors),'elapsed_seconds':time.perf_counter()-started},indent=2))
        print(f'progress {k}/{len(cases)} networks={len(results)} errors={len(errors)} elapsed={time.perf_counter()-started:.2f}s',flush=True)

pd.DataFrame(summaries).to_csv(HERE/'summary.csv',index=False)
pd.DataFrame(cellrows).to_csv(HERE/'cell_states.csv',index=False)
pd.DataFrame(curves).to_csv(HERE/'main_curves.csv',index=False)
pd.DataFrame(curvecells).to_csv(HERE/'main_curve_cells.csv',index=False)
pd.DataFrame(errors,columns=['case_id','R','C','profile','comparison_policy','connection','topology','status','reason']).to_csv(HERE/'errors.csv',index=False)
uniform=[]
for result in results:
    if not result['uniform']:continue
    single=core.thermal_mpp(result['meanPin_W'],ts,cfg)
    expected=result['N']*single['Pout_W']
    uniform.append({'case_id':result['case_id'],'connection':result['connection'],'N':result['N'],
                    'array_Pmax_W':result['Pmax_W'],'N_times_single_W':expected,
                    'relative_difference_percent':100*(result['Pmax_W']/expected-1)})
pd.DataFrame(uniform).to_csv(HERE/'uniform_scaling_checks.csv',index=False)
orientation=[]
for c in cases:
    if not c['is_main_case']:continue
    pair=[r for r in results if r['case_id']==c['case_id']]
    if len(pair)!=2:continue
    p=next(r for r in pair if r['connection']=='primary');s=next(r for r in pair if r['connection']=='secondary')
    orientation.append({'case_id':c['case_id'],'R':c['R'],'C':c['C'],'profile':c['profile'],'uniform':c['uniform'],
                        'primary_topology':p['topology'],'secondary_topology':s['topology'],
                        'primary_Pmax_W':p['Pmax_W'],'secondary_Pmax_W':s['Pmax_W'],
                        'secondary_minus_primary_W':s['Pmax_W']-p['Pmax_W'],
                        'primary_Vmpp_V':p['Vmpp_V'],'secondary_Vmpp_V':s['Vmpp_V'],
                        'primary_Impp_A':p['Impp_A'],'secondary_Impp_A':s['Impp_A']})
pd.DataFrame(orientation).to_csv(HERE/'orientation_comparison.csv',index=False)
residual_keys=['thermal_max_residual_K','KVL_max_residual_V','KCL_residual_A','electrical_power_residual_W','retained_energy_residual_W','source_energy_residual_W']
checks={'optical_case_count':len(cases),'successful_network_count':len(results),'unsupported_network_count':len(errors),
        'primary_main_count':sum(r['is_main_case'] and r['connection']=='primary' for r in results),
        'main_curve_points':len(curves),'main_curve_cell_rows':len(curvecells),
        'max_residuals':{key:max(abs(r[key]) for r in results) for key in residual_keys},
        'minimum_cell_voltage_V':min(r['minimum_cell_voltage_V'] for r in results),
        'minimum_branch_current_A':min(r['minimum_branch_current_A'] for r in results),
        'max_uniform_N_single_relative_difference_percent':max(abs(r['relative_difference_percent']) for r in uniform),
        'main_uniform_orientation_max_power_difference_W':max(abs(r['secondary_minus_primary_W']) for r in orientation if r['uniform']),
        'max_independent_MPP_bound_excess_W':max(r['Pmax_W']-r['sum_independent_cell_mpp_W'] for r in results),
        'main_boundary_limited_count':sum(r['is_main_case'] and r['connection']=='primary' and not r['is_interior_supported_MPP'] for r in results)}
output={'schema_version':'1.0','baseline':'Uploaded integrated-report joint-calibrated five-parameter model retained unchanged.',
        'contract_sha256':hashlib.sha256((ROOT/'study_contract.json').read_bytes()).hexdigest(),
        'optics_cases_sha256':hashlib.sha256(optics_path.read_bytes()).hexdigest(),
        'config':cfg,'Tsink_C':ts,'Rbus_ohm':rbus,'results':results,'errors':errors,'checks':checks,
        'definitions':{'Pmax_W':'Maximum actual array-port VI within common all-cell V>=0,I>=0 generation support; no full-network GMPP claim.',
          'Vmpp_V':'Port voltage at supported maximum, not necessarily full physical array Voc or Isc endpoint.',
          'sum_independent_cell_mpp_W':'Sum of separately optimized self-heating scalar-cell powers, used only as upper-bound reference, not as array output.',
          'mismatch_loss_W':'sum_independent_cell_mpp_W minus sum actual cell electrical powers at the shared array operating point.',
          'total_cell_heat_W':'Sum eta_h*Pin_i-V_i*I_i at the actual array operating point.',
          'source_energy_residual_W':'Ps-chain_loss-gap_loss-outside_loss-unretained_cell_optical-cell_heat-Pload-Pwire.',
          'Gaussian_uniform_reference':'Ideal equalized distribution after actual Gaussian capture; not a physical uniform Gaussian or measured homogenizer.'},
        'scope':'One scalar intercepted Pin and one uniform Tj for each complete six-junction cell. Independent identical sink boundary per cell. No within-cell distribution, lateral/shared heatsink, reverse bias, bypass, or extra electrical signal model.',
        'elapsed_seconds':time.perf_counter()-started}
(HERE/'results.json').write_text(json.dumps(output,ensure_ascii=False,indent=2))
(HERE/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
(HERE/'manifest.json').write_text(json.dumps({'command':'python arrays/run_arrays.py','status':'complete' if not errors else 'complete_with_explicit_unsupported_cases','source_model':'../core.py + ../input/source_model_config.json','source_model_sha256':hashlib.sha256((ROOT/'input/source_model_config.json').read_bytes()).hexdigest(),'python':platform.python_version(),'elapsed_seconds':time.perf_counter()-started,'files':['results.json','summary.csv','cell_states.csv','main_curves.csv','main_curve_cells.csv','uniform_scaling_checks.csv','orientation_comparison.csv','errors.csv','checks.json']},indent=2))
print(json.dumps(checks,indent=2),flush=True)
