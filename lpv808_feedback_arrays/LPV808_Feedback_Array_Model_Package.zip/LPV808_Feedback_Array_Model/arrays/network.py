"""Forward-generation-supported DC arrays with per-cell electrothermal roots.

Every cell is internally uniform and receives exactly one scalar Pin. Each
cell's steady heat source uses its actual branch-current operating power, not
its independent maximum power. The primary connection uses each geometric
column as a series string; the secondary uses each row as a series string.
No reverse, bypass, distributed-cell or unmeasured dynamic law is introduced.
"""
from pathlib import Path
import sys,time,json
import numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq,minimize_scalar

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
import core


class UnsupportedState(ValueError):pass


def groups_for_layout(R,C,orientation='primary'):
    if orientation=='primary':return [[r*C+c for r in range(R)] for c in range(C)]
    if orientation=='secondary':return [[r*C+c for c in range(C)] for r in range(R)]
    raise ValueError('orientation must be primary or secondary')


class CellBank:
    def __init__(self,powers,Tsink_C=25.,cfg=None,n_grid=401):
        self.powers=np.asarray(powers,dtype=float)
        self.n=len(self.powers);self.Tsink=float(Tsink_C)
        self.cfg=core.config(cfg) if hasattr(core,'config') else dict(core.DEFAULT_CONFIG,**(cfg or {}))
        self.rth=float(self.cfg['Rth_K_per_W']);self.eta=float(self.cfg['eta_h'])
        self.hot=self.Tsink+self.rth*self.eta*self.powers
        domain=self.cfg.get('temperature_domain_C',[0.,180.])
        if min(self.powers)<=0:raise UnsupportedState('Zero/dark optical cells need a separate measured model.')
        if max(self.hot)>domain[1]+1e-9:
            raise UnsupportedState('Open/short thermal endpoints exceed the declared junction-temperature domain.')
        self.isc=np.asarray(core.current(0.,self.powers,self.hot,self.cfg),dtype=float)
        self.voc=np.asarray(core.voltage(np.zeros(self.n),self.powers,self.hot,self.cfg),dtype=float)
        if min(self.isc)<=0 or min(self.voc)<=0:raise UnsupportedState('No positive-generation cell branch.')
        self.xgrid=np.linspace(0.,1.,int(n_grid));self.n_grid=len(self.xgrid)
        igrid=self.isc[:,None]*self.xgrid[None,:]
        states=self.at_current(igrid)
        self.v_grid=states['V_V'];self.t_grid=states['Tj_C']
        self.v_grid[:,0]=self.voc;self.v_grid[:,-1]=0.
        if np.any(np.diff(self.v_grid,axis=1)>=1e-9):raise UnsupportedState('Thermal cell branch not decreasing.')
        ip=PchipInterpolator(self.xgrid,self.v_grid,axis=1,extrapolate=False)
        self.coeff=ip.c
        self.table_max_thermal_residual_K=float(np.max(np.abs(states['thermal_residual_K'])))
        self._independent=None

    def at_current(self,currents,powers=None):
        """Vectorized true thermal fixed point for a specified per-cell current.

        Array shapes ncell or ncell x ngrid are supported. The current must be
        within each cell's thermal forward-current support (checked by caller).
        """
        ii=np.asarray(currents,dtype=float)
        pp=self.powers if powers is None else np.asarray(powers,dtype=float)
        if ii.ndim>1:pp=pp.reshape((len(pp),)+(1,)*(ii.ndim-1))
        hot=self.Tsink+self.rth*self.eta*pp
        tt=np.broadcast_to(self.Tsink+self.rth*(self.eta-.54)*pp,ii.shape).copy()
        if self.rth==0:tt[:]=self.Tsink
        for iteration in range(100):
            par=core.params(pp,tt,self.cfg)
            vv=np.asarray(core.voltage_params(ii,par,generation_only=False))
            target=self.Tsink+self.rth*(self.eta*pp-ii*vv)
            err=float(np.max(abs(target-tt)))
            tt=target
            if err<5e-11:break
        else:raise UnsupportedState('Vectorized thermal fixed point failed to converge.')
        par=core.params(pp,tt,self.cfg);vv=np.asarray(core.voltage_params(ii,par,generation_only=False))
        pout=ii*vv;q=self.eta*pp-pout
        residual=tt-self.Tsink-self.rth*q
        if max(np.ravel(abs(residual)))>2e-8:raise UnsupportedState('Thermal root residual too large.')
        if min(np.ravel(vv))<-2e-7 or min(np.ravel(ii))<-2e-10 or min(np.ravel(q))<-2e-7:
            raise UnsupportedState('Attempt to accept a cell outside positive-generation/energy support.')
        return {'V_V':vv,'I_A':ii,'Pout_W':pout,'Tj_C':tt,'Qheat_W':q,
                'thermal_residual_K':residual,'parameters':par,'iterations':iteration+1}

    def derivative(self,state):
        ii=state['I_A'];vv=state['V_V'];tt=state['Tj_C'];p=state['parameters']
        pp=self.powers
        if ii.ndim>1:pp=pp.reshape((len(pp),)+(1,)*(ii.ndim-1))
        internal=vv+ii*p['Rs_ohm']
        b=p['I0_A']/p['a_V']*np.exp(internal/p['a_V'])+1/p['Rsh_ohm']
        v_i=-1/b-p['Rs_ohm']
        eps=1e-3
        vp=np.asarray(core.voltage(ii,pp,tt+eps,self.cfg,generation_only=False))
        vm=np.asarray(core.voltage(ii,pp,tt-eps,self.cfg,generation_only=False))
        v_t=(vp-vm)/(2*eps)
        margin=1+self.rth*ii*v_t
        if min(np.ravel(margin))<=0:raise UnsupportedState('Unstable thermal branch in current-control parameterization.')
        return (v_i-self.rth*v_t*vv)/margin,margin

    def voltage_table(self,current,indices=None):
        js=np.arange(self.n) if indices is None else np.asarray(indices,dtype=int)
        f=np.asarray(current,dtype=float)/self.isc[js]
        if np.any(f<-1e-8) or np.any(f>1+1e-8):raise UnsupportedState('Interpolation request exceeds thermal current support.')
        f=np.clip(f,0.,1.)
        ks=np.minimum((f*(self.n_grid-1)).astype(int),self.n_grid-2)
        u=f-self.xgrid[ks];c=self.coeff[:,ks,js]
        return ((c[0]*u+c[1])*u+c[2])*u+c[3]

    def independent_mpps(self):
        if self._independent is not None:return self._independent
        # Vectorized bisection of V+I*dVsteady/dI. No fixed-temperature MPP is
        # substituted for the actual self-heating maximum.
        low=np.zeros(self.n);high=self.isc.copy()
        for _ in range(43):
            mid=(low+high)/2;state=self.at_current(mid);dv,margin=self.derivative(state)
            derivative=state['V_V']+mid*dv
            low=np.where(derivative>0,mid,low);high=np.where(derivative>0,high,mid)
        best=self.at_current((low+high)/2)
        self._independent=best
        return best


class ArrayNetwork:
    def __init__(self,bank,groups,Rbus_ohm=0.):
        self.bank=bank;self.groups=[np.asarray(g,dtype=int) for g in groups]
        self.ns=len(self.groups);self.n=bank.n;self.rbus=float(Rbus_ohm)
        if self.rbus<0:raise ValueError('Passive bus resistance must be nonnegative.')
        if sorted(np.concatenate(self.groups).tolist())!=list(range(self.n)):raise ValueError('Every cell must belong to exactly one string.')
        self.mapping=np.empty(self.n,dtype=int)
        for k,g in enumerate(self.groups):self.mapping[g]=k
        self.imax=np.array([min(bank.isc[g]) for g in self.groups])
        limiting=bank.at_current(self.imax[self.mapping])
        self.string_vmin=np.array([sum(limiting['V_V'][g]) for g in self.groups])
        self.string_vmax=np.array([sum(bank.voc[g]) for g in self.groups])
        self.umin=float(max(self.string_vmin));self.umax=float(min(self.string_vmax))
        if self.umin>=self.umax:raise UnsupportedState('No common positive-generation voltage interval.')
        self.cache={};self.solve_count=0
        if self.rbus>0 and self.state(self.umin)['Vport_V']<0:
            self.umin=brentq(lambda u:self.state(u)['Vport_V'],self.umin,self.umax,xtol=1e-11)

    def _branch_table_currents(self,u):
        out=[]
        for k,g in enumerate(self.groups):
            if abs(u-self.string_vmax[k])<2e-9:out.append(0.);continue
            if abs(u-self.string_vmin[k])<2e-9:out.append(self.imax[k]);continue
            def fun(i):return float(sum(self.bank.voltage_table(i,g))-u)
            low=fun(0.);high=fun(self.imax[k])
            if low<0 and low>-2e-7:out.append(0.)
            elif high>0 and high<2e-7:out.append(self.imax[k])
            elif low<0 or high>0:raise UnsupportedState('No string interpolation root in supported interval.')
            else:out.append(brentq(fun,0.,self.imax[k],xtol=5e-12))
        return np.array(out)

    def table_power(self,u):
        ib=self._branch_table_currents(float(u));it=float(sum(ib))
        return (float(u)-self.rbus*it)*it

    def state(self,u):
        u=float(u);key=round(u,12)
        if key in self.cache:return self.cache[key]
        if u<self.umin-2e-7 or u>self.umax+2e-7:raise UnsupportedState('Bus voltage outside supported domain.')
        ib=self._branch_table_currents(u)
        low=np.zeros(self.ns);high=self.imax.copy()
        for _ in range(16):
            s=self.bank.at_current(ib[self.mapping]);err=np.array([sum(s['V_V'][g])-u for g in self.groups])
            if max(abs(err))<3e-9:break
            dv,margin=self.bank.derivative(s);der=np.array([sum(dv[g]) for g in self.groups])
            low=np.where(err>0,ib,low);high=np.where(err<0,ib,high)
            new=ib-err/der
            new=np.where((new>=low)&(new<=high),new,(low+high)/2)
            ib=new
        else:raise UnsupportedState('Exact array branch-current refinement did not converge.')
        self.solve_count+=1
        it=float(sum(ib));vport=u-self.rbus*it;pout=vport*it
        if vport< -2e-7:raise UnsupportedState('Negative external load voltage.')
        cellpower=float(sum(s['Pout_W']));wire=self.rbus*it*it
        rows=[]
        for j in range(self.n):
            rows.append({'cell':j+1,'string':int(self.mapping[j])+1,'Pin_W':float(self.bank.powers[j]),
                         'Tj_C':float(s['Tj_C'][j]),'Vcell_V':float(s['V_V'][j]),
                         'Icell_A':float(s['I_A'][j]),'Pcell_W':float(s['Pout_W'][j]),
                         'Qheat_W':float(s['Qheat_W'][j]),'thermal_residual_K':float(s['thermal_residual_K'][j])})
        result={'Vbus_V':u,'Vport_V':float(vport),'Iport_A':it,'Pport_W':float(pout),
                'wire_loss_W':float(wire),'sum_cell_power_W':cellpower,'total_cell_heat_W':float(sum(s['Qheat_W'])),
                'Pin_total_W':float(sum(self.bank.powers)),
                'efficiency_received_percent':float(100*pout/sum(self.bank.powers)),
                'thermal_max_residual_K':float(max(abs(s['thermal_residual_K']))),
                'KVL_max_residual_V':float(max(abs(err))),
                'KCL_residual_A':float(it-sum(ib)),
                'electrical_power_residual_W':float(cellpower-wire-pout),
                'retained_energy_residual_W':float(self.bank.eta*sum(self.bank.powers)-sum(s['Qheat_W'])-pout-wire),
                'Tj_min_C':float(min(s['Tj_C'])),'Tj_max_C':float(max(s['Tj_C'])),
                'minimum_cell_voltage_V':float(min(s['V_V'])),'minimum_branch_current_A':float(min(ib)),
                'branch_currents_A':ib.tolist(),'cells':rows}
        self.cache[key]=result
        return result

    def optimum(self,scan_n=129):
        start=time.perf_counter();u=np.linspace(self.umin,self.umax,int(scan_n))
        pp=np.array([self.table_power(x) for x in u])
        peaks=np.flatnonzero((pp[1:-1]>=pp[:-2])&(pp[1:-1]>=pp[2:]))+1
        cand=[self.state(self.umin),self.state(self.umax)]
        for k in peaks:
            low=u[max(k-2,0)];high=u[min(k+2,len(u)-1)]
            opt=minimize_scalar(lambda uv:-self.state(float(uv))['Pport_W'],bounds=(low,high),
                                method='bounded',options={'xatol':2e-8})
            cand.append(self.state(float(opt.x)))
        best=dict(max(cand,key=lambda st:st['Pport_W']))
        independent=self.bank.independent_mpps();upper=float(sum(independent['Pout_W']))
        for j,row in enumerate(best['cells']):row['independent_cell_mpp_W']=float(independent['Pout_W'][j])
        edge=min(best['Vbus_V']-self.umin,self.umax-best['Vbus_V'])
        best.update({'supported_bus_min_V':self.umin,'supported_bus_max_V':self.umax,
                     'supported_port_min_V':self.state(self.umin)['Vport_V'],
                     'supported_port_max_V':self.state(self.umax)['Vport_V'],
                     'is_interior_supported_MPP':bool(edge>1e-5),
                     'maximum_label':'interior_supported_MPP' if edge>1e-5 else 'boundary_limited_supported_maximum',
                     'claimed_full_network_GMPP':False,'sum_independent_cell_mpp_W':upper,
                     'mismatch_loss_W':float(upper-cellpower) if (cellpower:=best['sum_cell_power_W']) else float(upper),
                     'mismatch_loss_percent':float(100*(upper-cellpower)/upper),
                     'total_loss_vs_independent_percent':float(100*(upper-best['Pport_W'])/upper),
                     'groups_1based':[[int(j)+1 for j in g] for g in self.groups],
                     'Rbus_ohm':self.rbus,'grid_current_points_per_cell':self.bank.n_grid,
                     'candidate_peaks_scanned':len(peaks),'power_scan_points':int(scan_n),
                     'runtime_seconds':time.perf_counter()-start,'exact_network_states':self.solve_count})
        if best['Pport_W']>upper+2e-7:raise UnsupportedState('Array exceeds independent-cell self-heating MPP bound.')
        return best

    def curve(self,n=161):
        return [self.state(float(u)) for u in np.linspace(self.umin,self.umax,int(n))]


if __name__=='__main__':
    bank=CellBank([8.]*9)
    network=ArrayNetwork(bank,groups_for_layout(3,3))
    print(json.dumps(network.optimum(),indent=2))
