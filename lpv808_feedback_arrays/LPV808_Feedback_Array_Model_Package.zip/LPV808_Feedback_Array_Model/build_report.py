"""Build the Chinese research report from saved, reproducible simulation outputs."""
from pathlib import Path
import json,os,re,hashlib
import pandas as pd
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT

ROOT=Path(__file__).resolve().parent
OUT=Path(os.environ.get('LPV_OUTPUT_DIR','/workspace/output' if Path('/workspace/output').exists() else str(ROOT/'output')));OUT.mkdir(exist_ok=True)
load=lambda p:json.loads((ROOT/p).read_text())
contract=load('study_contract.json');single=load('single/summary.json');base=load('report/baseline_metrics.json')
optics=load('optics/cases.json');cases={c['case_id']:c for c in optics['cases']}
array=load('arrays/results.json');results=array['results'];main=[a for a in results if a['is_main_case'] and a['connection']=='primary']
figs={f['key']:f for f in load('figures/figures.json')}
fb=pd.read_csv(ROOT/'single/feedback_summary.csv');hist=pd.read_csv(ROOT/'single/fixedpoint_iterations.csv')
ode=pd.read_csv(ROOT/'single/thermal_ODE_summary.csv');sensitivity=pd.read_csv(ROOT/'single/coefficient_boundary_sensitivity.csv')
layouts=contract['layouts'];profiles=['Gaussian_uniform_reference','Gaussian_nonuniform','TopHat_uniform','TopHat_nonuniform']
labels={'Gaussian_uniform_reference':'高斯理想均匀参照','Gaussian_nonuniform':'高斯非均匀','TopHat_uniform':'平顶均匀','TopHat_nonuniform':'平顶非均匀'}
short={'Gaussian_uniform_reference':'G-均匀参照','Gaussian_nonuniform':'G-非均匀','TopHat_uniform':'TH-均匀','TopHat_nonuniform':'TH-非均匀'}
get=lambda R,C,profile,connection='primary':next(a for a in results if a['R']==R and a['C']==C and a['profile']==profile and a['is_main_case'] and a['connection']==connection)
f=lambda x,n=4:f'{float(x):.{n}f}'

doc=Document();sec=doc.sections[0]
sec.page_width=Cm(21);sec.page_height=Cm(29.7)
sec.top_margin=Cm(1.65);sec.bottom_margin=Cm(1.65);sec.left_margin=Cm(1.9);sec.right_margin=Cm(1.9)
sec.header_distance=sec.footer_distance=Cm(.65)
LAT='Times New Roman';CJK='SimSun';BLUE='174C8B'
def font(run,size=None,bold=None,color=None):
 run.font.name=LAT
 if size is not None:run.font.size=Pt(size)
 if bold is not None:run.bold=bold
 if color:run.font.color.rgb=RGBColor.from_string(color)
 pr=run._element.get_or_add_rPr();rf=pr.find(qn('w:rFonts'))
 if rf is None:rf=OxmlElement('w:rFonts');pr.insert(0,rf)
 is_cjk=bool(re.search(r'[\u2E80-\u9FFF\uF900-\uFAFF\u3000-\u303F\uFF01-\uFF60]',run.text))
 for k,v in [('ascii',LAT),('hAnsi',LAT),('eastAsia',CJK if is_cjk else LAT),('cs',LAT)]:rf.set(qn('w:'+k),v)
 rf.set(qn('w:hint'),'eastAsia' if is_cjk else 'default')
 for attr in ['asciiTheme','hAnsiTheme','eastAsiaTheme','cstheme']:
  rf.attrib.pop(qn('w:'+attr),None)
 return run
for st in doc.styles:
 if hasattr(st,'font'):
  st.font.name=LAT
  try:st._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),CJK)
  except AttributeError:pass
norm=doc.styles['Normal'];norm.font.size=Pt(10.5)
norm.paragraph_format.line_spacing=1.16;norm.paragraph_format.space_after=Pt(5)
for name,size in [('Title',24),('Subtitle',13),('Heading 1',15.5),('Heading 2',12),('Caption',9.2)]:
 st=doc.styles[name];st.font.size=Pt(size)
 st.paragraph_format.space_before=Pt(5);st.paragraph_format.space_after=Pt(6)
 if name.startswith('Heading'):st.font.color.rgb=RGBColor.from_string(BLUE);st.paragraph_format.keep_with_next=True

def rich(pp,text,size=None,bold=None,color=None):
 supers='⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺';normal='0123456789-+'
 text=re.sub('['+supers+']+',lambda m:'^{'+m.group().translate(str.maketrans(supers,normal))+'}',str(text))
 for token in re.split(r'(_\{[^}]+\}|\^\{[^}]+\})',text):
  if not token:continue
  sub=token.startswith('_{');sup=token.startswith('^{')
  value=token[2:-1] if sub or sup else token
  for part in re.findall(r'[\u2E80-\u9FFF\uF900-\uFAFF\u3000-\u303F\uFF01-\uFF60]+|[^\u2E80-\u9FFF\uF900-\uFAFF\u3000-\u303F\uFF01-\uFF60]+',value):
   r=font(pp.add_run(part),size,bold,color)
   r.font.subscript=sub;r.font.superscript=sup
 return pp
def p(text='',size=None,bold=False,color=None,style=None):
 pp=doc.add_paragraph(style=style);rich(pp,text,size,bold,color);return pp
def h(text,level=2):return p(text,style=f'Heading {level}')
page_titles=[]
def page(title):
 page_titles.append(title)
 pp=h(title,1);pp.paragraph_format.page_break_before=True
def eq(s):
 pp=p(s,12.2);pp.alignment=WD_ALIGN_PARAGRAPH.CENTER;pp.paragraph_format.space_after=Pt(7);return pp
def note(s):return p(s,9.2,color='546477')
def table(headers,rows,widths=None,size=9.2):
 tb=doc.add_table(rows=1,cols=len(headers));tb.alignment=WD_TABLE_ALIGNMENT.CENTER;tb.autofit=False
 if widths is None:widths=[17.2/len(headers)]*len(headers)
 for j,hd in enumerate(headers):rich(tb.rows[0].cells[j].paragraphs[0],hd,size,True)
 for row in rows:
  cells_=tb.add_row().cells
  for j,val in enumerate(row):rich(cells_[j].paragraphs[0],val,size)
 for j,w in enumerate(widths):tb.columns[j].width=Cm(w)
 borders=OxmlElement('w:tblBorders')
 for side in ['top','left','bottom','right','insideH','insideV']:
  z=OxmlElement('w:'+side);z.set(qn('w:val'),'single');z.set(qn('w:sz'),'4');z.set(qn('w:color'),'CBD5E1');borders.append(z)
 tb._tbl.tblPr.append(borders)
 for k,row in enumerate(tb.rows):
  tr=row._tr.get_or_add_trPr();tr.append(OxmlElement('w:cantSplit'))
  if k==0:tr.append(OxmlElement('w:tblHeader'))
  for j,c in enumerate(row.cells):
   c.width=Cm(widths[j]);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'E8EFF7' if k==0 else ('F7F9FB' if k%2 else 'FFFFFF'));c._tc.get_or_add_tcPr().append(shade)
   mar=OxmlElement('w:tcMar')
   for side in ['top','bottom','left','right']:
    z=OxmlElement('w:'+side);z.set(qn('w:w'),'65');z.set(qn('w:type'),'dxa');mar.append(z)
   c._tc.get_or_add_tcPr().append(mar)
   for pp in c.paragraphs:
    pp.paragraph_format.line_spacing=1.03;pp.paragraph_format.space_before=Pt(2);pp.paragraph_format.space_after=Pt(2)
    if j:pp.alignment=WD_ALIGN_PARAGRAPH.CENTER
 p('',size=2).paragraph_format.space_after=Pt(1)
 return tb
fig_no=0
def picture(path,caption,width=16.8):
 global fig_no
 pp=doc.add_paragraph();pp.alignment=WD_ALIGN_PARAGRAPH.CENTER;pp.paragraph_format.space_after=Pt(2)
 pp.add_run().add_picture(str(path),width=Cm(width));fig_no+=1
 cap=p(f'图 {fig_no}  {caption}',style='Caption');return cap
def fig(key):
 x=figs[key];picture(ROOT/'figures'/Path(x['png']).name,x['caption'])

header=sec.header.paragraphs[0];rich(header,'808 nm GaAs 激光光伏电池：闭环反馈与大规模阵列预测',8.5,color='64748B')
footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
rich(footer,'第 ',8)
for command,tail in [('PAGE',' 页 / 共 '),('NUMPAGES',' 页')]:
 field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),command);footer._p.append(field);rich(footer,tail,8)

# Cover.
p('仿真研究报告',13,True,color=BLUE)
p('808 nm 六结 GaAs 激光光伏电池\n光—热—电耦合反馈与阵列输出预测',style='Title')
p('单体反馈计算验证 · 3×3 / 4×4 / 4×5 / 5×5 阵列\n高斯与平顶光束 · 均匀参照及非均匀辐照',style='Subtitle')
p('以用户上传的 LPV808_6J_Integrated_Report (1).docx 为基准，保留其联合标定五参数、温度迁移关系和条件热边界，新增单体反馈的计算验证、四种阵列规模的输出预测及逐片空间图。所有新增结果由本报告配套程序重新计算。')
table(['内容','本次完成'],[
 ['单体闭环','冻结参数、一次更新与自洽闭环比较；固定点、独立根与热 ODE 核对'],
 ['阵列研究','128 个光学工况主连接 + 16 个代表工况的连接方向对照，共 144 个网络'],
 ['空间结果','正文 16 个主工况的辐照度、电功率和结温图；另附完整 128 工况辐照图册'],
 ['建模尺度','每片电池一个接收功率、一个等效结温；仅研究片与片之间的辐照不均匀'],
 ['证据边界','原工况 I–V 标定有实测支撑；新增温度、功率及阵列结果为条件预测']
 ],[3.1,14.1],10)
p('参考样品：LPV-808-164-007\n器件：808 nm、GaAs、垂直串联六结、有效面积 1 cm²\n编制日期：2026 年 11 月 28 日')
note('英文与数字采用 Times New Roman，中文采用宋体（SimSun）；正文图片均内嵌，图内字体同样按上述要求生成。无片内电流、温度或微区效率分布模型。')

page('1  主要结果与阅读口径')
p('在保持原报告模型不变的条件下，单体温度会改变端口参数和电输出；电输出变化又改变发热量，形成可计算的闭环。16 W 时一次更新的热平衡残差为 −2.142795 K，自洽闭环收敛到 56.836603°C、8.521387 W。')
table(['Pin / W','冻结25°C功率 / W','一次更新 / W','闭环功率 / W','闭环 Tj / °C'],[[f(x.Pin_W,0),f(x.freeze_T25_Pout_W),f(x.one_pass_Pout_W),f(x.closed_loop_Pout_W),f(x.closed_loop_Tj_C)] for _,x in fb.iterrows()],[1.6,4.0,3.0,3.1,5.5])
p('主阵列比较统一为每片平均接收 8 W、每片散热端 25°C；各列串联、各列支路并联。下表为所有单体均处于正向发电支持域内的最大输出。高斯“均匀”项是理想等分参照，平顶均匀项可由覆盖整个外框的平顶圆光斑实现。')
table(['布局 / 主连接','均匀参考 / W','高斯非均匀 / W','平顶非均匀 / W'],[[f'{R}×{C} / {R}S{C}P',f(get(R,C,'TopHat_uniform')['Pmax_W']),f(get(R,C,'Gaussian_nonuniform')['Pmax_W']),f(get(R,C,'TopHat_nonuniform')['Pmax_W'])] for R,C in layouts],[4.1,4.2,4.4,4.5])
p('这些数值不是新增实测功率，也不是任意光斑和散热条件下的通用排序。相同总接收功率用于观察分配失配；相同激光源功率用于进一步比较截获损失，两类结果在全文分别列示。')

page('2  研究对象、继承参数与证据来源')
p('本次明确采用上传综合报告的联合标定端口模型，未替换为此前另一份解析法参数，也未重新拟合原始数据。名义 8 W 沿用原报告作为单片有源面入射功率的归一化假设；其实际功率计参考面仍需实验确认。')
table(['五参数','沿用值','单位'],[[k,str(v),unit] for (k,v),unit in zip(contract['baseline_parameters'].items(),['A','A','V','Ω','Ω'])],[4.5,8.7,4.0],10)
picture(ROOT/'report/extra_figures/baseline_reconstruction.png','沿用参数对原 72 点 I–V 的重构与残差；参考结温 40°C 为模型假设，并非结温测量。')
note(f"原工况 RMSE={base['RMSE_mA']:.6f} mA；NRMSE={base['NRMSE_percent_Isc']:.6f}%Isc；最大绝对残差={base['max_abs_mA']:.6f} mA。该精度只属于原工况同扫描重构，不能转移为新阵列的实验预测精度。")

page('3  五参数—温度—接收功率关系')
eq('I = I_{ph} − I_{0}[exp((V + IR_{s})/a) − 1] − (V + IR_{s})/R_{sh}')
p('电流流向负载为正。a 是完整六结器件的端口等效指数电压，不等同于未经验证的单结微观理想因子。采用温度的绝对值更新 a，并保持参考五参数精确不变。')
eq('I_{ph}(P,T) = I_{ph,0}(P/8)[1 + α_{I}(T − 40)]')
eq('a(T) = a_{0}(T + 273.15)/(40 + 273.15)')
eq('V_{oc,8}(T) = V_{oc,0} + β_{Voc}(T − 40)')
eq('I_{0}(T) = [I_{ph,8}(T) − V_{oc,8}(T)/R_{sh}]/[exp(V_{oc,8}(T)/a(T)) − 1]')
eq('R_{s}(T) = R_{s,0}[1 + γ_{Rs}(T − 40)]； R_{sh}(T) = R_{sh,0}')
table(['量','本次主值','采用依据'],[
 ['P0 / Tref','8 W / 40°C','沿用上传报告的参考功率和假定结温'],
 ['βVoc','−0.00815 V/K','沿用报告迁移的整器件温系，不再乘六'],
 ['αI / γRs','0 / 0 K⁻¹','原报告简化情景，不表示真实温度系数为零'],
 ['Rth / Cth','5.415665922 K/W / 0.30 J/K','条件封装参数，未经独立热测量'],
 ['fret / Tsink','0.90 / 25°C','净留存光能比例与每片恒温散热端'],
 ['ηchain','0.90','上游传输效率，作用位置不同于 fret']
 ],[3.2,6.0,8.0])
p('每一步都会重新评价五参数关系，但在同一接收功率下，αI=γRs=0、Rsh 恒定使 Iph、Rs、Rsh 不变，实际温变主要体现在 a 和 I0。不能把“重算五参数”写成“五个数值都随温度改变”。')

page('4  单体光—热—电反馈计算链')
picture(ROOT/'report/extra_figures/feedback_architecture.png','从源功率、接收功率到电输出及结温反馈的计算链；每片电池独立使用完整单体模型。')
eq('C_{th} dT_{j}/dt = f_{ret}P_{in} − P_{e}(P_{in},T_{j}) − (T_{j}−T_{sink})/R_{th}')
eq('稳态：T_{j} = T_{sink} + R_{th}[f_{ret}P_{in} − P_{e}(P_{in},T_{j})]')
p('求解顺序为：给定 Pin 与边界 → 用当前 Tj 更新五参数 → 解电路或理想 MPPT → 计算实际 Pe=VI → 由 Q=fretPin−Pe 更新 Tj → 重复直至热残差满足容限。阵列使用实际共同工作点的单片 VI，不能用各片独立 MPP 替代。')
table(['计算路径','数值作用'],[
 ['固定点迭代','从 25°C 开始，逐轮更新 θ、Pe、Q 和 Tj，展示反馈过程'],
 ['Brent 标量求根','直接求稳态热方程的零点，与固定点结果交叉核对'],
 ['热 ODE 积分','对光功率阶跃求 Tj(t)，检查长时间终值及能量积分'],
 ['独立实现','用内节点势与标量根法重新核对，避免只比对同一函数']
 ],[3.4,13.8])
note('电功率 VI 已包含端口模型中的二极管、串阻及漏电效应；热源中不再另扣一次电阻损耗。fret 表示未以反射、透射或再发光等方式逃逸的光能比例，是独立条件假设。')

page('5  迭代过程与闭环成立的数值证据')
fig('single_iterations')
rows=hist[hist.Pin_W==16].iloc[[0,1,2,3,5,-1]]
table(['轮次','Tj / °C','Pe / W','I0 / A','a / V','热残差 / K'],[[int(x.iteration),f(x.Tj_C,6),f(x.Pout_W,6),f'{x.I0_A:.3e}',f(x.a_V,7),f'{x.thermal_residual_K:.2e}'] for _,x in rows.iterrows()],[1.2,3.0,2.8,3.0,3.0,4.2],9)
p('16 W 时从冻结 25°C 电性能开始，第一次热更新得到 54.527020°C；用此温度重算电输出后，热方程仍不平衡。迭代到 56.836603°C 后，固定点与直接根法的温差小于 10⁻⁹ K，说明所声明方程在该功率下获得同一自洽解。')
note('8 W、40°C 由参考热阻的构造式强制复现，属于锚定检查。12 W 和 16 W 的迭代、根求解及时间域核对用于检验反馈实现，但仍不等于目标样品热温系已经实验验证。')

page('6  冻结、一次更新与闭环的输出差异')
fig('single_comparison')
table(['Pin / W','闭环较冻结降幅 / %','一次更新残差 / K','迭代次数','闭环 Q / W'],[[f(x.Pin_W,0),f(x.feedback_power_loss_vs_frozen_percent,3),f(x.one_pass_residual_K,4),int(x.iteration_count),f(x.closed_loop_Qheat_W,4)] for _,x in fb.iterrows()],[1.8,4.4,4.0,2.8,4.2])
p('16 W 下冻结 25°C 模型给出 8.947850 W，闭环为 8.521387 W，条件降幅约 4.766%。这与原报告以“固定 40°C”为参照得到的约 2.57% 降幅口径不同，二者不能直接混用。')
eq('g = −R_{th}(∂P_{e}/∂T)； τ_{eff} = R_{th}C_{th}/(1 − g)')
p('在采用的负电压温系下，升温降低 Pe，继而增加 Q 并进一步升温，属于正向电热反馈。16 W 时 g=0.072190，散热提供的恢复作用使 1−g=0.927810>0，局部稳态稳定；固定点迭代的收缩条件也得到满足。')

page('7  热瞬态、终值与积分能量核对')
fig('thermal_ode')
table(['光功率阶跃','初始 Tj / °C','终态 Tj / °C','t63.2 / s','线性化 τ / s'],[[x['case'].replace('to','→').replace('W',' W'),f(x.initial_Tj_C,3),f(x.final_root_Tj_C,3),f(x.t63p2_after_step_s,4),f(x.linearized_final_tau_s,4)] for _,x in ode.iterrows()],[3.5,3.4,3.4,3.4,3.5])
p('光功率在 0.5 s 发生阶跃。理想瞬时 MPPT 下电输出可立即变化，而含热容的结温保持连续，随后逐渐升高。稳态时热 ODE 终值与直接热根一致，30 s 端点温差小于 10⁻⁶ K。')
eq('∫f_{ret}P_{in}dt = ∫P_{e}dt + ∫(T_{j}−T_{sink})/R_{th}dt + C_{th}ΔT_{j}')
note('独立时间域计算的积分能量残差约为 10⁻¹¹ J 量级；该量说明计算守恒，不是热模型相对实测的误差。秒级时间常数不能解释为电信号带宽或 f3dB。')

page('8  光束模型与源功率守恒')
eq('P_{beam} = η_{chain}P_{s}； P_{in,i} = ∫∫_{Ai} G(x,y)dA')
eq('Gaussian：G = 2P_{beam}/(πw²) · exp[−2((x−x0)²+(y−y0)²)/w²]')
eq('TopHat：G = P_{beam}/(πr²)（圆内）；圆外 G = 0')
p('高斯 w 为强度 1/e² 半径。Gaussian 对方形有源面使用 erf 解析积分；圆平顶按圆与矩形交叠面积积分，不能仅按光斑中心值乘面积。间隙功率在逐片积分时自然排除，不再额外乘填充率。')
eq('P_{s} = P_{chain-loss}+P_{gap}+P_{outside}+ΣP_{in,i}')
eq('P_{s} = P_{chain-loss}+P_{gap}+P_{outside}+(1−f_{ret})ΣP_{in,i}+ΣQ_i+P_{out}')
table(['比较口径','设定','回答的问题'],[
 ['相同总接收功率','ΣPin=N×平均 Pin；扫描 2、4、6、8 W/片','相同入射总能量怎样因空间分配、热反馈与网络失配改变输出'],
 ['相同源功率','Ps=40、80、120、160 W','包含外逸、拼缝和传输后，各方案实际可输出多少'],
 ['主工况','平均 Pin=8 W/片，16 种布局/光束/分布组合','逐片辐照、电功率、结温及完整支持域曲线']
 ],[3.3,6.0,7.9])
p('高斯理想均匀参照保持同一实际高斯光场的截获总功率和源功率，将已截获能量无损等分到各片，只用于比较基准；它不是物理上完全均匀的高斯光束，也不是实测匀光器效率。')

page('9  阵列几何、光场及工况设计')
table(['布局','片数','外框 Lx×Ly / mm','主连接','方向对照'],[[f'{R}×{C}',R*C,f"{cases[f'R{R}C{C}_TopHat_uniform_received_mean_8']['geometry']['Lx_mm']:.1f}×{cases[f'R{R}C{C}_TopHat_uniform_received_mean_8']['geometry']['Ly_mm']:.1f}",f'{R}S{C}P',f'{C}S{R}P'] for R,C in layouts],[2.2,1.6,6.0,3.7,3.7])
p('R×C 指 R 行、C 列；上排为正 y。每片 10 mm×10 mm，间隙 0.3 mm。主连接为每列 R 片串联、C 个支路并联，因此 4×5 主方案是 4串5并，方向对照为 5串4并。外部串联单体数与每只器件内部六结数分别处理。')
table(['光场类别','半径 / 偏移规则','均匀性解释'],[
 ['高斯非均匀','w=0.60√(LxLy)；(x0,y0)=(0.10Lx,0.07Ly)','对每片积分，保留实际片间差异'],
 ['高斯均匀参照','截获比例、Ps 与对应非均匀高斯相同','仅将截获总功率理想均分'],
 ['平顶均匀','r=1.02×0.5√(Lx²+Ly²)，居中','圆光斑覆盖整个外框'],
 ['平顶非均匀','r=0.60√(LxLy)；相同相对偏移','边缘电池部分覆盖，片间平均辐照度不同']
 ],[3.0,7.8,6.4])
p('每片面积为 1 cm²，所以 Pin 的 W 数值恰等于平均 G 的 W/cm² 数值，但二者物理量与单位不同。所有热图均按整片常值绘制，不平滑插值，不计算单体内部的辐照不均匀响应。')
note('16 个主工况的逐片 Pin 范围为 0.5358–16.6745 W；完整功率扫描为 0.0731–22.9011 W。平均功率 2–8 W/片不意味着所有单片都落在该区间，低光和高光端存在额外外推。')

page('10  阵列电路—热节点的自洽求解')
eq('第 s 串：I_{i}=I_{s}； V_{bus}=Σ_{i}V_{i}(I_{s},P_{in,i},T_{j,i})（对该串各片求和）')
eq('I_{out}=Σ_{s}I_{s}； P_{out}=V_{bus}I_{out}； R_{bus}=0')
eq('每片：T_{j,i}=25+R_{th}[0.9P_{in,i}−V_{i}I_{i}]')
p('先构造每片在给定电流下的热自洽电压支路，再组合各串并联支路。扫描共同端口电压，对所有候选峰值和边界进行真实方程精化，而不是把各单体最大功率直接相加作为阵列输出。')
table(['量','定义'],[
 ['Pind','各片在各自独立 MPPT 和同热边界下的功率总和，用作上界'],
 ['失配损失','Lmis=1−Parray/Pind，反映共同工作点约束'],
 ['均匀参照降幅','Ltotal=1−Pnonuniform/Puniform，同时含功率分配非线性与网络失配'],
 ['正向支持域','所有单体 V≥0、I≥0 的共同端口区间'],
 ['边界受限最大值','最大值落在支持域边界时单独标记，不能称未知全支路的全局 MPP']
 ],[3.7,13.5])
p('不新增未经测量的反向击穿、旁路二极管或阻断器件，也不把被截断的支路端点当作阵列真实 Isc/Voc。所有 16 个主工况的最大值位于支持域内部；完整扫描另有 3 个低源功率工况落在边界。')
note('每片独立通过相同 Rth 接至固定 25°C 散热端；不包含片间导热及共同散热器温升。增大片数仍能维持该边界，需要实际散热系统提供相应能力。')

# Eight pages, each contains every whole-cell irradiance, electrical-power and temperature value.
section=11
for R,C in layouts:
 for beam in ['Gaussian','TopHat']:
  page(f'{section}  {R}×{C} 阵列：'+('高斯光束' if beam=='Gaussian' else '平顶光束')+'空间结果')
  ps=['Gaussian_uniform_reference','Gaussian_nonuniform'] if beam=='Gaussian' else ['TopHat_uniform','TopHat_nonuniform']
  p(f'主连接 {R}S{C}P；每片平均接收 8 W，总接收 {R*C*8} W；Tsink=25°C。上行为均匀参照或均匀覆盖，下行为非均匀接收；三列依次为平均辐照度、实际阵列工作点下的单体电功率、结温。')
  fig(f'heatmap_R{R}C{C}_{beam}')
  rows=[]
  for pro in ps:
   a=get(R,C,pro);c=cases[a['case_id']]
   rows.append([short[pro],f(c['Ps_W'],3),f(a['Pmax_W'],4),f(a['Vmpp_V'],3),f(a['Impp_A'],4),f(a['Tmax_C'],2),f(c['CV_G_percent'],2)])
  table(['条件','Ps / W','Pout / W','Vout / V','Iout / A','最高Tj / °C','辐照 CV / %'],rows,[3.1,2.4,2.6,2.4,2.4,2.3,2.0],8.8)
  a=get(R,C,ps[1]);c=cases[a['case_id']];u=get(R,C,ps[0]);drop=100*(1-a['Pmax_W']/u['Pmax_W'])
  p(f"非均匀条件下，逐片接收范围 {c['minPin_W']:.3f}–{c['maxPin_W']:.3f} W；输出较同总接收功率的均匀参照下降 {drop:.2f}%，实际网络失配损失为 {a['mismatch_loss_percent']:.2f}%。最高结温 {a['Tmax_C']:.2f}°C，说明高接收光功率位置若电工作点受限，会增加留在热节点中的能量。")
  note('每格代表一片完整六结单体；格内数字为片平均或片集总量，不能解释为片内热点分布。'+('高斯上行为理想均分对照，未计实际匀光系统损耗。' if beam=='Gaussian' else '平顶均匀与非均匀使用不同半径；同接收总量不代表同源功率。'))
  section+=1

page('19  四种布局的支持域输出 P–V 曲线')
fig('array_pv')
p('均匀参考与均匀平顶在相同每片 Pin 下重合，因为它们向相同端口模型提供相同输入。非均匀曲线只画全部单片均正向发电的共同区间；曲线未延伸到零电压不表示缺图，而是反向/旁路支路尚无实测模型。')
table(['布局','均匀 P / W','G 非均匀 / W','TH 非均匀 / W','G 降幅 / %'],[[f'{R}×{C}',f(get(R,C,'TopHat_uniform')['Pmax_W'],3),f(get(R,C,'Gaussian_nonuniform')['Pmax_W'],3),f(get(R,C,'TopHat_nonuniform')['Pmax_W'],3),f(100*(1-get(R,C,'Gaussian_nonuniform')['Pmax_W']/get(R,C,'TopHat_uniform')['Pmax_W']),2)] for R,C in layouts],[2.4,3.7,3.7,3.7,3.7])
note('本次 5×5 高斯输出低于 4×5，来自光斑随外框重设、支路串联长度与弱片分布共同变化；不是“固定光束下增加电池必然减小输出”的普遍规律。')

page('20  相同总接收功率下的功率扫描')
fig('received_sweep')
p('扫描平均每片 2、4、6、8 W。对同一布局，每档四种分布的总接收功率均为 N 倍平均功率。此口径排除有源面截获总量差异，突出片间功率分配、温度与网络约束的耦合作用。')
table(['布局','平均2 W/片：G / W','平均8 W/片：G / W','平均8 W/片：TH / W'],[[f'{R}×{C}',f(next(a for a in results if a['R']==R and a['C']==C and a['profile']=='Gaussian_nonuniform' and a['connection']=='primary' and a.get('target_meanPin_W')==2)['Pmax_W'],3),f(get(R,C,'Gaussian_nonuniform')['Pmax_W'],3),f(get(R,C,'TopHat_nonuniform')['Pmax_W'],3)] for R,C in layouts],[2.8,4.8,4.8,4.8])
p('均匀情景下在相同单片热边界下满足 Parray=N×Psingle，因此增加片数提高总输出。非均匀情景的失配程度由完整空间排列与电连接决定，不能仅用 CV 一个统计量预测输出。')

page('21  相同激光源功率下的系统输出')
fig('source_sweep')
p('源功率 Ps 固定为 40、80、120、160 W。阵列截获率因布局、光斑半径和偏移不同而变化，实际平均 Pin 不再相等。圆平顶完全覆盖外框需要较大光斑，外逸会降低同源功率下的截获量；高斯均匀参照仍只是保持实际高斯捕获率的理想对照。')
rows=[]
for R,C in layouts:
 vals=[next(a for a in results if a['R']==R and a['C']==C and a['profile']==pro and a['connection']=='primary' and a.get('target_Ps_W')==160)['Pmax_W'] for pro in profiles]
 rows.append([f'{R}×{C}']+[f(v,3) for v in vals])
table(['Ps=160 W','G 理想均匀 / W','G 非均匀 / W','TH 均匀 / W','TH 非均匀 / W'],rows,[2.4,4.0,3.6,3.6,3.6])
note('空心三角为支持域边界最大值。源 40 W 下 4×5 平顶非均匀、5×5 高斯非均匀与 5×5 平顶非均匀为此类型，不能据其端点推断实际反偏或旁路后的完整阵列输出。')

page('22  串并联方向、失配与热负荷')
rows=[]
for R,C in layouts:
 for pro in ['Gaussian_nonuniform','TopHat_nonuniform']:
  a=get(R,C,pro);b=get(R,C,pro,'secondary')
  rows.append([f'{R}×{C}',short[pro],f'{R}S{C}P',f(a['Pmax_W'],3),f'{C}S{R}P',f(b['Pmax_W'],3),f(a['mismatch_loss_percent'],2)])
table(['布局','分布','主连接','主 P / W','方向对照','对照 P / W','主失配 / %'],rows,[1.7,3.2,2.1,2.6,2.1,2.8,2.7],8.8)
p('4×5 高斯非均匀情景在相同接收矩阵下，4S5P 输出 53.468974 W，5S4P 为 26.739529 W；平顶非均匀分别为 78.528324 W 和 42.970289 W。改变连接方向改变哪些弱片处于同一串、各串的公共电压区间以及每片热负荷。')
eq('P_{ind}=ΣP_{i,独立MPP}； L_{mis}=1−P_{array}/P_{ind}')
eq('L_{dist}=1−P_{ind}/P_{uniform}；1−L_{total}=(1−L_{dist})(1−L_{mis})')
p('5×5、总接收 200 W 时，均匀条件下总发热约 69.2436 W，高斯非均匀主连接约 129.1453 W。相同光输入中较少能量输出到负载，会使更多能量进入热节点，故阵列方案必须同时评价功率与温度。')
note('本次没有加入线阻或共同散热器温升，不能据此宣称任意实物布线均可达到上述输出。失配损失和相对均匀参考的总降幅采用不同分母，不能相互替代。')

page('23  条件热参数与温度律的敏感性')
sel=sensitivity[(sensitivity['Pin_W']==16)]
p('热阻、散热端温度、温度系数均未由目标样品多工况辨识。本节的变化是情景敏感性，不是统计置信区间。只有独立热测量与受控温度 I–V 才能把当前条件预测收紧为目标样品模型。')
cols=sel.columns.tolist();note('完整 72 行敏感性数据保留在 coefficient_boundary_sensitivity.csv；以下说明关键反馈区分。')
table(['模型情景（16 W）','Tj / °C','Pe / W','解释'],[
 ['主 βVoc=−8.15 mV/K','56.8366','8.5214','负电压温系与 a(T)、I0(T)共同作用'],
 ['仅令 βVoc=0','55.7823','8.7161','a(T)、I0(T)仍更新，并非取消全部温度反馈'],
 ['全部参数冻结在25°C','54.5270','8.9479','电输出不再随结温变化；热状态仍可升高']
 ],[6.1,2.7,2.7,5.7],9.3)
p('在相同主温度律和 16 W 接收功率下，进一步改变散热热阻与冷端温度，得到：')
thermal_sens=sel[(abs(sel['beta_Voc_V_per_K']+0.00815)<1e-10)&(sel['temperature_update_policy']=='all_five_parameters_updated')]
table(['Rth / K/W','Tsink / °C','闭环 Tj / °C','闭环 Pe / W'],[[f(x.Rth_K_per_W,4),f(x.T_sink_C,0),f(x.Tj_C,4),f(x.Pout_W,5)] for _,x in thermal_sens.iterrows()],[4.3,4.3,4.3,4.3])
p('原报告的 Rth 来自 8 W、假定结温 40°C 的锚定构造。若参考结温、fret 或实际散热接触改变，仍可能在原端口曲线上得到相同拟合，却预测出不同的高功率结温与输出；一条 I–V 无法唯一选定这些热参数。')
table(['需要变化或补充的量','对预测的作用'],[
 ['Rth、Tsink、Cth','分别影响温升、边界与时间常数；阵列热负荷还可能抬升共同散热端'],
 ['βVoc(P)、αI(P)、Rs(T,P)','改变电压、电流和欧姆损失的温变；需跨功率联合辨识'],
 ['fret 与光功率参考面','改变净热源及输入归一化，不能与 ηchain 重复作用'],
 ['反向、旁路与互联支路','决定强非均匀工况的完整支持域和可能的新功率峰']
 ],[6.1,11.1])

page('24  数值验证与误差指标的分层解释')
val=load('validation/validation.json');arrchecks=array['checks'];refine=load('arrays/numerical_refinement_checks.json')
table(['检验','本次结果','含义'],[
 ['基准五参数及温度配置','与上传报告源配置逐值一致','模型迁移检查，未重新标定'],
 ['原72点 I–V NRMSE',f"{base['NRMSE_percent_Isc']:.6f}%Isc",'原工况同扫描重构误差'],
 ['独立电流求解差','约1.47×10⁻¹³ A','内节点根法对照 WrightOmega 前向求解'],
 ['光学功率预算','约10⁻¹³ W量级','积分归一化与拼缝、外逸分区一致'],
 ['固定点与热根温差','最大1.03×10⁻¹⁰ K','两种稳态求解路径一致'],
 ['阵列MPP能量残差',f"{arrchecks['max_residuals']['source_energy_residual_W']:.2e} W",'源到负载/热的计算守恒'],
 ['全部主曲线能量残差','≤1.064×10⁻⁸ W','包括2576个端口曲线点'],
 ['网格精化功率变化','≤8.37×10⁻¹⁰%','当前网格未主导本次数值输出'],
 ['四个独立网络重求解','功率差≤3.60×10⁻¹¹ W','独立内节点、热根与支路电流优化'],
 ['均匀 N 倍缩放差','≤2.27×10⁻¹⁰%','同热边界下的网络尺度自检']
 ],[5.6,5.0,6.6],9.2)
p(f"独立验证当前记录 {val['check_count']} 项检查，状态 {val['status']}。验证代码将原模型实现与独立内节点求根、圆矩形解析几何及时间域能量核对区分开。数值残差很小不能推断器件物理参数的真实误差，也不能当作跨工况实验精度。")
p('若后续有新实测曲线，应按统一电压点计算 RMSE、NRMSE=100×RMSE/Isc、MAE、最大绝对电流误差，并比较 Pmax、Vmpp、Impp、结温与阶跃时间。近零电流处不采用逐点相对百分误差。')

page('25  实验对比与模型优化路线')
table(['测量项','建议实验','校正对象 / 验证量'],[
 ['光输入参考面','同步记录 Ps、接收面功率、实际光斑及每片接收积分','ηchain、Pin 归一化、截获率与辐照 CV'],
 ['温度与稳态 I–V','至少多个功率及受控散热温度；独立测有效结温','βVoc、αI、a(T)、Rs(T)、Pmax及Tj误差'],
 ['热阻与热容','已知光功率/负载阶跃，同步电输出和温度','Rth、Cth、单/多时间常数模型'],
 ['阵列工作点','同一光场下交换行/列串接，记录各串电流及各片电压','支路失配、互联压降与热负荷分配'],
 ['强非均匀安全支路','在器件允许范围测反偏、旁路压降及温升','完整网络曲线、边界受限工况与多峰'],
 ['独立留出工况','整条未参与拟合的功率/温度/光斑工况留出','评价跨工况预测而非同曲线再拟合']
 ],[3.4,7.1,6.7])
p('优化顺序为：先锁定有效光功率和结温标度，再用多温度、多功率曲线联合拟合温度律与五参数，随后根据温度动态残差选择单热节点或多热节点，最后补足反向/旁路和实际互联模型。只有独立工况误差下降且参数可识别，才说明新增机制改善预测。')
note('可将 NRMSE≤1%Isc、Pmax相对误差≤2%、温度误差≤2 K 作为待讨论的项目目标，但需与测量不确定度匹配；本报告未宣称这些新增工况实验指标已达标。')

page('26  结论、复算资料与参考来源')
p('本研究在上传报告的联合五参数基线上，给出了单体“接收功率—参数—电输出—发热—结温—参数”的计算反馈链。一次温度修正与自洽解的差异、固定点收敛、独立热根和热 ODE 终值共同验证了该反馈在所声明方程中的实现。')
p('阵列预测表明：相同总接收功率并不保证相同电输出；串并联约束会使强照射单片偏离独立最大功率点，增加发热。在所研究空间图和主连接下，平顶非均匀工况较高斯非均匀保留更多输出，但该结论不推广到任意光斑半径、偏移、互联或散热系统。')
p('3×3、4×4、4×5、5×5 的均匀参考输出分别为 39.8723、70.8841、88.6052、110.7564 W。4×5 的方向对照说明，在同一接收矩阵下，4S5P 与5S4P可表现出显著功率差异。')
table(['配套文件','内容'],[
 ['研究报告 DOCX / PDF','完整方法、闭环计算、主热图、功率扫描、验证与实验计划'],
 ['LPV808_All_Case_Irradiance_Atlas.pdf','16页横向图册，每页8工况，128工况各出现一次'],
 ['模型包 core.py、single/、optics/、arrays/','基准配置、计算源程序、所有CSV及JSON结果'],
 ['validation/ 与 figures/','独立检查、数值精化、高清PNG和矢量PDF图'],
 ['README 与文件清单','复算顺序、依赖、参数来源及 SHA256 校验']
 ],[6.8,10.4])
p('[1] 用户上传：LPV808_6J_Integrated_Report (1).docx。SHA256：810e76e27c8b18a7b401ed2bdf4c69d7453c82b9d35093578b6025966da7e4bd。',9.5)
p('[2] 此前用户数据 LPV-808-164_261026.xlsx，样品 LPV-808-164-007；本次沿用归档的73点原始扫描与既有72点标定范围。',9.5)
p('[3] Gou Y, Wang H, Wang J, et al. Optics Express, 2022, 30(17):31509–31517. DOI:10.1364/OE.470740。温系迁移沿用[1]的来源说明，并非本次新测。',9.5)
note('所有新增图为仿真输出；未沿用原报告的片内5×5光学分区研究，也未为每个微区新增电学或热参数。')

page('附录 A  16 个主要工况数值总表')
rows=[]
for R,C in layouts:
 for pro in profiles:
  a=get(R,C,pro);c=cases[a['case_id']]
  rows.append([f'{R}×{C}',short[pro],f(a['Ps_W'],2),f(a['Pin_total_W'],0),f(a['Pmax_W'],4),f(a['efficiency_received_percent'],2),f(a['Tmax_C'],2),f(c['CV_G_percent'],2)])
table(['布局','光场 / 分布','Ps / W','Pin合计 / W','Pmax / W','η接收 / %','最高Tj / °C','CV / %'],rows,[1.6,3.4,2.0,2.2,2.5,2.0,2.0,1.5],8.6)
p('表中 Pmax 均位于已建模的正向发电支持域内部。η接收=Pmax/ΣPin×100%；源端效率则为 Pmax/Ps×100%，两者分母不同。共同散热端固定为 25°C，Rbus=0，fret=0.90。')
p('完整模型包另含平均接收 2、4、6、8 W 与源功率 40、80、120、160 W 的全部 128 光学工况、144 网络结果、2576 个主曲线端口点及 45080 行曲线逐片状态。')
note('G-均匀参照只用于比较，不能按实际无损高斯匀光器解读。附图册坐标用0起行列号，正文热图用1起行列号；二者均上排对应正y，矩阵次序一致。')

# Explicit fonts on every Word run, including fields, tables and picture runs.
for pp in doc.paragraphs:
 for r in pp.runs:font(r)
for tb in doc.tables:
 for row in tb.rows:
  for cell in row.cells:
   for pp in cell.paragraphs:
    for r in pp.runs:font(r)
doc.core_properties.title='808 nm GaAs 激光光伏电池光热电反馈与阵列输出研究'
doc.core_properties.subject='单体闭环验证；高斯和平顶；3×3、4×4、4×5、5×5；逐片辐照/电功率/结温'
doc.core_properties.author=''
name='LPV808_Feedback_Array_Research_Report.docx';path=OUT/name;doc.save(path)
manifest={'docx':str(path),'planned_pages':len(page_titles)+1,'page_titles':page_titles,'figures':fig_no,'tables':len(doc.tables),'latin_font':LAT,'chinese_font':CJK,'input_report_sha256':hashlib.sha256((ROOT/'input/source_report.docx').read_bytes()).hexdigest(),'validation_status_at_build':val['status'],'validation_checks_at_build':val['check_count'],'all_images_embedded':True}
(ROOT/'report/report_build_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(json.dumps(manifest,ensure_ascii=False))
