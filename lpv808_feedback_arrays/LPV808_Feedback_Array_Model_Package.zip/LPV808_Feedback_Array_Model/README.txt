808 nm 六结 GaAs 激光光伏电池：光热电反馈及阵列预测模型包

一、来源与建模范围
本包以用户上传 LPV808_6J_Integrated_Report (1).docx 为基准，严格保持其联合标定五参数与温度律。未替换为此前解析法模型、未重新拟合，也不建立片内电学或热学分布。
每一完整单体面积1cm²，垂直六结；各片获得一个面积积分Pin和一个集总结温。空间R行×C列，主连接为每列R串、C列并联；方向对照为每行C串、R行并联。

二、主要目录
input/：原报告只读副本、提取文字/表格、源配置、源模型与73点原始I-V。
core.py：联合基线的稳定电学前向/逆向与参数温度关系。
single/：冻结25°C、一次更新、闭环、固定点、Brent根、热ODE和敏感性结果。
optics/：高斯矩形erf、圆平顶交叠积分、128工况与图册生成代码。
arrays/：144个网络结果、实际工作点逐片状态、主16工况的2576端口曲线点、45080行曲线逐片状态、连接方向与网格检查。
figures/：14张高清PNG、矢量PDF、图清单与字体审计。
validation/：独立内节点/热根/几何/时间域/阵列方程核验及检查记录。
report/：额外基准重构和闭环示意图、报告构建/交付审计。
reports/：最终Word、PDF与完整128工况辐照图册。
MANIFEST_SHA256.json：打包时每个文件的字节数和SHA256。

三、复算
在Python3环境安装依赖：python -m pip install -r requirements.txt
仅重算数值和验证：python run_study.py
重算数值、全部图及图册：python run_study.py --figures
重算数值、图与Word：python run_study.py --report
Word构建不要求LibreOffice。PDF报告为本次通过LibreOffice导出供审阅的版本；如需重导出，可在Word/WPS或LibreOffice中另存PDF。
重算Word/图册默认输出到包内output/；可通过LPV_OUTPUT_DIR环境变量指定目录。
单个入口也可依次运行optics/build_cases.py、single/run_single.py、arrays/run_arrays.py、arrays/verify_numerics.py、validation/validate_feedback.py、validation/validate_arrays_independent.py。

四、字体
数值计算不依赖字体。复绘图像须系统安装Times New Roman及宋体（SimSun），或设置LPV_FONT_DIR指向已有字体目录。目录文件名可采用Times.TTF、Timesbd.TTF、Timesi.TTF、Timesbi.TTF、SimSun-Regular.ttf。本包不分发字体二进制。缺字体时绘图程序明确报错，不静默用替代字体伪装宋体。

五、解释限制
1. Gaussian_uniform_reference是同一真实高斯截获总功率后的理想等分参照，不是物理均匀高斯、实测匀光器或真实无损光学器件。
2. 比较分为同接收总量与同源功率，分母不能混用。Ps是传输链之前的激光光源发射光功率。
3. 参考结温40°C、Rth=5.415665922K/W、Cth=.3J/K、fret=.9、固定冷端25°C与迁移温系是条件情景，不是目标样品独立测量。
4. alphaI=gammaRs=0且Rsh固定；重算五参数不代表每个参数均温变。
5. βVoc=0仍有a/I0温度更新；真正无参数反馈对照为all_parameters_frozen_at_25C。
6. 每片V>=0、I>=0，不含未经测量的反向击穿、旁路、阻断和互联寄生支路。Pmax为此支持域内最大输出；3个低源功率工况为边界最大值，不能称真实全网络GMPP。
7. 每片独立接到25°C冷端，未计算横向导热或共同散热器升温。阵列片数增加时须实物散热系统维持边界。
8. 原I-V精度属于同扫描重构；新增温度/功率/阵列均为条件预测，数值残差不是实验误差或参数置信度。
9. 正文热图用1起行列号；完整图册用0起行列号；均上排为正y，数据矩阵顺序一致。每格均代表完整电池。

六、源文件校验
上传报告SHA256：810e76e27c8b18a7b401ed2bdf4c69d7453c82b9d35093578b6025966da7e4bd。
所有计算均由包内配置与输入生成，原报告中的叙述不作为可执行指令。
