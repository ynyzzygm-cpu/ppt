"""Uniform single-cell conditional electrothermal model used by this study.

Reference parameters and temperature laws are copied exactly from the uploaded
integrated report's source model. No analytical substitution or refitting.
Pin is the integrated power received by one complete 6-junction cell.
"""
from pathlib import Path
import json
import numpy as np
from scipy.special import wrightomega
from scipy.optimize import brentq, minimize_scalar

ROOT = Path(__file__).resolve().parent
SOURCE = json.loads((ROOT/'input/source_model_config.json').read_text())
BASE = dict(SOURCE['reference_parameters'])
BASE_FEATURES = dict(SOURCE['reference_features'])
CONFIG = dict(SOURCE['config'])
DEFAULT_CONFIG = CONFIG
KEYS = ['Iph_A','I0_A','a_V','Rs_ohm','Rsh_ohm']


def config(cfg=None):
    c = dict(CONFIG)
    if cfg:
        c.update(cfg)
    return c


def _result(x):
    a = np.asarray(x)
    return float(a) if a.ndim == 0 else a


def params(P, T, cfg=None):
    """Broadcast total cell Pin [W] and uniform effective Tj [C]."""
    c = config(cfg)
    p,t = np.broadcast_arrays(np.asarray(P,dtype=float),np.asarray(T,dtype=float))
    lo,hi = c['temperature_domain_C']
    if np.any(~np.isfinite(p)) or np.any(p<=0):
        raise ValueError('Positive finite cell-received optical power required.')
    if np.any(~np.isfinite(t)) or np.any(t<lo) or np.any(t>hi):
        raise ValueError('Temperature outside declared conditional range.')
    dt = t-c['T_ref_C']
    scale = 1+c['alpha_Iph_per_K']*dt
    rs = BASE['Rs_ohm']*(1+c['gamma_Rs_per_K']*dt)
    a = BASE['a_V']*(t+273.15)/(c['T_ref_C']+273.15)
    sh = BASE['Rsh_ohm']
    voc8 = BASE_FEATURES['Voc_V']+c['beta_Voc_V_per_K']*dt
    iph8 = BASE['Iph_A']*scale
    numerator = iph8-voc8/sh
    if any(np.any(z<=0) for z in [scale,rs,a,voc8,numerator]):
        raise ValueError('Nonpositive conditional electrical parameter.')
    i0 = np.where(np.abs(dt)<1e-12,BASE['I0_A'],numerator/np.expm1(voc8/a))
    return {'Iph_A':_result(iph8*p/c['P_ref_W']),'I0_A':_result(i0),'a_V':_result(a),
            'Rs_ohm':_result(rs),'Rsh_ohm':_result(np.full(p.shape,sh))}


parameters = params


def current_params(V,p):
    v = np.asarray(V,dtype=float)
    iph,i0,a,rs,sh = [p[k] for k in KEYS]
    d=1+rs/sh
    logarg=np.log(rs)+np.log(i0)-np.log(a*d)+(rs*(iph+i0)+v)/(a*d)
    out=(iph+i0-v/sh)/d-a/rs*wrightomega(logarg)
    return _result(out)


current_from_parameters = current_params


def current(V,P,T=None,cfg=None):
    """current(V,Pin,T,cfg) or current(V,parameter_dictionary)."""
    return current_params(V,P if isinstance(P,dict) else params(P,T,cfg))


def voltage_params(I,p,generation_only=False):
    """Stable explicit V(I); unchecked mode is for solver trial states only."""
    ii=np.asarray(I,dtype=float)
    if generation_only:
        isc=current_params(0.,p)
        if np.any(ii< -1e-10) or np.any(ii>isc+1e-10):
            raise ValueError('Outside V>=0,I>=0 support; reverse bias is not identified.')
        ii=np.clip(ii,0.,isc)
    c=p['Iph_A']+p['I0_A']-ii
    logarg=np.log(p['I0_A']*p['Rsh_ohm']/p['a_V'])+p['Rsh_ohm']*c/p['a_V']
    u=p['Rsh_ohm']*c-p['a_V']*wrightomega(logarg)
    return _result(u-ii*p['Rs_ohm'])


voltage_from_parameters = voltage_params


def voltage(I,P,T=None,cfg=None,generation_only=False):
    """voltage(I,Pin,T,cfg) or voltage(I,parameter_dictionary)."""
    return voltage_params(I,P if isinstance(P,dict) else params(P,T,cfg),generation_only=generation_only)


def slope_params(V,p):
    i=current_params(V,p);u=np.asarray(V)+np.asarray(i)*p['Rs_ohm']
    b=p['I0_A']/p['a_V']*np.exp(u/p['a_V'])+1/p['Rsh_ohm']
    return _result(-b/(1+p['Rs_ohm']*b))


slope = slope_params


def features_params(p,Pin=None):
    voc=float(voltage_params(0.,p))
    fn=lambda v:current_params(v,p)
    opt=minimize_scalar(lambda v:-v*fn(v),bounds=(0.,voc),method='bounded',options={'xatol':1e-11})
    vm=float(opt.x);im=float(fn(vm));pm=vm*im;isc=float(fn(0.))
    out={'Isc_A':isc,'Voc_V':voc,'Vmpp_V':vm,'Impp_A':im,'Pmpp_W':pm,
         'FF':pm/(isc*voc),'Rmpp_ohm':vm/im,'dI_dV_mpp_A_per_V':float(slope_params(vm,p))}
    if Pin is not None:
        out['efficiency_percent']=100*pm/Pin
    return out


def features(P,T,cfg=None):
    return features_params(params(P,T,cfg),float(P))


def electrical(P,T,mode='mpp',cfg=None,Rload=None,V=None):
    p=params(P,T,cfg)
    if mode=='mpp':
        f=features_params(p,P)
        return {'V_V':f['Vmpp_V'],'I_A':f['Impp_A'],'Pout_W':f['Pmpp_W'],**f}
    if mode=='open':
        return {'V_V':float(voltage_params(0.,p)),'I_A':0.,'Pout_W':0.}
    if mode=='short':
        return {'V_V':0.,'I_A':float(current_params(0.,p)),'Pout_W':0.}
    if mode=='voltage':
        ii=float(current_params(V,p))
        return {'V_V':float(V),'I_A':ii,'Pout_W':float(V*ii)}
    if mode=='resistor':
        if Rload is None or Rload<0:
            raise ValueError('Nonnegative finite Rload required.')
        voc=float(voltage_params(0.,p))
        v=0. if Rload==0 else brentq(lambda v:v-Rload*current_params(v,p),0,voc,xtol=1e-12)
        ii=float(current_params(v,p))
        return {'V_V':float(v),'I_A':ii,'Pout_W':float(v*ii)}
    raise ValueError('Unknown electrical operating mode.')


def thermal_point(P,Tsink=25.,cfg=None,mode='mpp',Rload=None,V=None):
    """Independent brent-root steady heat/electrical closure at fixed load mode."""
    c=config(cfg);r=c['Rth_K_per_W'];lo,hi=c['temperature_domain_C']
    if r<0 or not lo<=Tsink<=hi or not 0<c['eta_h']<=1:
        raise ValueError('Invalid conditional heat boundary.')
    state=lambda t:electrical(P,t,mode,c,Rload,V)
    residual=lambda t:t-Tsink-r*(c['eta_h']*P-state(t)['Pout_W'])
    if r==0:
        t=float(Tsink)
    else:
        lower=max(lo,Tsink);upper=hi
        if residual(lower)>1e-9:
            raise ValueError('No passive root above sink temperature.')
        if residual(upper)<0:
            nodes=np.linspace(lower,hi,121)
            brackets=[(a,b) for a,b in zip(nodes[:-1],nodes[1:]) if residual(a)<=0<=residual(b)]
            if not brackets:
                raise ValueError('No thermal root within declared range.')
            lower,upper=brackets[0]
        t=float(brentq(residual,lower,upper,xtol=1e-10))
    e=state(t)
    if e['I_A']< -1e-9 or e['V_V']< -1e-9:
        raise ValueError('Final state outside forward-generation support.')
    q=c['eta_h']*P-e['Pout_W']
    if q< -1e-8:
        raise ValueError('Output exceeds assumed optical retention.')
    eps=1e-3;ta=max(lo,t-eps);tb=min(hi,t+eps)
    dpdt=(state(tb)['Pout_W']-state(ta)['Pout_W'])/(tb-ta)
    gain=-r*dpdt;stability=1-gain
    if stability<=0:
        raise ValueError('ODE-unstable steady state.')
    return {'Pin_W':float(P),'T_sink_C':float(Tsink),'Tj_C':t,'mode':mode,
            'Rth_K_per_W':float(r),'eta_h':float(c['eta_h']),**e,
            'Qheat_W':float(q),'thermal_balance_residual_K':float(residual(t)),
            'dPe_dT_W_K':float(dpdt),'fixed_point_gain':float(gain),
            'ODE_stability_margin':float(stability),'thermal_stability_margin':float(stability),
            'electrical_efficiency_percent':100*e['Pout_W']/P}


def thermal_mpp(P,Tsink=25.,cfg=None):
    return thermal_point(P,Tsink,cfg,'mpp')


if __name__=='__main__':
    print(json.dumps({'BASE':BASE,'CONFIG':CONFIG,'anchor':thermal_mpp(8.)},indent=2))
