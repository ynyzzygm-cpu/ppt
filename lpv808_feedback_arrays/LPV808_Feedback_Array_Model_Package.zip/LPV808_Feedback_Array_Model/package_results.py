"""Package final reports, numerical model and saved results without font binaries."""
from pathlib import Path
import os,json,hashlib,shutil,zipfile
import fitz
ROOT=Path(__file__).resolve().parent
OUT=Path(os.environ.get('LPV_OUTPUT_DIR','/workspace/output' if Path('/workspace/output').exists() else str(ROOT/'output')))
STAGE=ROOT/'package_stage/LPV808_Feedback_Array_Model'
if STAGE.exists():shutil.rmtree(STAGE)
STAGE.mkdir(parents=True)
top=['core.py','study_contract.json','plot_figures.py','build_report.py','run_study.py','package_results.py','README.txt','requirements.txt']
for name in top:shutil.copy2(ROOT/name,STAGE/name)
for folder in ['input','single','optics','arrays','validation','figures','review']:
 for p in (ROOT/folder).rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(ROOT)
  if any(part in ['__pycache__','mplconfig','.mpl_cache','font_cache'] for part in rel.parts):continue
  if p.suffix.lower() in ['.ttf','.ttc','.otf','.pyc']:continue
  if folder=='optics' and 'atlas' in rel.parts and p.name!='atlas_manifest.json':continue
  if p.name=='run_progress.json':continue
  target=STAGE/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
for name in ['extra_figures.py','baseline_metrics.json','report_build_manifest.json','delivery_audit.json']:
 p=ROOT/'report'/name
 if p.exists():
  target=STAGE/'report'/name;target.parent.mkdir(exist_ok=True);shutil.copy2(p,target)
for p in (ROOT/'report/extra_figures').glob('*'):
 if p.is_file():
  target=STAGE/'report/extra_figures'/p.name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
reports=['LPV808_Feedback_Array_Research_Report.docx','LPV808_Feedback_Array_Research_Report.pdf','LPV808_All_Case_Irradiance_Atlas.pdf']
for name in reports:
 target=STAGE/'reports'/name;target.parent.mkdir(exist_ok=True);shutil.copy2(OUT/name,target)
validation=json.loads((STAGE/'validation/validation.json').read_text())
assert validation['status']=='passed' and 'arrays' in validation['sections']
assert all(x['passed'] for x in validation['checks'])
with fitz.open(OUT/reports[1]) as p:assert len(p)>=12
manifest=[]
for p in sorted(STAGE.rglob('*')):
 if p.is_file():
  data=p.read_bytes();manifest.append({'path':str(p.relative_to(STAGE)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(STAGE/'MANIFEST_SHA256.json').write_text(json.dumps({'files':manifest,'validation_checks':validation['check_count'],'note':'Font binaries are not distributed; all checksums refer to the supplied copies.'},ensure_ascii=False,indent=2))
archive=OUT/'LPV808_Feedback_Array_Model_Package.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(STAGE.rglob('*')):
  if p.is_file():z.write(p,'LPV808_Feedback_Array_Model/'+str(p.relative_to(STAGE)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for item in manifest:
  d=z.read('LPV808_Feedback_Array_Model/'+item['path'])
  assert hashlib.sha256(d).hexdigest()==item['sha256']
summary={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(manifest)+1,'CRC_and_SHA256_passed':True}
(ROOT/'report/package_verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False))
