"""Independent implicit-diode, thermal-root and KCL/KVL array verification."""
from pathlib import Path
import json,math,sys
import numpy as np
from scipy.optimize import brentq,minimize_scalar
from validate_feedback import independent_parameters,iu,CFG,ROOT,feature_ref

OUT=Path(__file__).resolve().parent
data=json.loads((ROOT/'arrays/results.json').read_text())
optics={c['case_id']:c for c in json.loads((ROOT/'optics/cases.json').read_text())['cases']}
checks=[]
def ck(name,value,tol,unit=''):
 checks.append({'check':name,'value':float(value),'tolerance':tol,'units':unit,'passed':bool(abs(value)<=tol)})
def rq(name,condition):checks.append({'check':name,'passed':bool(condition)})

worst={k:0. for k in ['implicit_current_A','thermal_K','KVL_V','KCL_A','source_budget_W','MPP_upper_bound_W']}
for a in data['results']:
 cells=a['cells'];case=optics[a['case_id']];ts=a['Tsink_C'];rth=a['Rth_each_K_per_W'];eta=a['eta_h']
 power=heat=0.;independent_sum=0.
 for c in cells:
  p=independent_parameters(c['Pin_W'],c['Tj_C'])
  residual=iu(c['Vcell_V']+c['Icell_A']*p['Rs_ohm'],p)-c['Icell_A']
  worst['implicit_current_A']=max(worst['implicit_current_A'],abs(residual))
  worst['thermal_K']=max(worst['thermal_K'],abs(c['Tj_C']-ts-rth*(eta*c['Pin_W']-c['Vcell_V']*c['Icell_A'])))
  rq(a['case_id']+f" cell{c['cell']} positive generation",c['Vcell_V']>=-1e-8 and c['Icell_A']>=-1e-10)
  power+=c['Vcell_V']*c['Icell_A'];heat+=eta*c['Pin_W']-c['Vcell_V']*c['Icell_A']
  independent_sum+=c['independent_cell_mpp_W']
 for group in a['groups_1based']:
  g=[cells[j-1] for j in group]
  worst['KVL_V']=max(worst['KVL_V'],abs(sum(c['Vcell_V'] for c in g)-a['Vport_V']))
  worst['KCL_A']=max(worst['KCL_A'],max(c['Icell_A'] for c in g)-min(c['Icell_A'] for c in g))
 total_i=sum(cells[g[0]-1]['Icell_A'] for g in a['groups_1based'])
 worst['KCL_A']=max(worst['KCL_A'],abs(total_i-a['Iport_A']))
 budget=case['Ps_W']-case['chain_loss_W']-case['gap_loss_W']-case['outside_loss_W']-(1-eta)*case['totalPin_W']-heat-a['Pmax_W']
 worst['source_budget_W']=max(worst['source_budget_W'],abs(budget))
 worst['MPP_upper_bound_W']=max(worst['MPP_upper_bound_W'],a['Pmax_W']-independent_sum)
 ck(a['case_id']+' actual-cell port power',power-a['Pmax_W'],3e-8,'W')
 rq(a['case_id']+' support flag retained',not a['claimed_full_network_GMPP'])
 if a['uniform']:
  ck(a['case_id']+' uniform N-times scaling',a['Pmax_W']-a['N']*cells[0]['independent_cell_mpp_W'],3e-7,'W')
for k,tol in [('implicit_current_A',1e-8),('thermal_K',1e-8),('KVL_V',1e-7),('KCL_A',1e-9),('source_budget_W',1e-7),('MPP_upper_bound_W',1e-7)]:ck('All arrays '+k,worst[k],tol)

# Direct scalar inner-potential and heat roots; no production current, voltage,
# interpolation or network implementation is imported.
def state_at_i(i,pin):
 hot=25+CFG['Rth_K_per_W']*CFG['eta_h']*pin
 def voltage(t):
  p=independent_parameters(pin,t)
  u=brentq(lambda u:iu(u,p)-i,-2,15,xtol=2e-12)
  return u-i*p['Rs_ohm']
 def residual(t):return t-25-CFG['Rth_K_per_W']*(CFG['eta_h']*pin-i*voltage(t))
 t=hot if abs(i)<1e-14 else brentq(residual,25,hot+1e-9,xtol=2e-10)
 return voltage(t),t

representatives=[
 ('R3C3_TopHat_uniform_received_mean_8','primary'),
 ('R5C5_Gaussian_nonuniform_received_mean_8','primary'),
 ('R4C5_TopHat_nonuniform_received_mean_8','secondary'),
 ('R5C5_Gaussian_nonuniform_source_Ps_40','primary')]
reference=[]
for case_id,connection in representatives:
 a=next(x for x in data['results'] if x['case_id']==case_id and x['connection']==connection)
 pins=np.array(optics[case_id]['powers']);groups=[[j-1 for j in g] for g in a['groups_1based']]
 isc=[]
 for pin in pins:
  ph=independent_parameters(pin,25+CFG['Rth_K_per_W']*CFG['eta_h']*pin)
  u=brentq(lambda u:u-ph['Rs_ohm']*iu(u,ph),0,15,xtol=1e-13);isc.append(iu(u,ph))
 imax=[min(isc[j] for j in g) for g in groups]
 def sv(g,i):return sum(state_at_i(i,pins[j])[0] for j in g)
 vlow=max(sv(g,i) for g,i in zip(groups,imax));vhigh=min(sv(g,0.) for g in groups)
 def net(v):
  currents=[]
  for g,high in zip(groups,imax):
   lowv=sv(g,high);hiv=sv(g,0.)
   if abs(v-lowv)<2e-8:i=high
   elif abs(v-hiv)<2e-8:i=0.
   else:i=brentq(lambda i:sv(g,i)-v,0,high,xtol=3e-12)
   currents.append(i)
  return v*sum(currents)
 vg=np.linspace(vlow,vhigh,61);pp=np.array([net(v) for v in vg]);candidates=[(pp[0],vg[0]),(pp[-1],vg[-1])]
 for k in np.where((pp[1:-1]>=pp[:-2])&(pp[1:-1]>=pp[2:]))[0]+1:
  sol=minimize_scalar(lambda v:-net(v),bounds=(vg[k-1],vg[k+1]),method='bounded',options={'xatol':2e-8})
  candidates.append((-sol.fun,sol.x))
 pm,vm=max(candidates)
 error=pm-a['Pmax_W'];ck(case_id+connection+' independent implicit/root maximum',error,2e-6,'W')
 reference.append({'case_id':case_id,'connection':connection,'production_Pmax_W':a['Pmax_W'],'independent_Pmax_W':pm,'difference_W':error,'independent_Vmax_V':vm,'independent_support_V':[vlow,vhigh]})

result={'status':'passed' if all(c['passed'] for c in checks) else 'failed','check_count':len(checks),'checks':checks,'maxima':worst,'independent_network_maxima':reference,'scope':'All 144 exported operating points checked against independent equations; four representative network maxima independently re-solved with scalar inner-potential/heat/current roots.'}
(OUT/'array_independent_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
base=json.loads((OUT/'validation.json').read_text())
base['sections']['arrays']= {k:v for k,v in result.items() if k!='checks'}
base['checks']=[x for x in base['checks'] if not x.get('array_validation_root_added',False)]
base['checks'].extend([{**x,'array_validation_root_added':True} for x in checks])
base['check_count']=len(base['checks']);base['status']='passed' if all(x['passed'] for x in base['checks']) else 'failed'
(OUT/'validation.json').write_text(json.dumps(base,ensure_ascii=False,indent=2))
(OUT/'summary.md').write_text('独立数值验证：'+base['status']+'\n\n'+str(base['check_count'])+' 项检查；含core、optics、single、arrays。\n\n只评价方程实现、守恒和声明支持域，不构成新工况实验精度验证。\n\n'+json.dumps(base['sections'],ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False))
if result['status']!='passed':raise SystemExit(1)
