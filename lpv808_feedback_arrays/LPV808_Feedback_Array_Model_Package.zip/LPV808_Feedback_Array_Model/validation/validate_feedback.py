"""Independent numerical, optical and network audit of conditional feedback arrays.

No parameter refitting. Reference currents use internal-node Brent roots rather
than the production Lambert/WrightOmega forward implementation.
"""
from pathlib import Path
import json,math,sys,importlib.util
import numpy as np
import pandas as pd
from scipy.optimize import brentq
from scipy.integrate import quad
from scipy.integrate import solve_ivp, simpson

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'validation'
SOURCE=json.loads((ROOT/'input/source_model_config.json').read_text())
CONTRACT=json.loads((ROOT/'study_contract.json').read_text())
BASE=SOURCE['reference_parameters'];CFG=SOURCE['config'];BASEF=SOURCE['reference_features']
checks=[]

def ck(name,value,tol=1e-7,units=''):
    checks.append({'check':name,'value':float(value),'tolerance':float(tol),'units':units,
                   'passed':bool(np.isfinite(value) and abs(value)<=tol)})

def req(name,condition,note=''):
    checks.append({'check':name,'passed':bool(condition),'note':note})

def independent_parameters(P,T,cfg=None):
    c=dict(CFG);c.update(cfg or {})
    dt=T-c['T_ref_C'];a=BASE['a_V']*(T+273.15)/(c['T_ref_C']+273.15)
    iph8=BASE['Iph_A']*(1+c['alpha_Iph_per_K']*dt)
    rs=BASE['Rs_ohm']*(1+c['gamma_Rs_per_K']*dt)
    vo=BASEF['Voc_V']+c['beta_Voc_V_per_K']*dt
    i0=BASE['I0_A'] if abs(dt)<1e-12 else (iph8-vo/BASE['Rsh_ohm'])/math.expm1(vo/a)
    return {'Iph_A':iph8*P/c['P_ref_W'],'I0_A':i0,'a_V':a,'Rs_ohm':rs,'Rsh_ohm':BASE['Rsh_ohm']}

def iu(U,p):
    exponent=math.log(p['I0_A'])+U/p['a_V']
    ex=math.exp(exponent) if exponent<700 else math.inf
    return p['Iph_A']-ex+p['I0_A']-U/p['Rsh_ohm']

def vu(U,p):return U-p['Rs_ohm']*iu(U,p)

def current_ref(V,p):
    u=brentq(lambda u:vu(u,p)-V,-1,max(15,V+2),xtol=1e-13)
    return float(iu(u,p))

def feature_ref(p):
    uoc=brentq(lambda u:iu(u,p),0,15,xtol=1e-13)
    usc=brentq(lambda u:vu(u,p),0,uoc,xtol=1e-13)
    def dpdu(u):
        i=iu(u,p);v=vu(u,p)
        di=-math.exp(math.log(p['I0_A'])+u/p['a_V'])/p['a_V']-1/p['Rsh_ohm']
        return i*(1-p['Rs_ohm']*di)+v*di
    um=brentq(dpdu,usc,uoc,xtol=1e-13)
    v=vu(um,p);i=iu(um,p);isc=iu(usc,p)
    return {'Isc_A':isc,'Voc_V':uoc,'Vmpp_V':v,'Impp_A':i,'Pmpp_W':v*i,
            'FF':v*i/(isc*uoc),'Rmpp_ohm':v/i}

def independent_thermal_mpp(P,Ts=25,cfg=None):
    c=dict(CFG);c.update(cfg or {});r=c['Rth_K_per_W']
    def residual(T):return T-Ts-r*(c['eta_h']*P-feature_ref(independent_parameters(P,T,c))['Pmpp_W'])
    T=Ts if r==0 else brentq(residual,Ts,c['temperature_domain_C'][1],xtol=1e-10)
    f=feature_ref(independent_parameters(P,T,c))
    return {'Pin_W':P,'Tj_C':T,'Qheat_W':c['eta_h']*P-f['Pmpp_W'],**f}

def load_core():
    spec=importlib.util.spec_from_file_location('feedback_core_validation_target',ROOT/'core.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def verify_core():
    m=load_core()
    for key in BASE:
        ck('Joint baseline exactly preserved '+key,0 if BASE[key]==m.BASE[key]==CONTRACT['baseline_parameters'][key] else 1,0)
    ck('Reference Rth matches uploaded joint report',m.CONFIG['Rth_K_per_W']-5.415665922079534,1e-14,'K/W')
    ck('Reference Rth from conditional 15K anchor',m.CONFIG['Rth_K_per_W']-15/(.9*8-BASEF['Pmpp_W']),1e-12,'K/W')
    max_i=max_kcl=max_par=max_feat=0.
    for P in [1.,2.,4.,8.,12.,16.]:
        for T in [15.,25.,40.,60.,80.]:
            p=independent_parameters(P,T);pr=m.params(P,T)
            max_par=max(max_par,max(abs((p[k]-pr[k])/p[k]) for k in p))
            f=feature_ref(p);fr=m.features(P,T)
            max_feat=max(max_feat,max(abs(f[k]-fr[k]) for k in f))
            vv=np.linspace(0,f['Voc_V'],9);target=np.asarray(m.current(vv,P,T))
            for v,it in zip(vv,target):
                ir=current_ref(v,p);max_i=max(max_i,abs(ir-it))
                u=v+it*p['Rs_ohm'];max_kcl=max(max_kcl,abs(iu(u,p)-it))
            # Inverse generation-domain voltages are checked by an independent forward residual.
            ii=np.linspace(0,f['Isc_A'],7);vinv=m.voltage(ii,P,T,generation_only=True)
            for i,v in zip(ii,vinv):ck(f'Inverse diode P{P:g} T{T:g} I{i:.3g}',current_ref(float(v),p)-i,3e-10,'A')
            photon_bound=1.602176634e-19*P/(6*(6.62607015e-34*299792458./808e-9))
            req(f'Photon current budget P{P:g} T{T:g}',f['Isc_A']<photon_bound)
    ck('Independent temperature/power parameters relative maximum',max_par,1e-11,'relative')
    ck('Independent current vs vectorized core maximum',max_i,3e-11,'A')
    ck('Implicit equation maximum',max_kcl,3e-11,'A')
    ck('Independent features maximum difference',max_feat,3e-6,'mixed feature units')
    for T in [15,25,40,60,80]:
        expected=BASEF['Voc_V']+CFG['beta_Voc_V_per_K']*(T-40)
        ck(f'Total-device Voc temperature transfer {T}C',m.features(8,T)['Voc_V']-expected,2e-9,'V')
    anchor=independent_thermal_mpp(8)
    ck('Steady reference anchor Tj',anchor['Tj_C']-40,2e-8,'K')
    ck('Steady reference anchor electrical P',anchor['Pmpp_W']-BASEF['Pmpp_W'],2e-8,'W')
    for P in [2,4,8,12,16]:
        for Ts in [15,25,40]:
            ref=independent_thermal_mpp(P,Ts);target=m.thermal_mpp(P,Ts)
            ck(f'Single independent steady T P{P} Ts{Ts}',ref['Tj_C']-target['Tj_C'],2e-7,'K')
            ck(f'Single independent steady P P{P} Ts{Ts}',ref['Pmpp_W']-target['Pout_W'],2e-7,'W')
            ck(f'Single root heat balance P{P} Ts{Ts}',target['Tj_C']-Ts-CFG['Rth_K_per_W']*(CFG['eta_h']*P-target['Pout_W']),2e-7,'K')
            req(f'Single positive stability P{P} Ts{Ts}',target['ODE_stability_margin']>0)
    return {'status':'passed','independent_reference_anchor':anchor,'max_current_difference_A':max_i,'max_KCL_A':max_kcl,
            'max_relative_parameter_difference':max_par,'max_feature_difference':max_feat}


def geometry_ref(R,C,side=10.,gap=.3):
    Lx=C*side+(C-1)*gap;Ly=R*side+(R-1)*gap
    cells=[]
    for r in range(R):
        for c in range(C):
            x=(c-(C-1)/2)*(side+gap);y=((R-1)/2-r)*(side+gap)
            cells.append((x-side/2,x+side/2,y-side/2,y+side/2))
    return cells,(-Lx/2,Lx/2,-Ly/2,Ly/2)

def gaussian_fraction_ref(bounds,w,offset):
    x0,x1,y0,y1=bounds;cx,cy=offset
    normal=2/(math.pi*w*w)
    def line(x):
        return quad(lambda y:normal*math.exp(-2*((x-cx)**2+(y-cy)**2)/(w*w)),y0,y1,epsabs=1e-13,epsrel=2e-12)[0]
    return quad(line,x0,x1,epsabs=1e-13,epsrel=2e-12)[0]

def disk_rectangle_ref(bounds,radius,offset):
    # Closed-form signed quadrant primitive, independent of production strip quadrature.
    cx,cy=offset;x0,x1,y0,y1=bounds;r=float(radius)
    def primitive(x,y):
        sign=(-1 if x<0 else 1)*(-1 if y<0 else 1)
        a=min(abs(x),r);b=min(abs(y),r)
        if a*a+b*b<=r*r:return sign*a*b
        cut=math.sqrt(max(0.,r*r-b*b))
        def F(t):return .5*(t*math.sqrt(max(0.,r*r-t*t))+r*r*math.asin(min(1.,max(-1.,t/r))))
        area=b*cut+F(a)-F(cut)
        return sign*area
    area=primitive(x1-cx,y1-cy)-primitive(x0-cx,y1-cy)-primitive(x1-cx,y0-cy)+primitive(x0-cx,y0-cy)
    return max(0.,area)/(math.pi*r*r)

def verify_optics():
    path=ROOT/'optics/cases.json'
    if not path.exists():return {'status':'pending'}
    data=json.loads(path.read_text());cases=data['cases']
    spec=importlib.util.spec_from_file_location('feedback_optics_validation_target',ROOT/'optics/optics.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    req('Optical case count128',len(cases)==128)
    req('Optical representative case count16',sum(c['is_main_case'] for c in cases)==16)
    cache={};worst=0.;reference_rows=[]
    for case in cases:
        R,C=case['R'],case['C'];beam=case['beam'];uniform=case['uniform']
        key=(R,C,beam,uniform)
        if key not in cache:
            boxes,frame=geometry_ref(R,C);Lx=frame[1]-frame[0];Ly=frame[3]-frame[2]
            radius=(1.02*.5*math.hypot(Lx,Ly) if uniform else .6*math.sqrt(Lx*Ly)) if beam=='TopHat' else .6*math.sqrt(Lx*Ly)
            offset=(0.,0.) if beam=='TopHat' and uniform else (.1*Lx,.07*Ly)
            fn=gaussian_fraction_ref if beam=='Gaussian' else disk_rectangle_ref
            fr=np.array([fn(b,radius,offset) for b in boxes]);framefr=fn(frame,radius,offset)
            cache[key]=(fr,framefr)
            ck(str(key)+' radius rule',radius-case['radius_mm'],1e-12,'mm')
            ck(str(key)+' offset rule',max(abs(np.array(offset)-case['offset_mm'])),1e-12,'mm')
        fr,framefr=cache[key];active=float(sum(fr));eta=case['eta_chain'];ps=case['Ps_W'];pbeam=eta*ps
        expected=fr*pbeam
        if beam=='Gaussian' and uniform:expected=np.full(R*C,sum(expected)/(R*C))
        pins=np.asarray(case['powers']);err=max(abs(pins-expected));worst=max(worst,err)
        ck(case['id']+' independent area-integrated cell power',err,1e-9,'W')
        ck(case['id']+' source/beam distinction',case['Pbeam_W']-pbeam,1e-10,'W')
        ck(case['id']+' independent gap power',case['gap_loss_W']-pbeam*(framefr-active),1e-9,'W')
        ck(case['id']+' independent outside power',case['outside_loss_W']-pbeam*(1-framefr),1e-9,'W')
        ck(case['id']+' full source budget',ps-case['chain_loss_W']-case['gap_loss_W']-case['outside_loss_W']-sum(pins),1e-9,'W')
        ck(case['id']+' received mean',case['meanPin_W']-float(np.mean(pins)),1e-12,'W')
        ck(case['id']+' CV',case['CV_G']-float(np.std(pins)/np.mean(pins)),1e-12)
        if case['policy']=='received_fixed':
            ck(case['id']+' equal received total policy',sum(pins)-R*C*case['target_meanPin_W'],1e-9,'W')
        else:ck(case['id']+' source-fixed target',ps-case['target_Ps_W'],1e-12,'W')
        if uniform:ck(case['id']+' equal-area uniform input',max(pins)-min(pins),1e-10,'W')
        reference_rows.append({'case_id':case['id'],'max_cell_power_difference_W':err,'independent_capture_fraction':active,'independent_frame_fraction':framefr})
    # New deterministic random rectangles: direct Gaussian quadrature and closed-form disk geometry.
    rng=np.random.default_rng(8080328);random_max_g=random_max_t=0.
    for k in range(24):
        center=rng.uniform(-25,25,2);sizes=rng.uniform(1,20,2)
        b=(center[0]-sizes[0]/2,center[0]+sizes[0]/2,center[1]-sizes[1]/2,center[1]+sizes[1]/2)
        rad=float(rng.uniform(5,40));off=tuple(rng.uniform(-10,10,2))
        ge=abs(gaussian_fraction_ref(b,rad,off)-m.gaussian_rectangle(b,rad,off)['fraction'])
        te=abs(disk_rectangle_ref(b,rad,off)-m.circle_rectangle(b,rad,off)['fraction'])
        random_max_g=max(random_max_g,ge);random_max_t=max(random_max_t,te)
        ck(f'Random rectangle{k} Gaussian independent integral',ge,2e-11,'fraction')
        ck(f'Random rectangle{k} TopHat analytic disk intersection',te,2e-10,'fraction')
    for R,C in CONTRACT['layouts']:
        for beam in ['Gaussian','TopHat']:
            for unif in [False,True]:
                a=m.beam_cell_powers(R,C,beam,unif,'source_fixed',Ps_W=40)
                b=m.beam_cell_powers(R,C,beam,unif,'source_fixed',Ps_W=160)
                ck(f'{R}x{C} {beam} {unif} source scaling',max(abs(np.asarray(b['powers'])-4*np.asarray(a['powers']))),1e-10,'W')
    pd.DataFrame(reference_rows).to_csv(OUT/'independent_optics_cases.csv',index=False)
    return {'status':'passed','cases_checked':len(cases),'max_independent_cell_power_difference_W':worst,
            'random_rectangle_count':24,'random_Gaussian_fraction_error':random_max_g,'random_TopHat_fraction_error':random_max_t,
            'TopHat_reference':'Closed-form signed disk-quadrant intersection, independent of strip quadrature.'}

def verify_single():
    folder=ROOT/'single'
    if not (folder/'thermal_ODE_steps.csv').exists():return {'status':'pending'}
    stages=pd.read_csv(folder/'freeze_onepass_converged.csv')
    iterations=pd.read_csv(folder/'fixedpoint_iterations.csv')
    feedback=pd.read_csv(folder/'feedback_summary.csv')
    max_pe=0.
    for _,row in stages.iterrows():
        p=independent_parameters(row.Pin_W,row.Tj_C);f=feature_ref(p)
        max_pe=max(max_pe,abs(f['Pmpp_W']-row.Pout_W))
        for key in BASE:ck(f'Single {row.model_stage} P{row.Pin_W:g} '+key,(row[key]-p[key])/p[key],2e-11,'relative')
        ck(f'Single {row.model_stage} P{row.Pin_W:g} heat source',row.Qheat_W-CFG['eta_h']*row.Pin_W+row.Pout_W,1e-10,'W')
        ck(f'Single {row.model_stage} P{row.Pin_W:g} next-temperature definition',row.T_next_C-25-CFG['Rth_K_per_W']*row.Qheat_W,1e-9,'K')
        if row.model_stage=='freeze_T25':ck('Freeze remains at sink',row.Tj_C-25,1e-12,'K')
        elif row.model_stage=='one_pass':
            f0=feature_ref(independent_parameters(row.Pin_W,25))
            ck(f'Single P{row.Pin_W:g} genuine one-pass temperature',row.Tj_C-25-CFG['Rth_K_per_W']*(CFG['eta_h']*row.Pin_W-f0['Pmpp_W']),1e-8,'K')
        else:ck(f'Single {row.model_stage} P{row.Pin_W:g} steady heat closure',row.Tj_C-25-CFG['Rth_K_per_W']*row.Qheat_W,2e-7,'K')
    ck('Single staged MPP independent maximum',max_pe,1e-8,'W')
    for power,grp in iterations.groupby('Pin_W'):
        grp=grp.sort_values('iteration')
        req(f'Fixed-point P{power:g} initial temperature25',abs(grp.iloc[0].Tj_C-25)<1e-12)
        ck(f'Fixed-point P{power:g} successive state linkage',max(abs(grp.Tj_C.to_numpy()[1:]-grp.T_next_C.to_numpy()[:-1])),1e-10,'K')
        for _,row in grp.iterrows():
            f=feature_ref(independent_parameters(power,row.Tj_C))
            ck(f'Fixed-point P{power:g} iteration{row.iteration:g} actual instantaneous electrical power',row.Pout_W-f['Pmpp_W'],1e-8,'W')
    for _,row in feedback.iterrows():
        ref=independent_thermal_mpp(row.Pin_W)
        ck(f'Feedback P{row.Pin_W:g} closed loop independent temperature',row.closed_loop_Tj_C-ref['Tj_C'],2e-7,'K')
        ck(f'Feedback P{row.Pin_W:g} closed loop independent output',row.closed_loop_Pout_W-ref['Pmpp_W'],2e-7,'W')
        req(f'Feedback P{row.Pin_W:g} nonzero one-pass heat residual',abs(row.one_pass_residual_K)>1e-4)
    steps=pd.read_csv(folder/'thermal_ODE_steps.csv');summary=pd.read_csv(folder/'thermal_ODE_summary.csv')
    energy=pd.read_csv(folder/'thermal_ODE_energy.csv');ode_cases=[]
    for _,info in summary.iterrows():
        P0,P1,ts,end=info.initial_Pin_W,info.final_Pin_W,info.step_time_s,info.end_time_s
        Cth=info.Cth_J_per_K;Rth=CFG['Rth_K_per_W'];T0=independent_thermal_mpp(P0)['Tj_C']
        ck(info['case']+' scenario heat capacity',Cth-CONTRACT['Cth_J_K'],0,'J/K')
        def rhs(t,T):
            pe=feature_ref(independent_parameters(P1,float(T[0])))['Pmpp_W']
            return [(CFG['eta_h']*P1-pe-(T[0]-25)/Rth)/Cth]
        sol=solve_ivp(rhs,(ts,end),[T0],rtol=2e-11,atol=2e-12,dense_output=True,max_step=.05)
        req(info['case']+' independent ODE integration successful',sol.success)
        rows=steps[steps['case']==info['case']]
        max_t=max_power=max_rhs=max_energy=0.
        for _,row in rows.iterrows():
            t=row.t_s;treference=T0 if row.segment=='pre' else float(sol.sol(t)[0])
            max_t=max(max_t,abs(row.Tj_C-treference))
            pe=feature_ref(independent_parameters(row.Pin_W,row.Tj_C))['Pmpp_W']
            max_power=max(max_power,abs(pe-row.Pout_W))
            qloss=(row.Tj_C-row.T_sink_C)/row.Rth_K_per_W
            rhsw=CFG['eta_h']*row.Pin_W-pe-qloss
            max_rhs=max(max_rhs,abs(Cth*row.dTdt_K_per_s-rhsw))
            max_energy=max(max_energy,abs(row.Qheat_W+row.Pout_W-CFG['eta_h']*row.Pin_W),abs(row.Qloss_W-qloss))
        ck(info['case']+' saved T vs independent dynamic ODE maximum',max_t,2e-6,'K')
        ck(info['case']+' electrical power evaluated at instantaneous T',max_power,2e-8,'W')
        ck(info['case']+' instantaneous Cth*dTdt balance',max_rhs,3e-8,'W')
        ck(info['case']+' heat component definitions',max_energy,1e-9,'W')
        # Separate integration of the independent dense trajectory's energy terms.
        eopt=CFG['eta_h']*P1*(end-ts)
        ee=quad(lambda t:feature_ref(independent_parameters(P1,float(sol.sol(t)[0])))['Pmpp_W'],ts,end,epsabs=1e-9,epsrel=1e-11)[0]
        eloss=quad(lambda t:(float(sol.sol(t)[0])-25)/Rth,ts,end,epsabs=1e-9,epsrel=1e-11)[0]
        estore=Cth*(float(sol.y[0,-1])-T0)
        ck(info['case']+' independent integrated optical-electric-thermal energy',eopt-ee-eloss-estore,3e-8,'J')
        erow=energy[(energy['case']==info['case'])&(energy.segment=='post')].iloc[0]
        ck(info['case']+' exported electrical energy vs independent trajectory',erow.electrical_output_energy_J-ee,3e-6,'J')
        ck(info['case']+' exported sink energy vs independent trajectory',erow.convective_loss_energy_J-eloss,3e-6,'J')
        first=rows[(rows.segment=='post')&(abs(rows.t_s-ts)<1e-10)].iloc[0]
        ck(info['case']+' continuous temperature at optical step',first.Tj_C-T0,2e-7,'K')
        req(info['case']+' dynamic heating retained after step',first.dTdt_K_per_s>1)
        ode_cases.append({'case':info['case'],'max_temperature_difference_K':max_t,'instantaneous_power_max_difference_W':max_power,
            'independent_integrated_energy_residual_J':eopt-ee-eloss-estore,'independent_end_Tj_C':float(sol.y[0,-1])})
    return {'status':'passed','staged_rows':len(stages),'fixed_point_iteration_rows':len(iterations),'ODE_saved_rows':len(steps),
            'independent_ODE_cases':ode_cases,'dynamic_interpretation':'Instantaneous electrical MPP at T(t) coupled to thermal ODE; no inner steady-temperature solve.'}


def write_result(sections):
    result={'status':'passed' if all(c['passed'] for c in checks) else 'failed','check_count':len(checks),
        'checks':checks,'sections':sections,
        'scope':'Independent implementation, conservation, supported-domain and scenario audit; not experimental validation or physical-parameter confidence.'}
    (OUT/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    (OUT/'summary.md').write_text('独立验证'+('通过' if result['status']=='passed' else '存在失败项')+'\n\n'+str(len(checks))+'项检查。\n\n'+json.dumps(sections,ensure_ascii=False,indent=2)+'\n\n这些检查证明数值实现与所声明情景一致，不构成跨功率、温度或实际阵列的实验精度验证。',encoding='utf-8')
    print(json.dumps({'status':result['status'],'checks':len(checks),'sections':sections,'failed':[c for c in checks if not c['passed']]},ensure_ascii=False))
    if result['status']!='passed':raise SystemExit(1)


if __name__=='__main__':
    sections={'core':verify_core(),'optics':verify_optics(),'single':verify_single()}
    write_result(sections)
