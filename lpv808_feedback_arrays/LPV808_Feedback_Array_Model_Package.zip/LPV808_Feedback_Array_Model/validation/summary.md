独立数值验证：passed

4551 项检查；含core、optics、single、arrays。

只评价方程实现、守恒和声明支持域，不构成新工况实验精度验证。

{
  "core": {
    "status": "passed",
    "independent_reference_anchor": {
      "Pin_W": 8,
      "Tj_C": 39.99999999999999,
      "Qheat_W": 2.769742487040305,
      "Isc_A": 0.7361247468865589,
      "Voc_V": 7.095740478956524,
      "Vmpp_V": 6.300514908115437,
      "Impp_A": 0.7031580081261709,
      "Pmpp_W": 4.430257512959695,
      "FF": 0.8481639893598912,
      "Rmpp_ohm": 8.960311672913361
    },
    "max_current_difference_A": 1.4704903961160198e-13,
    "max_KCL_A": 1.128958038165706e-14,
    "max_relative_parameter_difference": 0.0,
    "max_feature_difference": 9.572956543024702e-07
  },
  "optics": {
    "status": "passed",
    "cases_checked": 128,
    "max_independent_cell_power_difference_W": 8.704148513061227e-14,
    "random_rectangle_count": 24,
    "random_Gaussian_fraction_error": 1.1102230246251565e-16,
    "random_TopHat_fraction_error": 8.326672684688674e-17,
    "TopHat_reference": "Closed-form signed disk-quadrant intersection, independent of strip quadrature."
  },
  "single": {
    "status": "passed",
    "staged_rows": 12,
    "fixed_point_iteration_rows": 22,
    "ODE_saved_rows": 1204,
    "independent_ODE_cases": [
      {
        "case": "4to12W",
        "max_temperature_difference_K": 4.310862777856528e-11,
        "instantaneous_power_max_difference_W": 5.329070518200751e-15,
        "independent_integrated_energy_residual_J": 1.0305534203780553e-11,
        "independent_end_Tj_C": 48.05152128655809
      },
      {
        "case": "8to16W",
        "max_temperature_difference_K": 3.4361846701358445e-11,
        "instantaneous_power_max_difference_W": 8.881784197001252e-15,
        "independent_integrated_energy_residual_J": 9.9333874459262e-12,
        "independent_end_Tj_C": 56.836602368547766
      }
    ],
    "dynamic_interpretation": "Instantaneous electrical MPP at T(t) coupled to thermal ODE; no inner steady-temperature solve."
  },
  "arrays": {
    "status": "passed",
    "check_count": 2890,
    "maxima": {
      "implicit_current_A": 4.1933123640092163e-13,
      "thermal_K": 1.4814816040598089e-12,
      "KVL_V": 1.6279670944641111e-09,
      "KCL_A": 4.440892098500626e-16,
      "source_budget_W": 5.46265255252365e-10,
      "MPP_upper_bound_W": 1.2449419273252715e-10
    },
    "independent_network_maxima": [
      {
        "case_id": "R3C3_TopHat_uniform_received_mean_8",
        "connection": "primary",
        "production_Pmax_W": 39.872317616653675,
        "independent_Pmax_W": 39.87231761663839,
        "difference_W": -1.5283774246199755e-11,
        "independent_Vmax_V": 18.90154472563796,
        "independent_support_V": [
          9.825473767932635e-15,
          20.700597607946673
        ]
      },
      {
        "case_id": "R5C5_Gaussian_nonuniform_received_mean_8",
        "connection": "primary",
        "production_Pmax_W": 50.85467980989383,
        "independent_Pmax_W": 50.854679809881475,
        "difference_W": -1.2356338174868142e-11,
        "independent_Vmax_V": 32.8833882407416,
        "independent_support_V": [
          27.445324991586546,
          34.09425012444929
        ]
      },
      {
        "case_id": "R4C5_TopHat_nonuniform_received_mean_8",
        "connection": "secondary",
        "production_Pmax_W": 42.97028925646151,
        "independent_Pmax_W": 42.97028925642554,
        "difference_W": -3.597477871153387e-11,
        "independent_Vmax_V": 32.945246599519955,
        "independent_support_V": [
          27.475264440674295,
          34.37443892228774
        ]
      },
      {
        "case_id": "R5C5_Gaussian_nonuniform_source_Ps_40",
        "connection": "primary",
        "production_Pmax_W": 5.901874682610605,
        "independent_Pmax_W": 5.901874682625087,
        "difference_W": 1.4482637311630242e-11,
        "independent_Vmax_V": 27.285413669413845,
        "independent_support_V": [
          27.285413669413845,
          33.11754159091888
        ]
      }
    ],
    "scope": "All 144 exported operating points checked against independent equations; four representative network maxima independently re-solved with scalar inner-potential/heat/current roots."
  }
}