from pathlib import Path
import sys,json,os
ROOT=Path(__file__).resolve().parents[1]
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.mpl_cache'))
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt,font_manager as fm
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
sys.path.insert(0,str(ROOT));import core
FONT=Path(os.environ.get('LPV_FONT_DIR','/workspace/work/lpv_response_figures/fonts'))
for n in ['Times.TTF','Timesbd.TTF','Timesi.TTF','Timesbi.TTF','SimSun-Regular.ttf']:
 if (FONT/n).exists():fm.fontManager.addfont(str(FONT/n))
for family in ['Times New Roman','SimSun']:fm.findfont(fm.FontProperties(family=family),fallback_to_default=False)
plt.rcParams.update({'font.family':['Times New Roman','SimSun'],'axes.unicode_minus':False,'font.size':11,'pdf.fonttype':42,'svg.fonttype':'none','figure.facecolor':'white','axes.linewidth':.8,'xtick.direction':'in','ytick.direction':'in'})
OUT=ROOT/'report/extra_figures';OUT.mkdir(exist_ok=True)
def save(fig,name):
 fig.savefig(OUT/(name+'.png'),dpi=450,bbox_inches='tight');fig.savefig(OUT/(name+'.pdf'),bbox_inches='tight');plt.close(fig)
raw=pd.read_csv(ROOT/'input/selected_007_raw.csv');v=raw.voltage_V.values;i=raw.current_output_A.values
fig,ax=plt.subplots(1,2,figsize=(7.1,3.15));fine=np.linspace(0,7.1,600)
ax[0].plot(v[:72],i[:72]*1000,'o',ms=2.9,c='#111111',label='实测点（72点）');ax[0].plot(fine,core.current(fine,8,40)*1000,c='#003087',lw=1.5,label='沿用五参数模型')
ax[0].set(xlabel='端口电压 (V)',ylabel='输出电流 (mA)');ax[0].legend(fontsize=8.8,frameon=False,loc='lower left');ax[0].text(.02,.95,'(a)',transform=ax[0].transAxes,va='top',fontweight='bold')
e=(core.current(v[:72],8,40)-i[:72])*1000;ax[1].axhline(0,c='#777777',lw=.8);ax[1].plot(v[:72],e,'o-',ms=2.3,c='#E60026',lw=.9);ax[1].set(xlabel='端口电压 (V)',ylabel='模型减实测电流 (mA)');ax[1].text(.02,.95,'(b)',transform=ax[1].transAxes,va='top',fontweight='bold')
fig.tight_layout();save(fig,'baseline_reconstruction')
fig,ax=plt.subplots(figsize=(8.0,3.45));ax.set_xlim(0,10);ax.set_ylim(0,4);ax.axis('off')
def box(x,y,w,h,s,c):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.06',ec=c,fc='white',lw=1.0));ax.text(x+w/2,y+h/2,s,ha='center',va='center',fontsize=11)
def ar(a,b,c='#003087'):
 ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=11,color=c,lw=1.2))
box(.1,2.5,1.55,.8,'光源与传输\nPs、ηchain','#003087');box(2.0,2.5,1.65,.8,'有源面积分\n每片 Pin','#003087');box(4.05,2.5,2.05,.8,'参数更新\nθ(Pin, Tj)','#003087');box(6.6,2.5,3.1,.8,'负载 / 阵列工作点\nV、I、Pe = VI','#003087')
ar((1.7,2.9),(1.95,2.9));ar((3.7,2.9),(4.,2.9));ar((6.15,2.9),(6.55,2.9))
box(6.65,.55,3.0,.95,'热模型\nQ = fret Pin − Pe','#B45A20');box(3.9,.55,2.25,.95,'单片结温\nTj(t) 或稳态 Tj','#176A79')
ar((8.15,2.45),(8.15,1.55),'#B45A20');ar((6.6,1.0),(6.2,1.0),'#176A79');ar((5.0,1.55),(5.0,2.45),'#176A79')
ax.plot([2.8,2.8,7.2],[2.45,1.9,1.9],color='#B45A20',lw=1.0);ar((7.2,1.9),(7.2,1.55),'#B45A20')
ax.text(1.8,.95,'每片电池按完整单体计算；\n阵列各片分别接收、发热并更新参数。',ha='center',va='center',fontsize=9.7,color='#555555')
fig.tight_layout();save(fig,'feedback_architecture')
print(OUT)
