"""Fixed-point, Brent-root and ODE study of a uniform complete 6J cell.

Run from any directory.  Outputs are conditional simulations, not additional
experimental validation.  The 8 W / Tj=40 C anchor is a construction constraint.
"""
from pathlib import Path
import sys
import json
import hashlib
import importlib.util
import numpy as np
import pandas as pd
from scipy.optimize import brentq
from scipy.integrate import solve_ivp, quad

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT))
import core as m


def point(P,T,Tsink=25.,cfg=None):
    c=m.config(cfg);par=m.params(P,T,c);f=m.features(P,T,c)
    pe=f['Pmpp_W'];q=c['eta_h']*P-pe
    return {'Pin_W':float(P),'Tj_C':float(T),'T_sink_C':float(Tsink),
            'Rth_K_per_W':float(c['Rth_K_per_W']),'eta_h':float(c['eta_h']),
            **par,**f,'Pe_W':pe,'Pout_W':pe,'Qheat_W':q,
            'T_next_C':Tsink+c['Rth_K_per_W']*q,
            'thermal_residual_K':T-Tsink-c['Rth_K_per_W']*q,
            'energy_retention_residual_W':c['eta_h']*P-pe-q}


def iterate(P,Tsink=25.,cfg=None,initial=None,tolerance=1e-10,maxiter=100):
    t=Tsink if initial is None else initial
    rows=[]
    for k in range(maxiter+1):
        row={'iteration':k,**point(P,t,Tsink,cfg)}
        rows.append(row)
        if abs(row['thermal_residual_K'])<=tolerance:
            return rows
        t=row['T_next_C']
    raise RuntimeError('Fixed-point iteration did not converge.')


def ode_case(p0,p1,C=.3,Tsink=25.,step=.5,tend=30.):
    c=m.config();r=c['Rth_K_per_W']
    initial=m.thermal_mpp(p0,Tsink,c)
    final=m.thermal_mpp(p1,Tsink,c)
    rhs=lambda p:lambda t,y:[(c['eta_h']*p-m.features(p,float(y[0]),c)['Pmpp_W']-(float(y[0])-Tsink)/r)/C]
    first=solve_ivp(rhs(p0),(0.,step),[initial['Tj_C']],rtol=2e-10,atol=2e-11,
                    max_step=.04,dense_output=True)
    second=solve_ivp(rhs(p1),(step,tend),first.y[:,-1],rtol=2e-10,atol=2e-11,
                     max_step=.04,dense_output=True)
    if not first.success or not second.success:
        raise RuntimeError('Thermal ODE integration failed.')
    case=f'{p0:g}to{p1:g}W'
    rows=[];energies=[]
    for segment,p,sol,start,end in [('pre',p0,first,0.,step),('post',p1,second,step,tend)]:
        times=np.linspace(start,end,11 if segment=='pre' else 591)
        for t in times:
            temp=float(sol.sol(t)[0]);f=m.features(p,temp,c);pe=f['Pmpp_W']
            qheat=c['eta_h']*p-pe;qloss=(temp-Tsink)/r;dtdt=(qheat-qloss)/C
            rows.append({'case':case,'segment':segment,'t_s':float(t),'Pin_W':p,
                         'Tj_C':temp,'T_sink_C':Tsink,'Rth_K_per_W':r,'Cth_J_per_K':C,
                         'V_V':f['Vmpp_V'],'I_A':f['Impp_A'],'Pout_W':pe,
                         'Qheat_W':qheat,'Qloss_W':qloss,'dTdt_K_per_s':dtdt,
                         **m.params(p,temp,c),
                         'instantaneous_ODE_residual_W':C*dtdt-(c['eta_h']*p-pe-qloss)})
        retained=c['eta_h']*p*(end-start)
        pe_integral=quad(lambda t:m.features(p,float(sol.sol(t)[0]),c)['Pmpp_W'],start,end,
                         epsabs=1e-8,epsrel=2e-10,limit=100)[0]
        loss_integral=quad(lambda t:(float(sol.sol(t)[0])-Tsink)/r,start,end,
                          epsabs=1e-8,epsrel=2e-10,limit=100)[0]
        storage=C*float(sol.y[0,-1]-sol.y[0,0])
        energies.append({'case':case,'segment':segment,'t_start_s':start,'t_end_s':end,
                         'retained_optical_energy_J':retained,'electrical_output_energy_J':pe_integral,
                         'convective_loss_energy_J':loss_integral,'stored_energy_change_J':storage,
                         'integrated_energy_residual_J':retained-pe_integral-loss_integral-storage})
    tendT=float(second.y[0,-1]);t0=initial['Tj_C'];tf=final['Tj_C']
    target=t0+(1-np.exp(-1))*(tf-t0)
    t63=brentq(lambda t:float(second.sol(t)[0])-target,step,tend,xtol=1e-11)-step
    postfirst=next(row for row in rows if row['segment']=='post')
    summary={'case':case,'initial_Pin_W':p0,'final_Pin_W':p1,'step_time_s':step,'end_time_s':tend,
             'Cth_J_per_K':C,'operating_policy':'ideal instantaneous MPPT with thermal ODE',
             'initial_Tj_C':t0,'final_root_Tj_C':tf,'ODE_end_Tj_C':tendT,
             'ODE_endpoint_temperature_error_K':tendT-tf,
             'initial_Pout_W':initial['Pout_W'],'immediate_post_step_Pout_W':postfirst['Pout_W'],
             'final_root_Pout_W':final['Pout_W'],
             'ODE_end_Pout_W':m.features(p1,tendT,c)['Pmpp_W'],
             't63p2_after_step_s':float(t63),'bare_RthC_s':r*C,
             'linearized_final_tau_s':r*C/final['ODE_stability_margin'],
             'temperature_jump_at_step_K':postfirst['Tj_C']-first.y[0,-1],
             'max_integrated_energy_residual_J':max(abs(e['integrated_energy_residual_J']) for e in energies)}
    return rows,energies,summary


def main():
    powers=[4.,8.,12.,16.];comparisons=[];feedback=[];hist=[];curves=[]
    for p in powers:
        row0=point(p,25.)
        row1=point(p,row0['T_next_C'])
        root=m.thermal_mpp(p)
        row2=point(p,root['Tj_C'])
        for label,row in [('freeze_T25',row0),('one_pass',row1),('closed_loop_Brent',row2)]:
            comparisons.append({'model_stage':label,**row,
                                'Pout_minus_closed_loop_W':row['Pout_W']-root['Pout_W'],
                                'T_minus_closed_loop_K':row['Tj_C']-root['Tj_C']})
        its=iterate(p);end=its[-1]
        gain=root['fixed_point_gain']
        feedback.append({'Pin_W':p,'freeze_T25_Pout_W':row0['Pout_W'],
                         'one_pass_Tj_C':row1['Tj_C'],'one_pass_Pout_W':row1['Pout_W'],
                         'one_pass_residual_K':row1['thermal_residual_K'],
                         'closed_loop_Tj_C':root['Tj_C'],'closed_loop_Pout_W':root['Pout_W'],
                         'closed_loop_Qheat_W':root['Qheat_W'],
                         'feedback_power_loss_vs_frozen_percent':100*(1-root['Pout_W']/row0['Pout_W']),
                         'iteration_count':end['iteration'],'fixed_point_gain':gain,
                         'fixed_point_converges_local':abs(gain)<1,
                         'ODE_stability_margin':root['ODE_stability_margin'],
                         'ODE_stable_local':root['ODE_stability_margin']>0,
                         'fixedpoint_vs_Brent_T_abs_error_K':abs(end['Tj_C']-root['Tj_C']),
                         'fixedpoint_vs_Brent_P_abs_error_W':abs(end['Pout_W']-root['Pout_W'])})
        if p in [12.,16.]:
            hist.extend(its)
            for stage,row in [('freeze_T25',row0),('one_pass',row1),('closed_loop',row2)]:
                vv=np.linspace(0,row['Voc_V'],181);ii=m.current(vv,p,row['Tj_C'])
                for v,i in zip(vv,ii):
                    curves.append({'Pin_W':p,'stage':stage,'Tj_C':row['Tj_C'],'V_V':v,'I_A':i,'Pout_W':v*i})
    pd.DataFrame(comparisons).to_csv(HERE/'freeze_onepass_converged.csv',index=False)
    pd.DataFrame(feedback).to_csv(HERE/'feedback_summary.csv',index=False)
    pd.DataFrame(hist).to_csv(HERE/'fixedpoint_iterations.csv',index=False)
    pd.DataFrame(curves).to_csv(HERE/'iteration_IV_curves.csv',index=False)

    sens=[]
    for beta in [0.,m.CONFIG['beta_Voc_V_per_K']]:
        for rth in [3.,m.CONFIG['Rth_K_per_W'],8.]:
            for ts in [25.,45.]:
                c=m.config({'beta_Voc_V_per_K':beta,'Rth_K_per_W':rth})
                for p in powers:
                    s=m.thermal_mpp(p,ts,c)
                    sens.append({'temperature_update_policy':'all_five_parameters_updated',
                                 'beta_Voc_V_per_K':beta,**s})
    # A true no-parameter-feedback counterfactual freezes ALL temperature laws.
    # Setting betaVoc=0 alone does not freeze a(T) or the reconstructed I0(T).
    for rth in [3.,m.CONFIG['Rth_K_per_W'],8.]:
        for ts in [25.,45.]:
            for p in powers:
                e=m.features(p,25.);q=m.CONFIG['eta_h']*p-e['Pmpp_W']
                sens.append({'temperature_update_policy':'all_parameters_frozen_at_25C',
                             'beta_Voc_V_per_K':None,'Pin_W':p,'T_sink_C':ts,'Rth_K_per_W':rth,
                             'Tj_C':ts+rth*q,'Pout_W':e['Pmpp_W'],'V_V':e['Vmpp_V'],'I_A':e['Impp_A'],
                             'Qheat_W':q,'fixed_point_gain':0.,'ODE_stability_margin':1.,
                             'thermal_balance_residual_K':0.})
    pd.DataFrame(sens).to_csv(HERE/'coefficient_boundary_sensitivity.csv',index=False)

    ode_rows=[];energy=[];ode_summary=[]
    for p0,p1 in [(4.,12.),(8.,16.)]:
        rr,ee,ss=ode_case(p0,p1)
        ode_rows.extend(rr);energy.extend(ee);ode_summary.append(ss)
    pd.DataFrame(ode_rows).to_csv(HERE/'thermal_ODE_steps.csv',index=False)
    pd.DataFrame(energy).to_csv(HERE/'thermal_ODE_energy.csv',index=False)
    pd.DataFrame(ode_summary).to_csv(HERE/'thermal_ODE_summary.csv',index=False)

    # Compare with the literal source model at temperatures/powers outside the
    # anchor too. This is implementation migration, not empirical validation.
    spec=importlib.util.spec_from_file_location('uploaded_report_source',ROOT/'input/source_core_model.py')
    original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
    parameter_errors=[];current_errors=[];inverse_errors=[];kcl=[]
    for p in [2.,4.,8.,12.,16.]:
        for t in [25.,40.,60.,90.]:
            par=m.params(p,t);old=original.parameters(p,t)
            parameter_errors.extend(abs(par[k]-old[k]) for k in m.KEYS)
            f=m.features(p,t);v=np.linspace(0,f['Voc_V'],61);i=m.current(v,p,t)
            current_errors.extend(abs(i-original.current(v,p,t)))
            inverse_errors.extend(abs(m.voltage(i,p,t)-v))
            u=v+i*par['Rs_ohm']
            kcl.extend(abs(par['Iph_A']-par['I0_A']*np.expm1(u/par['a_V'])-u/par['Rsh_ohm']-i))
    anchor=m.thermal_mpp(8.)
    checks={'source_baseline_parameter_exact_equality':m.BASE==original.BASE,
            'source_thermal_config_exact_equality':m.CONFIG==original.DEFAULT_CONFIG,
            'source_parameter_max_abs_difference':float(max(parameter_errors)),
            'source_IV_max_abs_difference_A':float(max(current_errors)),
            'inverse_IV_max_abs_difference_V':float(max(inverse_errors)),
            'literal_KCL_max_abs_residual_A':float(max(kcl)),
            'constructed_anchor_Tj_abs_difference_K':abs(anchor['Tj_C']-40.),
            'constructed_anchor_Pout_abs_difference_W':abs(anchor['Pout_W']-m.BASE_FEATURES['Pmpp_W']),
            'fixedpoint_vs_Brent_max_T_error_K':max(r['fixedpoint_vs_Brent_T_abs_error_K'] for r in feedback),
            'ODE_endpoint_max_T_error_K':max(abs(r['ODE_endpoint_temperature_error_K']) for r in ode_summary),
            'ODE_max_integrated_energy_residual_J':max(r['max_integrated_energy_residual_J'] for r in ode_summary),
            'ODE_temperature_jump_at_step_K':max(abs(r['temperature_jump_at_step_K']) for r in ode_summary)}
    assert checks['source_baseline_parameter_exact_equality']
    assert checks['source_thermal_config_exact_equality']
    assert checks['source_parameter_max_abs_difference']<1e-12
    assert checks['source_IV_max_abs_difference_A']<1e-12
    assert checks['inverse_IV_max_abs_difference_V']<1e-10
    assert checks['literal_KCL_max_abs_residual_A']<1e-10
    assert checks['fixedpoint_vs_Brent_max_T_error_K']<1e-8
    assert checks['ODE_endpoint_max_T_error_K']<2e-5
    assert checks['ODE_max_integrated_energy_residual_J']<1e-6
    (HERE/'checks.json').write_text(json.dumps(checks,indent=2))
    summary={'baseline':'EXACT joint-calibrated five-parameter model from supplied report',
             'parameters':m.BASE,'config':m.CONFIG,'feedback_comparison':feedback,
             'ODE_cases':ode_summary,'sensitivity_rows':len(sens),'checks':checks,
             'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                              for p in [ROOT/'input/source_core_model.py',ROOT/'input/source_model_config.json']},
             'scope':'Uniform whole-cell conditional simulation. Source migration, anchor closure, fixedpoint/Brent agreement and ODE conservation are numerical checks, not new experimental precision.'}
    (HERE/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
    (HERE/'notes.txt').write_text(
        '基线严格采用上传综合报告联合标定五参数及原温度律，没有重新拟合，没有替换成解析提参结果。\n'
        'Pin为一整只六结电池截获的总光功率；电池片内始终采用单一均匀有效结温和端口模型。\n'
        '闭环迭代每步重新按瞬时结温计算全部五参数，再求理想MPP、电输出、留存光能差和温升。\n'
        'one_pass由T0=25摄氏度的Pe估计一次温升，再于该温度重算电学，尚未满足热平衡；closed_loop同时闭合。\n'
        '固定点增益g=−Rth*dPe/dT。无松弛固定点需|g|<1；热ODE局部稳定需1−g>0，两者不能混称。\n'
        'betaVoc=0只取消Voc8温度律，a仍随绝对温度变，I0仍据开路条件重建，因此不等于取消全部电热反馈。\n'
        '真正的no-feedback对照将全部温度依赖参数冻结在25摄氏度；光功率对Iph的缩放仍保留。\n'
        'eta_h=0.9表示光能净留存比例，Qheat=eta_h*Pin−Pe。未留存的0.1Pin不是结内热源。\n'
        '动态采用Cth=0.3 J/K和理想瞬时MPPT；电学随温度准静态更新，温度在光功率阶跃处连续。\n'
        'ODE的秒级热响应不代表载流子、结电容或MPPT控制环带宽。\n'
        '8W/结温40摄氏度/热沉25摄氏度是原假定与Rth构造形成的锚点，不能作为独立实验验证。\n'
        '全部跨功率、温度、散热边界和热容结果都是条件性仿真；精度须由新增接收功率、结温和瞬态实测检验。\n',encoding='utf-8')
    print(json.dumps({'feedback':feedback,'ODE':ode_summary,'checks':checks},indent=2))


if __name__=='__main__':
    main()
