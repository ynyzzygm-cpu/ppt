"""Recompute saved numerical results; optionally regenerate figures and Word."""
from pathlib import Path
import argparse,os,subprocess,sys
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('--figures',action='store_true',help='Regenerate plots and full irradiance atlas; requires actual requested fonts.')
p.add_argument('--report',action='store_true',help='Also build Word after generating figures; requires python-docx.')
args=p.parse_args()
steps=['optics/build_cases.py','single/run_single.py','arrays/run_arrays.py',
       'arrays/verify_numerics.py','validation/validate_feedback.py','validation/validate_arrays_independent.py']
if args.figures or args.report:steps+=['plot_figures.py','report/extra_figures.py','optics/plot_atlas.py']
if args.report:steps+=['build_report.py']
env=os.environ.copy();env.setdefault('LPV_OUTPUT_DIR',str(ROOT/'output'))
env.setdefault('MPLCONFIGDIR',str(ROOT/'.mpl_cache'))
for step in steps:
 print('Running '+step,flush=True)
 subprocess.run([sys.executable,str(ROOT/step)],cwd=ROOT,env=env,check=True)
print('Completed. Numeric CSV/JSON remain in their module folders. Documents/atlas: '+env['LPV_OUTPUT_DIR'])
